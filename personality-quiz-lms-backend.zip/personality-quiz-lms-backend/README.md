# Personality Quiz LMS — Django Backend

This is the Django backend created for the LMS mini quiz project.

## Features
- Django project configuration
- `Question` model
- Django admin for adding questions
- Django REST Framework API
- `GET /api/questions/` endpoint
- Correct answers are not returned by the questions endpoint

## Setup

Create/activate a virtual environment, then install dependencies:

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Create the database tables:

```bash
python manage.py makemigrations
python manage.py migrate
```

Create an admin account:

```bash
python manage.py createsuperuser
```

Run the server:

```bash
python manage.py runserver
```

Admin:
`http://127.0.0.1:8000/admin/`

Questions API:
`http://127.0.0.1:8000/api/questions/`

## Important

This starter backend uses SQLite for easy setup. For a larger/production LMS, PostgreSQL is a better next step.
