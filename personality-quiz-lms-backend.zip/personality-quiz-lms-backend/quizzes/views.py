from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Question


@api_view(['GET'])
def get_questions(request):
    questions = Question.objects.all()

    data = []

    for question in questions:
        data.append({
            'id': question.id,
            'question_text': question.question_text,
            'option_a': question.option_a,
            'option_b': question.option_b,
            'option_c': question.option_c,
            'option_d': question.option_d,
        })

    return Response(data)
