import { useState } from "react";

const COLORS = {
  lavender: "#BFA2DB",
  softPurple: "#CDB4DB",
  accent: "#8E7CC3",
  bg: "#FAF8FF",
  white: "#FFFFFF",
  text: "#2D2547",
  textMuted: "#7B6FA0",
  textLight: "#A99CC4",
  border: "#E8E0F5",
  cardShadow: "0 2px 16px rgba(143,124,195,0.10)",
  success: "#6DBF94",
  warning: "#F4A261",
  error: "#E07070",
  successBg: "#EBF9F2",
  warningBg: "#FEF3EA",
  errorBg: "#FCEAEA",
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Poppins', sans-serif; background: ${COLORS.bg}; color: ${COLORS.text}; }
  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: ${COLORS.bg}; }
  ::-webkit-scrollbar-thumb { background: ${COLORS.border}; border-radius: 3px; }
  button { cursor: pointer; font-family: 'Poppins', sans-serif; }
  input, select, textarea { font-family: 'Poppins', sans-serif; }

  /* --- Hover interactions --- */
  .btn-hover { transition: transform .18s ease, box-shadow .18s ease, filter .18s ease; }
  .btn-hover:hover { transform: translateY(-2px); filter: brightness(1.04); }
  .btn-hover.btn-primary-hover:hover { box-shadow: 0 8px 20px rgba(143,124,195,0.35); }
  .btn-hover.btn-secondary-hover:hover { box-shadow: 0 6px 16px rgba(143,124,195,0.18); border-color: ${COLORS.accent}; }
  .btn-hover.btn-ghost-hover:hover { background: ${COLORS.bg}; color: ${COLORS.accent}; }
  .btn-hover:active { transform: translateY(0); }

  .role-card { transition: transform .22s ease, box-shadow .22s ease, border-color .22s ease, background .22s ease; }
  .role-card:hover { transform: translateY(-6px); box-shadow: 0 16px 36px rgba(143,124,195,0.22); }
  .role-card:hover .role-card-icon { transform: scale(1.08) rotate(-3deg); }
  .role-card-icon { transition: transform .22s ease; }

  .nav-item { transition: background .15s ease, color .15s ease, padding-left .15s ease; }
  .nav-item:hover:not(.nav-item-active) { background: ${COLORS.bg} !important; color: ${COLORS.accent} !important; padding-left: 14px !important; }

  .icon-btn-hover { transition: background .15s ease, transform .15s ease, border-color .15s ease; }
  .icon-btn-hover:hover { background: ${COLORS.white} !important; transform: translateY(-1px); border-color: ${COLORS.accent}55 !important; box-shadow: 0 4px 12px rgba(143,124,195,0.15); }

  .convo-row { transition: background .15s ease; }
  .convo-row:hover { background: ${COLORS.bg}; }

  .feature-card { transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease; }
  .feature-card:hover { transform: translateY(-4px); box-shadow: 0 12px 28px rgba(143,124,195,0.16); border-color: ${COLORS.accent}66; }

  .campaign-card-hover { transition: transform .2s ease, box-shadow .2s ease; }
  .campaign-card-hover:hover { transform: translateY(-3px); box-shadow: 0 14px 32px rgba(143,124,195,0.18); }

  /* --- Decorative background --- */
  .bg-decor { position: fixed; inset: 0; z-index: 0; overflow: hidden; pointer-events: none; }
  .bg-decor::before, .bg-decor::after, .bg-decor .blob3 {
    content: ""; position: absolute; border-radius: 50%; filter: blur(70px);
  }
  .bg-decor::before {
    width: 520px; height: 520px; top: -180px; right: -120px;
    background: radial-gradient(circle at 30% 30%, ${COLORS.lavender}55, transparent 70%);
  }
  .bg-decor::after {
    width: 460px; height: 460px; bottom: -160px; left: -140px;
    background: radial-gradient(circle at 60% 60%, ${COLORS.accent}40, transparent 70%);
  }
  .bg-decor .blob3 {
    width: 380px; height: 380px; top: 38%; left: 48%;
    background: radial-gradient(circle, ${COLORS.softPurple}30, transparent 70%);
  }
  .bg-dotgrid {
    position: fixed; inset: 0; z-index: 0; pointer-events: none;
    background-image: radial-gradient(${COLORS.accent}22 1px, transparent 1px);
    background-size: 26px 26px;
    -webkit-mask-image: linear-gradient(180deg, rgba(0,0,0,0.9), rgba(0,0,0,0.15) 60%, transparent 100%);
    mask-image: linear-gradient(180deg, rgba(0,0,0,0.9), rgba(0,0,0,0.15) 60%, transparent 100%);
  }
`;

const BackgroundDecor = () => (
  <>
    <div className="bg-decor"><div className="blob3" /></div>
    <div className="bg-dotgrid" />
  </>
);

// --- ICONS ---
const Icon = ({ name, size = 18, color = "currentColor" }) => {
  const icons = {
    dashboard: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
    campaign: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11l19-9-9 19-2-8-8-2z"/></svg>,
    users: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
    message: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
    analytics: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
    calendar: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
    settings: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
    bell: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>,
    search: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
    contract: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>,
    payment: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>,
    portfolio: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>,
    star: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
    logout: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
    plus: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    trending: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>,
    filter: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>,
    check: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
    bookmark: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>,
    media: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
    user: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
    eye: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
    arrow: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>,
    globe: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>,
    megaphone: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11v2a6 6 0 0 0 6 6h0a6 6 0 0 0 6-6v-2"/><path d="M21 3L9 9v6l12 6V3z"/><line x1="3" y1="9" x2="9" y2="9"/><line x1="3" y1="15" x2="9" y2="15"/></svg>,
    mail: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>,
    phone: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>,
    pin: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>,
    clock: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
    target: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
    shield: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
    heart: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>,
    chevronDown: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>,
  };
  return icons[name] || icons.dashboard;
};

// --- SHARED COMPONENTS ---
const Badge = ({ label, color = COLORS.accent, bg = "#EDE8F9" }) => (
  <span style={{ background: bg, color, fontSize: 11, fontWeight: 600, borderRadius: 20, padding: "2px 10px", letterSpacing: 0.3 }}>{label}</span>
);

const Btn = ({ children, variant = "primary", onClick, style = {} }) => {
  const styles = {
    primary: { background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})`, color: "#fff", border: "none" },
    secondary: { background: COLORS.white, color: COLORS.accent, border: `1.5px solid ${COLORS.border}` },
    ghost: { background: "transparent", color: COLORS.textMuted, border: "none" },
  };
  return (
    <button onClick={onClick} className={`btn-hover btn-${variant}-hover`} style={{ ...styles[variant], padding: "9px 20px", borderRadius: 12, fontWeight: 500, fontSize: 13, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6, ...style }}>
      {children}
    </button>
  );
};

const StatCard = ({ label, value, sub, icon, color = COLORS.accent, bg = "#F0EBF9" }) => (
  <div style={{ background: COLORS.white, borderRadius: 18, padding: "20px 22px", boxShadow: COLORS.cardShadow, display: "flex", gap: 14, alignItems: "center" }}>
    <div style={{ width: 46, height: 46, borderRadius: 14, background: bg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <Icon name={icon} color={color} size={22} />
    </div>
    <div>
      <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.text, lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 3 }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: COLORS.success, marginTop: 2, fontWeight: 500 }}>{sub}</div>}
    </div>
  </div>
);

const Avatar = ({ name, size = 36, color = COLORS.accent, bg = "#EDE8F9" }) => {
  const initials = name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: bg, color, fontSize: size * 0.35, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      {initials}
    </div>
  );
};

// Mini bar chart
const MiniChart = ({ data, color = COLORS.accent }) => {
  const max = Math.max(...data);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 48 }}>
      {data.map((v, i) => (
        <div key={i} style={{ flex: 1, background: i === data.length - 1 ? color : `${color}40`, borderRadius: "4px 4px 0 0", height: `${(v / max) * 100}%`, transition: "height .5s" }} />
      ))}
    </div>
  );
};

// --- SIDEBAR ---
const Sidebar = ({ role, page, setPage, onLogout }) => {
  const brandNav = [
    { id: "dashboard", label: "Dashboard", icon: "dashboard" },
    { id: "campaigns", label: "Campaigns", icon: "campaign" },
    { id: "discovery", label: "Influencer Discovery", icon: "users" },
    { id: "messages", label: "Messages", icon: "message" },
    { id: "contracts", label: "Contracts", icon: "contract" },
    { id: "analytics", label: "Analytics", icon: "analytics" },
    { id: "calendar", label: "Calendar", icon: "calendar" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];
  const influencerNav = [
    { id: "dashboard", label: "Dashboard", icon: "dashboard" },
    { id: "opportunities", label: "Opportunities", icon: "megaphone" },
    { id: "collaborations", label: "Collaborations", icon: "users" },
    { id: "applications", label: "Applications", icon: "bookmark" },
    { id: "messages", label: "Messages", icon: "message" },
    { id: "portfolio", label: "Portfolio", icon: "portfolio" },
    { id: "analytics", label: "Analytics", icon: "analytics" },
    { id: "payments", label: "Payments", icon: "payment" },
    { id: "reviews", label: "Reviews", icon: "star" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];
  const nav = role === "brand" ? brandNav : influencerNav;

  return (
    <div style={{ width: 220, background: COLORS.white, borderRight: `1px solid ${COLORS.border}`, display: "flex", flexDirection: "column", height: "100vh", position: "fixed", top: 0, left: 0, zIndex: 100 }}>
      <div style={{ padding: "24px 20px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <div style={{ width: 32, height: 32, borderRadius: 10, background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="globe" color="#fff" size={16} />
          </div>
          <span style={{ fontWeight: 700, fontSize: 16, color: COLORS.text }}>Pressly</span>
        </div>
        <div style={{ marginTop: 6, fontSize: 11, color: COLORS.textMuted, background: "#F3EEF9", borderRadius: 8, padding: "3px 8px", display: "inline-block", fontWeight: 500, textTransform: "uppercase", letterSpacing: 0.5 }}>
          {role === "brand" ? "Brand" : "Influencer"}
        </div>
      </div>

      <nav style={{ flex: 1, padding: "8px 12px", overflowY: "auto" }}>
        {nav.map(item => {
          const active = page === item.id;
          return (
            <button key={item.id} onClick={() => setPage(item.id)} className={`nav-item ${active ? "nav-item-active" : ""}`} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 10px", borderRadius: 12, border: "none", background: active ? `linear-gradient(135deg, ${COLORS.accent}22, ${COLORS.lavender}22)` : "transparent", color: active ? COLORS.accent : COLORS.textMuted, fontWeight: active ? 600 : 400, fontSize: 13, cursor: "pointer", marginBottom: 2, textAlign: "left" }}>
              <Icon name={item.icon} color={active ? COLORS.accent : COLORS.textLight} size={17} />
              {item.label}
              {active && <div style={{ marginLeft: "auto", width: 6, height: 6, borderRadius: "50%", background: COLORS.accent }} />}
            </button>
          );
        })}
      </nav>

      <div style={{ padding: "12px 12px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px", borderRadius: 12, background: COLORS.bg, marginBottom: 4 }}>
          <Avatar name={role === "brand" ? "Zara Fashion" : "Ayla Rahman"} size={32} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{role === "brand" ? "Zara Fashion" : "Ayla Rahman"}</div>
            <div style={{ fontSize: 10, color: COLORS.textMuted }}>Pro plan</div>
          </div>
        </div>
        <button onClick={onLogout} className="icon-btn-hover" style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, padding: "9px 10px", borderRadius: 12, border: "none", background: "transparent", color: COLORS.error, fontSize: 13, cursor: "pointer" }}>
          <Icon name="logout" color={COLORS.error} size={16} /> Sign out
        </button>
      </div>
    </div>
  );
};

// --- TOPBAR ---
const Topbar = ({ title }) => (
  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 28px", background: COLORS.white, borderBottom: `1px solid ${COLORS.border}`, position: "sticky", top: 0, zIndex: 50 }}>
    <div style={{ fontSize: 18, fontWeight: 700, color: COLORS.text }}>{title}</div>
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, background: COLORS.bg, borderRadius: 12, padding: "8px 14px", border: `1px solid ${COLORS.border}` }}>
        <Icon name="search" color={COLORS.textLight} size={15} />
        <input placeholder="Search..." style={{ border: "none", background: "transparent", outline: "none", fontSize: 13, color: COLORS.text, width: 160 }} />
      </div>
      <button className="icon-btn-hover" style={{ position: "relative", background: COLORS.bg, border: `1px solid ${COLORS.border}`, borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
        <Icon name="bell" color={COLORS.textMuted} size={17} />
        <span style={{ position: "absolute", top: 6, right: 6, width: 8, height: 8, borderRadius: "50%", background: COLORS.error, border: `2px solid ${COLORS.white}` }} />
      </button>
      <Avatar name="User" size={36} />
    </div>
  </div>
);

// ======================== BRAND PAGES ========================

const BrandDashboard = () => {
  const stats = [
    { label: "Total campaigns", value: "24", icon: "campaign", color: COLORS.accent, bg: "#EDE8F9", sub: "+3 this month" },
    { label: "Active campaigns", value: "8", icon: "trending", color: "#E07070", bg: "#FCEAEA", sub: "2 ending soon" },
    { label: "Budget spent", value: "$42k", icon: "payment", color: COLORS.success, bg: COLORS.successBg, sub: "of $80k total" },
    { label: "Influencers", value: "137", icon: "users", color: COLORS.warning, bg: COLORS.warningBg, sub: "+12 new" },
  ];
  const campaigns = [
    { name: "Spring Collection 2025", status: "Active", budget: "$12,000", influencers: 8, progress: 65 },
    { name: "Summer Glow Campaign", status: "Review", budget: "$8,500", influencers: 4, progress: 40 },
    { name: "Accessories Launch", status: "Draft", budget: "$5,000", influencers: 0, progress: 10 },
  ];
  const statusColors = { Active: { color: COLORS.success, bg: COLORS.successBg }, Review: { color: COLORS.warning, bg: COLORS.warningBg }, Draft: { color: COLORS.textMuted, bg: COLORS.bg } };

  return (
    <div style={{ padding: 28 }}>
      <div style={{ marginBottom: 24 }}>
        <p style={{ fontSize: 14, color: COLORS.textMuted }}>Good morning, Zara Fashion 👋 Here's what's happening today.</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 28 }}>
        {stats.map(s => <StatCard key={s.label} {...s} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.7fr 1fr", gap: 20, marginBottom: 20 }}>
        <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <div style={{ fontWeight: 600, fontSize: 15 }}>Campaign performance</div>
            <Badge label="Last 30 days" />
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end", height: 120 }}>
            {[40, 65, 50, 80, 72, 90, 68, 95, 78, 85, 92, 88].map((v, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <div style={{ width: "100%", borderRadius: "6px 6px 0 0", background: i === 11 ? COLORS.accent : `${COLORS.lavender}60`, height: `${v}%`, transition: "all .5s" }} />
              </div>
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            {["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].map(m => (
              <span key={m} style={{ fontSize: 10, color: COLORS.textLight }}>{m}</span>
            ))}
          </div>
        </div>

        <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Quick actions</div>
          {[
            { label: "Create campaign", icon: "plus", color: COLORS.accent },
            { label: "Find influencers", icon: "search", color: COLORS.success },
            { label: "View analytics", icon: "analytics", color: COLORS.warning },
            { label: "Send contract", icon: "contract", color: "#7B6FA0" },
          ].map(a => (
            <button key={a.label} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 12, border: `1px solid ${COLORS.border}`, background: COLORS.bg, cursor: "pointer", marginBottom: 8, color: COLORS.text, fontSize: 13, fontFamily: "Poppins" }}>
              <div style={{ width: 30, height: 30, borderRadius: 9, background: `${a.color}20`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icon name={a.icon} color={a.color} size={15} />
              </div>
              {a.label}
              <Icon name="arrow" color={COLORS.textLight} size={14} style={{ marginLeft: "auto" }} />
            </button>
          ))}
        </div>
      </div>

      <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <div style={{ fontWeight: 600, fontSize: 15 }}>Recent campaigns</div>
          <Btn variant="ghost">View all</Btn>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
              {["Campaign", "Status", "Budget", "Influencers", "Progress"].map(h => (
                <th key={h} style={{ textAlign: "left", padding: "8px 12px", fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {campaigns.map(c => (
              <tr key={c.name} style={{ borderBottom: `1px solid ${COLORS.bg}` }}>
                <td style={{ padding: "12px 12px", fontSize: 13, fontWeight: 500, color: COLORS.text }}>{c.name}</td>
                <td style={{ padding: "12px 12px" }}><Badge label={c.status} color={statusColors[c.status].color} bg={statusColors[c.status].bg} /></td>
                <td style={{ padding: "12px 12px", fontSize: 13, color: COLORS.textMuted }}>{c.budget}</td>
                <td style={{ padding: "12px 12px", fontSize: 13, color: COLORS.textMuted }}>{c.influencers}</td>
                <td style={{ padding: "12px 12px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ flex: 1, height: 6, borderRadius: 3, background: COLORS.border }}>
                      <div style={{ width: `${c.progress}%`, height: "100%", borderRadius: 3, background: `linear-gradient(90deg, ${COLORS.accent}, ${COLORS.lavender})` }} />
                    </div>
                    <span style={{ fontSize: 11, color: COLORS.textMuted, minWidth: 30 }}>{c.progress}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const InfluencerDiscovery = () => {
  const influencers = [
    { name: "Sophia Zhang", category: "Fashion & Style", followers: "245K", engagement: "4.8%", price: "$800/post", platforms: ["IG", "TT"], verified: true, rating: 4.9 },
    { name: "Aiden Malik", category: "Tech & Gadgets", followers: "182K", engagement: "6.2%", price: "$650/post", platforms: ["YT", "IG"], verified: true, rating: 4.7 },
    { name: "Priya Sharma", category: "Beauty & Skincare", followers: "320K", engagement: "5.5%", price: "$1,100/post", platforms: ["IG", "TT", "YT"], verified: true, rating: 4.9 },
    { name: "Lucas Ferreira", category: "Fitness & Health", followers: "98K", engagement: "7.8%", price: "$400/post", platforms: ["IG", "TT"], verified: false, rating: 4.5 },
    { name: "Emma Christensen", category: "Travel & Lifestyle", followers: "415K", engagement: "3.9%", price: "$1,500/post", platforms: ["IG", "YT"], verified: true, rating: 4.8 },
    { name: "Yusuf Adeyemi", category: "Food & Culture", followers: "67K", engagement: "9.1%", price: "$280/post", platforms: ["TT", "IG"], verified: false, rating: 4.6 },
  ];
  const platformColors = { IG: { bg: "#FCE4EC", color: "#C2185B" }, TT: { bg: "#E8F5E9", color: "#2E7D32" }, YT: { bg: "#FFEBEE", color: "#C62828" } };

  return (
    <div style={{ padding: 28 }}>
      <div style={{ display: "flex", gap: 12, marginBottom: 24, alignItems: "center" }}>
        <div style={{ flex: 1, display: "flex", gap: 8, background: COLORS.white, borderRadius: 14, padding: "10px 16px", border: `1px solid ${COLORS.border}` }}>
          <Icon name="search" color={COLORS.textLight} size={16} />
          <input placeholder="Search influencers by name, niche, or platform..." style={{ flex: 1, border: "none", outline: "none", fontSize: 13, color: COLORS.text, background: "transparent" }} />
        </div>
        <Btn variant="secondary"><Icon name="filter" size={15} />Filters</Btn>
        <Btn><Icon name="users" size={15} color="#fff" />Find matches</Btn>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {["All categories", "Fashion", "Beauty", "Tech", "Travel", "Food", "Fitness"].map((f, i) => (
          <button key={f} style={{ padding: "6px 14px", borderRadius: 20, border: `1px solid ${i === 0 ? COLORS.accent : COLORS.border}`, background: i === 0 ? `${COLORS.accent}15` : COLORS.white, color: i === 0 ? COLORS.accent : COLORS.textMuted, fontSize: 12, cursor: "pointer", fontFamily: "Poppins", fontWeight: i === 0 ? 600 : 400 }}>
            {f}
          </button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
        {influencers.map(inf => (
          <div key={inf.name} style={{ background: COLORS.white, borderRadius: 18, padding: 20, boxShadow: COLORS.cardShadow, transition: "transform .2s", cursor: "pointer" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14 }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <Avatar name={inf.name} size={44} />
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.text }}>{inf.name}</div>
                    {inf.verified && <span style={{ color: COLORS.accent, fontSize: 13 }}>✓</span>}
                  </div>
                  <div style={{ fontSize: 11, color: COLORS.textMuted }}>{inf.category}</div>
                </div>
              </div>
              <button style={{ background: COLORS.bg, border: "none", borderRadius: 10, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
                <Icon name="bookmark" color={COLORS.textLight} size={15} />
              </button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 14 }}>
              {[{ label: "Followers", value: inf.followers }, { label: "Engagement", value: inf.engagement }, { label: "Rating", value: `⭐ ${inf.rating}` }].map(m => (
                <div key={m.label} style={{ background: COLORS.bg, borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.text }}>{m.value}</div>
                  <div style={{ fontSize: 10, color: COLORS.textMuted }}>{m.label}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 6, marginBottom: 14 }}>
              {inf.platforms.map(p => <Badge key={p} label={p} color={platformColors[p]?.color} bg={platformColors[p]?.bg} />)}
            </div>

            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.accent }}>{inf.price}</span>
              <div style={{ display: "flex", gap: 8 }}>
                <Btn variant="secondary" style={{ padding: "6px 12px", fontSize: 12 }}><Icon name="eye" size={13} />View</Btn>
                <Btn style={{ padding: "6px 12px", fontSize: 12 }}>Invite</Btn>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const BrandCampaigns = () => {
  const campaigns = [
    { name: "Spring Collection 2025", status: "Active", budget: "$12,000", used: "$7,800", influencers: 8, deadline: "Mar 30", progress: 65 },
    { name: "Summer Glow Campaign", status: "In Review", budget: "$8,500", used: "$3,400", influencers: 4, deadline: "Apr 15", progress: 40 },
    { name: "Accessories Launch", status: "Draft", budget: "$5,000", used: "$0", influencers: 0, deadline: "May 1", progress: 10 },
    { name: "Holiday Special Edition", status: "Completed", budget: "$20,000", used: "$19,200", influencers: 15, deadline: "Dec 31", progress: 100 },
  ];
  const statusColors = { Active: { c: COLORS.success, bg: COLORS.successBg }, "In Review": { c: COLORS.warning, bg: COLORS.warningBg }, Draft: { c: COLORS.textMuted, bg: COLORS.bg }, Completed: { c: COLORS.accent, bg: "#EDE8F9" } };

  return (
    <div style={{ padding: 28 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <p style={{ fontSize: 14, color: COLORS.textMuted }}>Manage and track all your PR campaigns.</p>
        </div>
        <Btn><Icon name="plus" size={15} color="#fff" />New campaign</Btn>
      </div>

      <div style={{ display: "grid", gap: 14 }}>
        {campaigns.map(c => {
          const sc = statusColors[c.status];
          return (
            <div key={c.name} className="campaign-card-hover" style={{ background: COLORS.white, borderRadius: 18, padding: "20px 24px", boxShadow: COLORS.cardShadow }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ fontWeight: 600, fontSize: 16, color: COLORS.text }}>{c.name}</div>
                    <Badge label={c.status} color={sc.c} bg={sc.bg} />
                  </div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 4 }}>Deadline: {c.deadline} · {c.influencers} influencers</div>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <Btn variant="secondary" style={{ padding: "7px 14px", fontSize: 12 }}>Edit</Btn>
                  <Btn style={{ padding: "7px 14px", fontSize: 12 }}>View details</Btn>
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 16 }}>
                {[{ label: "Total budget", value: c.budget }, { label: "Spent", value: c.used }, { label: "Influencers", value: c.influencers }, { label: "Deadline", value: c.deadline }].map(m => (
                  <div key={m.label} style={{ background: COLORS.bg, borderRadius: 12, padding: "10px 14px" }}>
                    <div style={{ fontSize: 12, color: COLORS.textMuted }}>{m.label}</div>
                    <div style={{ fontSize: 15, fontWeight: 600, color: COLORS.text, marginTop: 2 }}>{m.value}</div>
                  </div>
                ))}
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ flex: 1, height: 7, borderRadius: 4, background: COLORS.border }}>
                  <div style={{ width: `${c.progress}%`, height: "100%", borderRadius: 4, background: `linear-gradient(90deg, ${COLORS.accent}, ${COLORS.lavender})`, transition: "width .5s" }} />
                </div>
                <span style={{ fontSize: 12, color: COLORS.textMuted, minWidth: 35 }}>{c.progress}%</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const MessagesPage = () => {
  const convos = [
    { name: "Priya Sharma", last: "Looking forward to our collaboration!", time: "2m", unread: 2, active: true },
    { name: "Emma Christensen", last: "Can you send the brief?", time: "15m", unread: 0, active: false },
    { name: "Sophia Zhang", last: "Contract signed ✓", time: "1h", unread: 0, active: false },
    { name: "Aiden Malik", last: "Here are the deliverables", time: "3h", unread: 1, active: false },
    { name: "Lucas Ferreira", last: "Payment received, thank you!", time: "1d", unread: 0, active: false },
  ];
  const msgs = [
    { from: "them", text: "Hi! I reviewed the campaign brief and I'm very excited to work on this.", time: "10:02" },
    { from: "me", text: "Great! We'd love to have you. The budget we discussed works?", time: "10:05" },
    { from: "them", text: "Yes, that works perfectly. When do you need the first deliverable?", time: "10:07" },
    { from: "me", text: "By March 15th if possible. We're targeting the spring collection launch.", time: "10:09" },
    { from: "them", text: "Looking forward to our collaboration!", time: "10:12" },
  ];

  return (
    <div style={{ display: "flex", height: "calc(100vh - 65px)", overflow: "hidden" }}>
      <div style={{ width: 280, borderRight: `1px solid ${COLORS.border}`, background: COLORS.white, overflowY: "auto" }}>
        <div style={{ padding: 16 }}>
          <div style={{ display: "flex", gap: 8, background: COLORS.bg, borderRadius: 12, padding: "8px 12px", marginBottom: 12, border: `1px solid ${COLORS.border}` }}>
            <Icon name="search" color={COLORS.textLight} size={15} />
            <input placeholder="Search messages..." style={{ flex: 1, border: "none", background: "transparent", outline: "none", fontSize: 12 }} />
          </div>
          {convos.map(c => (
            <div key={c.name} className="convo-row" style={{ display: "flex", gap: 10, padding: "12px 8px", borderRadius: 12, background: c.active ? `${COLORS.accent}12` : "transparent", cursor: "pointer", marginBottom: 2 }}>
              <Avatar name={c.name} size={40} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <div style={{ fontWeight: c.unread ? 600 : 500, fontSize: 13, color: COLORS.text }}>{c.name}</div>
                  <div style={{ fontSize: 10, color: COLORS.textLight }}>{c.time}</div>
                </div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.last}</div>
              </div>
              {c.unread > 0 && <div style={{ width: 18, height: 18, borderRadius: "50%", background: COLORS.accent, color: "#fff", fontSize: 10, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{c.unread}</div>}
            </div>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", background: COLORS.bg }}>
        <div style={{ padding: "14px 20px", background: COLORS.white, borderBottom: `1px solid ${COLORS.border}`, display: "flex", alignItems: "center", gap: 12 }}>
          <Avatar name="Priya Sharma" size={36} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>Priya Sharma</div>
            <div style={{ fontSize: 12, color: COLORS.success }}>● Online</div>
          </div>
        </div>

        <div style={{ flex: 1, padding: 20, overflowY: "auto", display: "flex", flexDirection: "column", gap: 12 }}>
          {msgs.map((m, i) => (
            <div key={i} style={{ display: "flex", justifyContent: m.from === "me" ? "flex-end" : "flex-start", gap: 8, alignItems: "flex-end" }}>
              {m.from === "them" && <Avatar name="Priya Sharma" size={28} />}
              <div style={{ maxWidth: "65%", background: m.from === "me" ? `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})` : COLORS.white, color: m.from === "me" ? "#fff" : COLORS.text, borderRadius: m.from === "me" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", padding: "10px 14px", fontSize: 13, boxShadow: COLORS.cardShadow }}>
                {m.text}
                <div style={{ fontSize: 10, opacity: 0.7, marginTop: 4, textAlign: "right" }}>{m.time}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ padding: "14px 20px", background: COLORS.white, borderTop: `1px solid ${COLORS.border}` }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center", background: COLORS.bg, borderRadius: 14, padding: "10px 16px", border: `1px solid ${COLORS.border}` }}>
            <input placeholder="Type a message..." style={{ flex: 1, border: "none", background: "transparent", outline: "none", fontSize: 13 }} />
            <Btn style={{ padding: "7px 16px", fontSize: 12 }}>Send</Btn>
          </div>
        </div>
      </div>
    </div>
  );
};

const BrandAnalytics = () => (
  <div style={{ padding: 28 }}>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
      {[{ label: "Total reach", value: "2.4M", icon: "globe", color: COLORS.accent, bg: "#EDE8F9" }, { label: "Engagements", value: "186K", icon: "trending", color: COLORS.success, bg: COLORS.successBg }, { label: "Conversions", value: "4,820", icon: "check", color: COLORS.warning, bg: COLORS.warningBg }, { label: "ROI", value: "340%", icon: "analytics", color: "#C2185B", bg: "#FCE4EC" }].map(s => <StatCard key={s.label} {...s} />)}
    </div>

    <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 20 }}>
      <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
        <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 20 }}>Reach & engagement over time</div>
        <div style={{ display: "flex", gap: 6, alignItems: "flex-end", height: 140 }}>
          {[55, 70, 45, 90, 80, 65, 95, 75, 85, 100, 88, 92].map((v, i) => (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", gap: 3, alignItems: "center", height: "100%" }}>
              <div style={{ width: "100%", borderRadius: "5px 5px 0 0", background: `${COLORS.lavender}50`, height: `${v * 0.7}%` }} />
              <div style={{ width: "100%", borderRadius: "5px 5px 0 0", background: `${COLORS.accent}90`, height: `${v * 0.3}%` }} />
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 16, marginTop: 12 }}>
          <span style={{ fontSize: 12, color: COLORS.textMuted, display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: `${COLORS.lavender}80`, display: "inline-block" }} />Reach</span>
          <span style={{ fontSize: 12, color: COLORS.textMuted, display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: `${COLORS.accent}90`, display: "inline-block" }} />Engagement</span>
        </div>
      </div>

      <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
        <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 18 }}>Platform breakdown</div>
        {[{ p: "Instagram", pct: 52, color: "#C2185B" }, { p: "TikTok", pct: 28, color: COLORS.success }, { p: "YouTube", pct: 15, color: COLORS.error }, { p: "Facebook", pct: 5, color: "#1565C0" }].map(item => (
          <div key={item.p} style={{ marginBottom: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
              <span style={{ fontSize: 13, color: COLORS.text }}>{item.p}</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.text }}>{item.pct}%</span>
            </div>
            <div style={{ height: 7, borderRadius: 4, background: COLORS.border }}>
              <div style={{ width: `${item.pct}%`, height: "100%", borderRadius: 4, background: item.color }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

// ======================== INFLUENCER PAGES ========================

const InfluencerDashboard = () => {
  const stats = [
    { label: "Active campaigns", value: "3", icon: "campaign", color: COLORS.accent, bg: "#EDE8F9", sub: "1 new offer" },
    { label: "Total earnings", value: "$8,400", icon: "payment", color: COLORS.success, bg: COLORS.successBg, sub: "+$1,200 this month" },
    { label: "Applications", value: "12", icon: "bookmark", color: COLORS.warning, bg: COLORS.warningBg, sub: "3 pending" },
    { label: "Profile views", value: "2.1K", icon: "eye", color: "#C2185B", bg: "#FCE4EC", sub: "This week" },
  ];

  return (
    <div style={{ padding: 28 }}>
      <div style={{ background: `linear-gradient(135deg, ${COLORS.accent}22, ${COLORS.lavender}22)`, borderRadius: 20, padding: "20px 24px", marginBottom: 24, border: `1px solid ${COLORS.border}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <Avatar name="Ayla Rahman" size={56} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 18 }}>Ayla Rahman</div>
            <div style={{ fontSize: 13, color: COLORS.textMuted }}>Fashion & Lifestyle · 128K followers</div>
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              <Badge label="Verified" color={COLORS.success} bg={COLORS.successBg} />
              <Badge label="Top Creator" color={COLORS.accent} bg="#EDE8F9" />
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 12, color: COLORS.textMuted }}>Profile completion</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.accent }}>82%</div>
            <div style={{ width: 120, height: 6, borderRadius: 3, background: COLORS.border, marginTop: 4 }}>
              <div style={{ width: "82%", height: "100%", borderRadius: 3, background: `linear-gradient(90deg, ${COLORS.accent}, ${COLORS.lavender})` }} />
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
        {stats.map(s => <StatCard key={s.label} {...s} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 20 }}>
        <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Active campaigns</div>
          {[
            { brand: "Zara Fashion", campaign: "Spring Collection 2025", deadline: "Mar 30", status: "In progress", pay: "$800" },
            { brand: "L'Oréal Paris", campaign: "Glow Up Series", deadline: "Apr 5", status: "Deliverable due", pay: "$1,200" },
            { brand: "Nike Women", campaign: "She Moves Campaign", deadline: "Apr 20", status: "Brief review", pay: "$650" },
          ].map(c => (
            <div key={c.campaign} style={{ display: "flex", gap: 12, padding: "12px 0", borderBottom: `1px solid ${COLORS.bg}`, alignItems: "center" }}>
              <Avatar name={c.brand} size={38} color="#8E7CC3" bg="#EDE8F9" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{c.campaign}</div>
                <div style={{ fontSize: 11, color: COLORS.textMuted }}>{c.brand} · Due {c.deadline}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.accent }}>{c.pay}</div>
                <Badge label={c.status} color={COLORS.warning} bg={COLORS.warningBg} />
              </div>
            </div>
          ))}
        </div>

        <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Followers growth</div>
          <MiniChart data={[62, 70, 68, 80, 76, 90, 88, 95, 100, 98, 105, 128]} color={COLORS.accent} />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            <span style={{ fontSize: 10, color: COLORS.textLight }}>Jan</span>
            <span style={{ fontSize: 10, color: COLORS.textLight }}>Dec</span>
          </div>
          <div style={{ marginTop: 16, padding: "12px", background: COLORS.bg, borderRadius: 12 }}>
            <div style={{ fontSize: 11, color: COLORS.textMuted }}>Current followers</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.text }}>128,400</div>
            <div style={{ fontSize: 12, color: COLORS.success }}>↑ 6.8% this month</div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Opportunities = () => {
  const opportunities = [
    { brand: "Chanel Beauty", campaign: "Elegance Redefined", budget: "$1,500/post", category: "Beauty", deadline: "Apr 10", followers: "100K+", fit: 98 },
    { brand: "Adidas Women", campaign: "She Runs the World", budget: "$900/post", category: "Fitness", deadline: "Apr 20", followers: "50K+", fit: 85 },
    { brand: "Glossier", campaign: "Skin First Campaign", budget: "$700/post", category: "Skincare", deadline: "May 1", followers: "80K+", fit: 91 },
    { brand: "H&M Studio", campaign: "Sustainable Fashion 2025", budget: "$1,100/post", category: "Fashion", deadline: "Apr 30", followers: "120K+", fit: 96 },
  ];

  return (
    <div style={{ padding: 28 }}>
      <div style={{ marginBottom: 20 }}>
        <p style={{ fontSize: 14, color: COLORS.textMuted }}>Campaigns matched to your profile and niche.</p>
      </div>
      <div style={{ display: "grid", gap: 16 }}>
        {opportunities.map(o => (
          <div key={o.campaign} style={{ background: COLORS.white, borderRadius: 18, padding: "20px 24px", boxShadow: COLORS.cardShadow }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
                <Avatar name={o.brand} size={48} />
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, color: COLORS.text }}>{o.campaign}</div>
                  <div style={{ fontSize: 13, color: COLORS.textMuted }}>{o.brand}</div>
                  <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                    <Badge label={o.category} />
                    <Badge label={`${o.followers} required`} color={COLORS.textMuted} bg={COLORS.bg} />
                  </div>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 11, color: COLORS.textMuted }}>Match score</div>
                <div style={{ fontSize: 22, fontWeight: 700, color: o.fit >= 90 ? COLORS.success : COLORS.warning }}>{o.fit}%</div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 16, paddingTop: 14, borderTop: `1px solid ${COLORS.bg}` }}>
              <div style={{ display: "flex", gap: 20 }}>
                <div><span style={{ fontSize: 11, color: COLORS.textMuted }}>Pay</span> <span style={{ fontSize: 14, fontWeight: 700, color: COLORS.accent }}>{o.budget}</span></div>
                <div><span style={{ fontSize: 11, color: COLORS.textMuted }}>Deadline</span> <span style={{ fontSize: 13, fontWeight: 500 }}> {o.deadline}</span></div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <Btn variant="secondary" style={{ padding: "7px 14px", fontSize: 12 }}><Icon name="bookmark" size={13} />Save</Btn>
                <Btn style={{ padding: "7px 16px", fontSize: 12 }}>Apply now</Btn>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const Payments = () => (
  <div style={{ padding: 28 }}>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 24 }}>
      <StatCard label="Total earned" value="$8,400" icon="payment" color={COLORS.success} bg={COLORS.successBg} sub="All time" />
      <StatCard label="Pending" value="$1,950" icon="calendar" color={COLORS.warning} bg={COLORS.warningBg} sub="2 invoices" />
      <StatCard label="Withdrawn" value="$6,450" icon="analytics" color={COLORS.accent} bg="#EDE8F9" sub="To bank account" />
    </div>
    <div style={{ background: COLORS.white, borderRadius: 18, padding: 22, boxShadow: COLORS.cardShadow }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 18 }}>
        <div style={{ fontWeight: 600, fontSize: 15 }}>Transaction history</div>
        <Btn variant="secondary" style={{ fontSize: 12, padding: "7px 14px" }}>Export PDF</Btn>
      </div>
      {[
        { brand: "Zara Fashion", campaign: "Spring Campaign", amount: "+$800", date: "Mar 10", status: "Paid" },
        { brand: "L'Oréal Paris", campaign: "Glow Up Series", amount: "+$1,200", date: "Mar 5", status: "Pending" },
        { brand: "Nike Women", campaign: "She Moves", amount: "+$650", date: "Feb 22", status: "Paid" },
        { brand: "H&M Studio", campaign: "Sustainable Fashion", amount: "+$1,100", date: "Feb 10", status: "Paid" },
      ].map(t => (
        <div key={t.campaign} style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 0", borderBottom: `1px solid ${COLORS.bg}` }}>
          <Avatar name={t.brand} size={38} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{t.campaign}</div>
            <div style={{ fontSize: 11, color: COLORS.textMuted }}>{t.brand} · {t.date}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.success }}>{t.amount}</div>
            <Badge label={t.status} color={t.status === "Paid" ? COLORS.success : COLORS.warning} bg={t.status === "Paid" ? COLORS.successBg : COLORS.warningBg} />
          </div>
        </div>
      ))}
    </div>
  </div>
);

// ======================== LANDING PAGE ========================

// --- Shared marketing chrome (nav + footer) used by Landing, Features, About, Pricing, Contact ---
const MARKETING_LINKS = [
  { id: "features", label: "Features" },
  { id: "about", label: "About" },
  { id: "pricing", label: "Pricing" },
  { id: "contact", label: "Contact" },
];

const MarketingNav = ({ active = "landing", onNavigate, onGetStarted }) => (
  <nav style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 60px", background: COLORS.white, borderBottom: `1px solid ${COLORS.border}`, position: "sticky", top: 0, zIndex: 100 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 9, cursor: "pointer" }} onClick={() => onNavigate("landing")}>
      <div style={{ width: 34, height: 34, borderRadius: 10, background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon name="globe" color="#fff" size={17} />
      </div>
      <span style={{ fontWeight: 700, fontSize: 18, color: COLORS.text }}>Pressly</span>
    </div>
    <div style={{ display: "flex", gap: 28 }}>
      {MARKETING_LINKS.map(l => (
        <button
          key={l.id}
          onClick={() => onNavigate(l.id)}
          className="nav-item"
          style={{ fontSize: 14, color: active === l.id ? COLORS.accent : COLORS.textMuted, textDecoration: "none", fontWeight: active === l.id ? 700 : 500, background: "none", border: "none", cursor: "pointer", padding: "4px 0" }}
        >
          {l.label}
        </button>
      ))}
    </div>
    <div style={{ display: "flex", gap: 10 }}>
      <Btn variant="secondary" onClick={onGetStarted}>Sign in</Btn>
      <Btn onClick={onGetStarted}>Get started free</Btn>
    </div>
  </nav>
);

const MarketingFooter = ({ onNavigate }) => (
  <div style={{ background: COLORS.white, borderTop: `1px solid ${COLORS.border}`, padding: "40px 60px", position: "relative", zIndex: 1 }}>
    <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 24, maxWidth: 1100, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
        <div style={{ width: 28, height: 28, borderRadius: 8, background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon name="globe" color="#fff" size={14} />
        </div>
        <span style={{ fontWeight: 700, fontSize: 15, color: COLORS.text }}>Pressly</span>
        <span style={{ fontSize: 12, color: COLORS.textLight, marginLeft: 8 }}>© 2026 Pressly, Inc.</span>
      </div>
      <div style={{ display: "flex", gap: 24 }}>
        {MARKETING_LINKS.map(l => (
          <button key={l.id} onClick={() => onNavigate(l.id)} style={{ fontSize: 13, color: COLORS.textMuted, background: "none", border: "none", cursor: "pointer", fontWeight: 500 }}>{l.label}</button>
        ))}
      </div>
    </div>
  </div>
);

const LandingPage = ({ onGetStarted, onNavigate }) => (
  <div style={{ minHeight: "100vh", background: COLORS.bg, fontFamily: "Poppins, sans-serif", position: "relative" }}>
    <BackgroundDecor />
    <MarketingNav active="landing" onNavigate={onNavigate} onGetStarted={onGetStarted} />

    {/* Hero */}
    <div style={{ textAlign: "center", padding: "80px 60px 60px", maxWidth: 800, margin: "0 auto", position: "relative", zIndex: 1 }}>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "#EDE8F9", borderRadius: 20, padding: "5px 14px", marginBottom: 24, fontSize: 12, color: COLORS.accent, fontWeight: 600 }}>
        ✨ The smart PR platform for influencer marketing
      </div>
      <h1 style={{ fontSize: 52, fontWeight: 800, color: COLORS.text, lineHeight: 1.15, marginBottom: 20 }}>
        Connect Brands with<br />
        <span style={{ background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>the Right Influencers</span>
      </h1>
      <p style={{ fontSize: 18, color: COLORS.textMuted, lineHeight: 1.7, marginBottom: 36 }}>
        Pressly streamlines PR campaigns, influencer discovery, contracts, and analytics in one elegant platform built for modern brands and creators.
      </p>
      <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
        <Btn style={{ fontSize: 15, padding: "13px 28px" }} onClick={onGetStarted}><Icon name="arrow" color="#fff" size={17} />Start for free</Btn>
        <Btn variant="secondary" style={{ fontSize: 15, padding: "13px 28px" }}>Watch demo</Btn>
      </div>
    </div>

    {/* Features */}
    <div style={{ padding: "60px", background: COLORS.white, position: "relative", zIndex: 1 }}>
      <div style={{ textAlign: "center", marginBottom: 40 }}>
        <h2 style={{ fontSize: 32, fontWeight: 700, color: COLORS.text, marginBottom: 10 }}>Everything you need</h2>
        <p style={{ fontSize: 16, color: COLORS.textMuted }}>Powerful tools for brands and creators alike.</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, maxWidth: 1000, margin: "0 auto" }}>
        {[
          { icon: "campaign", title: "Campaign management", desc: "Create, launch, and track PR campaigns with full budget control and timeline management.", color: COLORS.accent, bg: "#EDE8F9" },
          { icon: "users", title: "Influencer discovery", desc: "Find the perfect creators by niche, followers, engagement rate, location, and more.", color: COLORS.success, bg: COLORS.successBg },
          { icon: "analytics", title: "Performance analytics", desc: "Deep insights into reach, engagement, conversions, and ROI across all campaigns.", color: COLORS.warning, bg: COLORS.warningBg },
          { icon: "message", title: "Secure messaging", desc: "Professional in-platform communication with file sharing and media attachments.", color: "#C2185B", bg: "#FCE4EC" },
          { icon: "contract", title: "Smart contracts", desc: "Generate, sign, and manage contracts digitally — fully legally compliant.", color: "#7B6FA0", bg: "#F0EBF9" },
          { icon: "payment", title: "Payments & invoicing", desc: "Seamless payment flows for influencers with invoice tracking and withdrawal requests.", color: "#1565C0", bg: "#E3F2FD" },
        ].map(f => (
          <div key={f.title} className="feature-card" style={{ background: COLORS.bg, borderRadius: 18, padding: "22px", border: `1px solid ${COLORS.border}` }}>
            <div style={{ width: 44, height: 44, borderRadius: 14, background: f.bg, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
              <Icon name={f.icon} color={f.color} size={22} />
            </div>
            <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 8 }}>{f.title}</div>
            <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>{f.desc}</div>
          </div>
        ))}
      </div>
    </div>

    {/* Role selection CTA */}
    <div style={{ padding: "60px", textAlign: "center", position: "relative", zIndex: 1 }}>
      <h2 style={{ fontSize: 28, fontWeight: 700, marginBottom: 10 }}>Who are you?</h2>
      <p style={{ fontSize: 15, color: COLORS.textMuted, marginBottom: 36 }}>Choose your role to explore the tailored experience.</p>
      <div style={{ display: "flex", gap: 20, justifyContent: "center" }}>
        <div onClick={onGetStarted} className="role-card" style={{ width: 260, background: COLORS.white, borderRadius: 20, padding: 28, border: `2px solid ${COLORS.accent}`, cursor: "pointer", textAlign: "left", boxShadow: COLORS.cardShadow }}>
          <div className="role-card-icon" style={{ width: 50, height: 50, borderRadius: 15, background: "#EDE8F9", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
            <Icon name="portfolio" color={COLORS.accent} size={26} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 6 }}>I'm a Brand</div>
          <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>Launch campaigns, discover creators, and manage your PR strategy.</div>
          <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 5, color: COLORS.accent, fontSize: 13, fontWeight: 600 }}>Get started <Icon name="arrow" color={COLORS.accent} size={14} /></div>
        </div>
        <div onClick={onGetStarted} className="role-card" style={{ width: 260, background: COLORS.white, borderRadius: 20, padding: 28, border: `1px solid ${COLORS.border}`, cursor: "pointer", textAlign: "left" }}>
          <div className="role-card-icon" style={{ width: 50, height: 50, borderRadius: 15, background: COLORS.successBg, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
            <Icon name="user" color={COLORS.success} size={26} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 6 }}>I'm a Creator</div>
          <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>Find brand partnerships, manage applications, and grow your income.</div>
          <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 5, color: COLORS.success, fontSize: 13, fontWeight: 600 }}>Get started <Icon name="arrow" color={COLORS.success} size={14} /></div>
        </div>
      </div>
    </div>

    <MarketingFooter onNavigate={onNavigate} />
  </div>
);

// ======================== MARKETING SUB-PAGES ========================

const FeaturesPage = ({ onGetStarted, onNavigate }) => {
  const brandFeatures = [
    { icon: "campaign", title: "Campaign management", desc: "Create, launch, and track PR campaigns from a single dashboard. Set budgets, timelines, and deliverables, then monitor progress in real time.", color: COLORS.accent, bg: "#EDE8F9" },
    { icon: "users", title: "Influencer discovery", desc: "Filter creators by niche, follower count, engagement rate, audience location, and past brand collaborations to find the right fit fast.", color: COLORS.success, bg: COLORS.successBg },
    { icon: "contract", title: "Smart contracts", desc: "Generate deliverable-based contracts from templates, send for e-signature, and store signed copies with version history.", color: "#7B6FA0", bg: "#F0EBF9" },
    { icon: "payment", title: "Payments & invoicing", desc: "Pay creators on milestones or completion, track invoices, and export spend reports for finance.", color: "#1565C0", bg: "#E3F2FD" },
    { icon: "analytics", title: "Performance analytics", desc: "See reach, engagement, click-through, and ROI per creator and per campaign, with exportable reports for stakeholders.", color: COLORS.warning, bg: COLORS.warningBg },
    { icon: "message", title: "Secure messaging", desc: "Negotiate deliverables and share briefs, assets, and drafts in one thread per collaboration — no more scattered email chains.", color: "#C2185B", bg: "#FCE4EC" },
  ];
  const creatorFeatures = [
    { icon: "star", title: "Curated opportunities", desc: "Get matched with brand campaigns that fit your niche and audience, and apply with one click using your saved portfolio.", color: COLORS.accent, bg: "#EDE8F9" },
    { icon: "portfolio", title: "Portfolio & media kit", desc: "Showcase past collaborations, audience demographics, and content samples in a shareable profile.", color: COLORS.success, bg: COLORS.successBg },
    { icon: "payment", title: "Fast, tracked payments", desc: "Submit invoices, track payment status, and request withdrawals without chasing brands for updates.", color: "#1565C0", bg: "#E3F2FD" },
    { icon: "analytics", title: "Growth analytics", desc: "Understand which content and campaigns perform best so you can pitch brands with data, not guesswork.", color: COLORS.warning, bg: COLORS.warningBg },
    { icon: "message", title: "Direct brand messaging", desc: "Discuss scope and rates directly with brand teams, with full history saved per collaboration.", color: "#C2185B", bg: "#FCE4EC" },
    { icon: "shield", title: "Contract protection", desc: "Every collaboration is backed by a digital contract, so scope, timeline, and payment terms are always clear and enforceable.", color: "#7B6FA0", bg: "#F0EBF9" },
  ];
  const steps = [
    { icon: "user", title: "Create your profile", desc: "Brands set up a company workspace; creators build a portfolio and media kit." },
    { icon: "search", title: "Discover a match", desc: "Brands search creators by audience fit; creators browse open campaign opportunities." },
    { icon: "contract", title: "Agree on terms", desc: "Negotiate in-platform messaging, then generate and e-sign a contract." },
    { icon: "trending", title: "Track & get paid", desc: "Monitor deliverables and performance, then settle payment through the platform." },
  ];
  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg, position: "relative" }}>
      <BackgroundDecor />
      <MarketingNav active="features" onNavigate={onNavigate} onGetStarted={onGetStarted} />

      <div style={{ textAlign: "center", padding: "70px 60px 40px", maxWidth: 760, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <h1 style={{ fontSize: 42, fontWeight: 800, color: COLORS.text, marginBottom: 16, lineHeight: 1.2 }}>Everything both sides of a partnership need</h1>
        <p style={{ fontSize: 16, color: COLORS.textMuted, lineHeight: 1.7 }}>One platform for campaign management, discovery, contracts, payments, and analytics — built separately for brands and for creators.</p>
      </div>

      <div style={{ padding: "20px 60px 10px", position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, maxWidth: 1000, margin: "0 auto 20px" }}>
          <Icon name="portfolio" color={COLORS.accent} size={20} />
          <h2 style={{ fontSize: 22, fontWeight: 700 }}>For Brands</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, maxWidth: 1000, margin: "0 auto" }}>
          {brandFeatures.map(f => (
            <div key={f.title} className="feature-card" style={{ background: COLORS.white, borderRadius: 18, padding: "22px", border: `1px solid ${COLORS.border}` }}>
              <div style={{ width: 44, height: 44, borderRadius: 14, background: f.bg, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
                <Icon name={f.icon} color={f.color} size={22} />
              </div>
              <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 8 }}>{f.title}</div>
              <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>{f.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "40px 60px 10px", position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, maxWidth: 1000, margin: "0 auto 20px" }}>
          <Icon name="user" color={COLORS.success} size={20} />
          <h2 style={{ fontSize: 22, fontWeight: 700 }}>For Creators</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, maxWidth: 1000, margin: "0 auto" }}>
          {creatorFeatures.map(f => (
            <div key={f.title} className="feature-card" style={{ background: COLORS.white, borderRadius: 18, padding: "22px", border: `1px solid ${COLORS.border}` }}>
              <div style={{ width: 44, height: 44, borderRadius: 14, background: f.bg, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
                <Icon name={f.icon} color={f.color} size={22} />
              </div>
              <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 8 }}>{f.title}</div>
              <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>{f.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "50px 60px", background: COLORS.white, marginTop: 40, position: "relative", zIndex: 1 }}>
        <h2 style={{ fontSize: 26, fontWeight: 700, textAlign: "center", marginBottom: 36 }}>How it works</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20, maxWidth: 1000, margin: "0 auto" }}>
          {steps.map((s, i) => (
            <div key={s.title} style={{ textAlign: "center", position: "relative" }}>
              <div style={{ width: 52, height: 52, borderRadius: 16, background: "#EDE8F9", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
                <Icon name={s.icon} color={COLORS.accent} size={24} />
              </div>
              <div style={{ fontSize: 12, color: COLORS.accent, fontWeight: 700, marginBottom: 4 }}>STEP {i + 1}</div>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6 }}>{s.title}</div>
              <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>{s.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "60px", textAlign: "center", position: "relative", zIndex: 1 }}>
        <Btn style={{ fontSize: 15, padding: "13px 28px" }} onClick={onGetStarted}><Icon name="arrow" color="#fff" size={17} />Start for free</Btn>
      </div>

      <MarketingFooter onNavigate={onNavigate} />
    </div>
  );
};

const AboutPage = ({ onGetStarted, onNavigate }) => {
  const stats = [
    { label: "Active brands", value: "1,200+", icon: "portfolio", color: COLORS.accent, bg: "#EDE8F9" },
    { label: "Creators on platform", value: "48,000+", icon: "users", color: COLORS.success, bg: COLORS.successBg },
    { label: "Campaigns run", value: "9,600+", icon: "campaign", color: COLORS.warning, bg: COLORS.warningBg },
    { label: "Paid to creators", value: "$32M+", icon: "payment", color: "#1565C0", bg: "#E3F2FD" },
  ];
  const values = [
    { icon: "shield", title: "Trust by default", desc: "Every collaboration runs through a contract and a tracked payment — no handshake deals, no chasing invoices." },
    { icon: "target", title: "Fit over follower count", desc: "We help brands find creators whose audience actually matches the campaign, not just the biggest number." },
    { icon: "heart", title: "Fair to creators", desc: "Creators set their own rates, see full campaign terms upfront, and get paid on time." },
    { icon: "trending", title: "Decisions from data", desc: "Every dashboard is built so both sides can see what's actually working, not just what shipped." },
  ];
  const timeline = [
    { year: "2022", text: "Pressly started as a spreadsheet-based tool for a single boutique PR agency managing influencer outreach." },
    { year: "2023", text: "Launched publicly as a self-serve platform for brands, with the first version of creator discovery." },
    { year: "2024", text: "Added contracts, in-platform payments, and a dedicated creator-side app." },
    { year: "2026", text: "Now used by brands and creators across 30+ countries to run and get paid for campaigns." },
  ];
  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg, position: "relative" }}>
      <BackgroundDecor />
      <MarketingNav active="about" onNavigate={onNavigate} onGetStarted={onGetStarted} />

      <div style={{ textAlign: "center", padding: "70px 60px 40px", maxWidth: 760, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <h1 style={{ fontSize: 42, fontWeight: 800, color: COLORS.text, marginBottom: 16, lineHeight: 1.2 }}>Built to make influencer marketing fair and trackable</h1>
        <p style={{ fontSize: 16, color: COLORS.textMuted, lineHeight: 1.7 }}>Pressly exists because too many campaigns were run over DMs and spreadsheets, with no contract, no clear metrics, and no guaranteed payment. We built the platform we wished existed.</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, maxWidth: 1000, margin: "0 auto", padding: "20px 60px", position: "relative", zIndex: 1 }}>
        {stats.map(s => <StatCard key={s.label} {...s} />)}
      </div>

      <div style={{ padding: "50px 60px", position: "relative", zIndex: 1 }}>
        <h2 style={{ fontSize: 26, fontWeight: 700, textAlign: "center", marginBottom: 36 }}>What we care about</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 18, maxWidth: 1000, margin: "0 auto" }}>
          {values.map(v => (
            <div key={v.title} className="feature-card" style={{ background: COLORS.white, borderRadius: 18, padding: "22px", border: `1px solid ${COLORS.border}` }}>
              <div style={{ width: 44, height: 44, borderRadius: 14, background: "#EDE8F9", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
                <Icon name={v.icon} color={COLORS.accent} size={22} />
              </div>
              <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 8 }}>{v.title}</div>
              <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>{v.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "10px 60px 60px", position: "relative", zIndex: 1 }}>
        <h2 style={{ fontSize: 26, fontWeight: 700, textAlign: "center", marginBottom: 36 }}>Our story</h2>
        <div style={{ maxWidth: 640, margin: "0 auto", display: "flex", flexDirection: "column", gap: 22 }}>
          {timeline.map(t => (
            <div key={t.year} style={{ display: "flex", gap: 18 }}>
              <div style={{ width: 64, flexShrink: 0, fontWeight: 700, color: COLORS.accent, fontSize: 15 }}>{t.year}</div>
              <div style={{ fontSize: 14, color: COLORS.textMuted, lineHeight: 1.7, paddingBottom: 18, borderBottom: `1px solid ${COLORS.border}`, flex: 1 }}>{t.text}</div>
            </div>
          ))}
        </div>
      </div>

      <MarketingFooter onNavigate={onNavigate} />
    </div>
  );
};

const PricingPage = ({ onGetStarted, onNavigate }) => {
  const [billing, setBilling] = useState("monthly");
  const plans = [
    {
      id: "starter", name: "Starter", audience: "Solo creators & small brands",
      monthly: 0, yearly: 0,
      desc: "Get discovered or run your first campaign.",
      features: ["1 active campaign or profile", "Basic discovery search", "In-platform messaging", "Standard contracts", "Community support"],
      cta: "Start for free", highlight: false,
    },
    {
      id: "growth", name: "Growth", audience: "Growing brands & full-time creators",
      monthly: 79, yearly: 63,
      desc: "For teams running multiple campaigns a month.",
      features: ["Unlimited campaigns", "Advanced discovery filters", "Smart contracts & e-signature", "Payments & invoicing", "Performance analytics", "Priority support"],
      cta: "Start 14-day trial", highlight: true,
    },
    {
      id: "enterprise", name: "Enterprise", audience: "Agencies & large brand teams",
      monthly: null, yearly: null,
      desc: "Custom workflows, seats, and reporting.",
      features: ["Everything in Growth", "Multiple team seats & roles", "Custom reporting & exports", "Dedicated account manager", "SLA-backed support"],
      cta: "Contact sales", highlight: false,
    },
  ];
  const faqs = [
    { q: "Can I switch between Brand and Creator plans?", a: "Your account type is set at signup, but billing plans can be changed anytime from Settings." },
    { q: "Is there a free trial for Growth?", a: "Yes — Growth includes a 14-day free trial, no card required to start." },
    { q: "How does Enterprise pricing work?", a: "Enterprise pricing depends on team size and campaign volume. Our sales team will put together a custom quote." },
    { q: "What happens if I go over my plan's campaign limit?", a: "You'll be prompted to upgrade before launching a new campaign — nothing is paused or deleted." },
  ];
  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg, position: "relative" }}>
      <BackgroundDecor />
      <MarketingNav active="pricing" onNavigate={onNavigate} onGetStarted={onGetStarted} />

      <div style={{ textAlign: "center", padding: "70px 60px 20px", maxWidth: 700, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <h1 style={{ fontSize: 42, fontWeight: 800, color: COLORS.text, marginBottom: 16, lineHeight: 1.2 }}>Simple pricing for both sides</h1>
        <p style={{ fontSize: 16, color: COLORS.textMuted, lineHeight: 1.7, marginBottom: 28 }}>Start free. Upgrade when you're running more than one campaign or collaboration at a time.</p>
        <div style={{ display: "inline-flex", background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 30, padding: 4 }}>
          {["monthly", "yearly"].map(b => (
            <button key={b} onClick={() => setBilling(b)} className="btn-hover" style={{ border: "none", borderRadius: 26, padding: "8px 20px", fontSize: 13, fontWeight: 600, background: billing === b ? `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})` : "transparent", color: billing === b ? "#fff" : COLORS.textMuted }}>
              {b === "monthly" ? "Monthly" : "Yearly · save 20%"}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, maxWidth: 1000, margin: "0 auto", padding: "30px 60px 10px", position: "relative", zIndex: 1 }}>
        {plans.map(p => {
          const price = billing === "monthly" ? p.monthly : p.yearly;
          return (
            <div key={p.id} className="feature-card" style={{ background: COLORS.white, borderRadius: 20, padding: 28, border: p.highlight ? `2px solid ${COLORS.accent}` : `1px solid ${COLORS.border}`, boxShadow: p.highlight ? COLORS.cardShadow : "none", position: "relative", display: "flex", flexDirection: "column" }}>
              {p.highlight && <div style={{ position: "absolute", top: -12, left: 24 }}><Badge label="Most popular" /></div>}
              <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 4 }}>{p.name}</div>
              <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 18 }}>{p.audience}</div>
              <div style={{ marginBottom: 10 }}>
                {price === null ? (
                  <span style={{ fontSize: 28, fontWeight: 800 }}>Custom</span>
                ) : (
                  <>
                    <span style={{ fontSize: 34, fontWeight: 800 }}>${price}</span>
                    <span style={{ fontSize: 13, color: COLORS.textMuted }}>{price === 0 ? " forever" : "/mo"}</span>
                  </>
                )}
              </div>
              <div style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20, lineHeight: 1.6 }}>{p.desc}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24, flex: 1 }}>
                {p.features.map(f => (
                  <div key={f} style={{ display: "flex", alignItems: "flex-start", gap: 8, fontSize: 13, color: COLORS.text }}>
                    <Icon name="check" color={COLORS.success} size={15} />
                    <span>{f}</span>
                  </div>
                ))}
              </div>
              <Btn variant={p.highlight ? "primary" : "secondary"} style={{ justifyContent: "center", width: "100%", padding: "11px" }} onClick={p.id === "enterprise" ? () => onNavigate("contact") : onGetStarted}>{p.cta}</Btn>
            </div>
          );
        })}
      </div>

      <div style={{ padding: "60px", position: "relative", zIndex: 1 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, textAlign: "center", marginBottom: 30 }}>Frequently asked questions</h2>
        <div style={{ maxWidth: 700, margin: "0 auto", display: "flex", flexDirection: "column", gap: 14 }}>
          {faqs.map(f => (
            <div key={f.q} style={{ background: COLORS.white, borderRadius: 14, padding: "16px 20px", border: `1px solid ${COLORS.border}` }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6 }}>{f.q}</div>
              <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>{f.a}</div>
            </div>
          ))}
        </div>
      </div>

      <MarketingFooter onNavigate={onNavigate} />
    </div>
  );
};

const ContactPage = ({ onGetStarted, onNavigate }) => {
  const [form, setForm] = useState({ name: "", email: "", role: "brand", subject: "", message: "" });
  const [sent, setSent] = useState(false);
  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const canSubmit = form.name.trim() && form.email.trim() && form.message.trim();

  const handleSubmit = () => {
    if (!canSubmit) return;
    setSent(true);
  };

  const channels = [
    { icon: "mail", title: "Email us", value: "hello@pressly.io", desc: "General questions & support", color: COLORS.accent, bg: "#EDE8F9" },
    { icon: "message", title: "Live chat", value: "In-app chat", desc: "Mon–Fri, 9am–6pm", color: COLORS.success, bg: COLORS.successBg },
    { icon: "phone", title: "Sales", value: "+1 (555) 010-2040", desc: "For Enterprise plans", color: "#1565C0", bg: "#E3F2FD" },
    { icon: "pin", title: "Office", value: "San Francisco, CA", desc: "By appointment only", color: COLORS.warning, bg: COLORS.warningBg },
  ];

  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg, position: "relative" }}>
      <BackgroundDecor />
      <MarketingNav active="contact" onNavigate={onNavigate} onGetStarted={onGetStarted} />

      <div style={{ textAlign: "center", padding: "70px 60px 30px", maxWidth: 700, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <h1 style={{ fontSize: 42, fontWeight: 800, color: COLORS.text, marginBottom: 16, lineHeight: 1.2 }}>Get in touch</h1>
        <p style={{ fontSize: 16, color: COLORS.textMuted, lineHeight: 1.7 }}>Questions about a plan, a partnership, or something broken? We read every message.</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, maxWidth: 1000, margin: "0 auto", padding: "10px 60px 40px", position: "relative", zIndex: 1 }}>
        {channels.map(c => (
          <div key={c.title} className="feature-card" style={{ background: COLORS.white, borderRadius: 18, padding: 20, border: `1px solid ${COLORS.border}` }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
              <Icon name={c.icon} color={c.color} size={19} />
            </div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>{c.title}</div>
            <div style={{ fontSize: 13, color: COLORS.text, marginTop: 4, fontWeight: 500 }}>{c.value}</div>
            <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>{c.desc}</div>
          </div>
        ))}
      </div>

      <div style={{ maxWidth: 640, margin: "0 auto", padding: "10px 60px 70px", position: "relative", zIndex: 1 }}>
        <div style={{ background: COLORS.white, borderRadius: 22, padding: 32, border: `1px solid ${COLORS.border}`, boxShadow: COLORS.cardShadow }}>
          {sent ? (
            <div style={{ textAlign: "center", padding: "20px 0" }}>
              <div style={{ width: 56, height: 56, borderRadius: 18, background: COLORS.successBg, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
                <Icon name="check" color={COLORS.success} size={26} />
              </div>
              <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 8 }}>Message sent</div>
              <div style={{ fontSize: 14, color: COLORS.textMuted, marginBottom: 20 }}>Thanks, {form.name.split(" ")[0]} — our team will reply to {form.email} within one business day.</div>
              <Btn variant="secondary" onClick={() => { setSent(false); setForm({ name: "", email: "", role: "brand", subject: "", message: "" }); }}>Send another message</Btn>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ display: "flex", gap: 14 }}>
                <div style={{ flex: 1 }}>
                  <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>Full name</label>
                  <input value={form.name} onChange={e => update("name", e.target.value)} placeholder="Your name" style={{ width: "100%", marginTop: 6, padding: "11px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", background: COLORS.bg, color: COLORS.text }} />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>Email</label>
                  <input value={form.email} onChange={e => update("email", e.target.value)} type="email" placeholder="you@example.com" style={{ width: "100%", marginTop: 6, padding: "11px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", background: COLORS.bg, color: COLORS.text }} />
                </div>
              </div>
              <div>
                <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>I am a...</label>
                <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
                  {[{ id: "brand", label: "Brand" }, { id: "influencer", label: "Creator" }, { id: "other", label: "Other" }].map(r => (
                    <button key={r.id} onClick={() => update("role", r.id)} className="btn-hover" style={{ flex: 1, padding: "9px", borderRadius: 12, fontSize: 13, fontWeight: 600, border: `1.5px solid ${form.role === r.id ? COLORS.accent : COLORS.border}`, background: form.role === r.id ? "#EDE8F9" : COLORS.white, color: form.role === r.id ? COLORS.accent : COLORS.textMuted }}>{r.label}</button>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>Subject</label>
                <input value={form.subject} onChange={e => update("subject", e.target.value)} placeholder="What's this about?" style={{ width: "100%", marginTop: 6, padding: "11px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", background: COLORS.bg, color: COLORS.text }} />
              </div>
              <div>
                <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>Message</label>
                <textarea value={form.message} onChange={e => update("message", e.target.value)} placeholder="How can we help?" rows={5} style={{ width: "100%", marginTop: 6, padding: "11px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", background: COLORS.bg, color: COLORS.text, resize: "vertical", fontFamily: "inherit" }} />
              </div>
              <Btn style={{ justifyContent: "center", padding: "12px", opacity: canSubmit ? 1 : 0.5 }} onClick={handleSubmit}>Send message</Btn>
            </div>
          )}
        </div>
      </div>

      <MarketingFooter onNavigate={onNavigate} />
    </div>
  );
};

// ======================== AUTH PAGES ========================

const AuthPage = ({ onLogin }) => {
  const [mode, setMode] = useState("login");
  const [role, setRole] = useState(null);

  if (mode === "register" && !role) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: COLORS.bg, position: "relative" }}>
        <BackgroundDecor />
        <div style={{ width: 520, background: COLORS.white, borderRadius: 24, padding: 40, boxShadow: "0 8px 40px rgba(143,124,195,0.15)", position: "relative", zIndex: 1 }}>
          <div style={{ textAlign: "center", marginBottom: 32 }}>
            <div style={{ fontWeight: 700, fontSize: 22, color: COLORS.text }}>Join Pressly</div>
            <div style={{ fontSize: 14, color: COLORS.textMuted, marginTop: 6 }}>Select your account type to continue</div>
          </div>
          <div style={{ display: "flex", gap: 16 }}>
            {[
              { id: "brand", label: "Brand", desc: "Launch campaigns and find creators", icon: "portfolio", color: COLORS.accent, bg: "#EDE8F9" },
              { id: "influencer", label: "Creator", desc: "Find brand deals and grow income", icon: "user", color: COLORS.success, bg: COLORS.successBg },
            ].map(r => (
              <div key={r.id} onClick={() => setRole(r.id)} className="role-card" style={{ flex: 1, background: COLORS.bg, border: `2px solid ${COLORS.border}`, borderRadius: 18, padding: 24, cursor: "pointer", textAlign: "center" }}>
                <div className="role-card-icon" style={{ width: 56, height: 56, borderRadius: 16, background: r.bg, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
                  <Icon name={r.icon} color={r.color} size={28} />
                </div>
                <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 6 }}>{r.label}</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, lineHeight: 1.5 }}>{r.desc}</div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: "center", marginTop: 20 }}>
            <button onClick={() => setMode("login")} style={{ color: COLORS.accent, fontSize: 13, background: "none", border: "none", cursor: "pointer" }}>Already have an account? Sign in</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: COLORS.bg, position: "relative" }}>
      <BackgroundDecor />
      <div style={{ width: 420, background: COLORS.white, borderRadius: 24, padding: 40, boxShadow: "0 8px 40px rgba(143,124,195,0.15)", position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ width: 44, height: 44, borderRadius: 14, background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
            <Icon name="globe" color="#fff" size={22} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 22 }}>{mode === "login" ? "Welcome back" : "Create account"}</div>
          <div style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 5 }}>Sign {mode === "login" ? "in" : "up"} to Pressly{role ? ` as a ${role}` : ""}</div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {mode === "register" && (
            <div>
              <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>Full name</label>
              <input placeholder="Your name" style={{ width: "100%", marginTop: 6, padding: "11px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", background: COLORS.bg, color: COLORS.text }} />
            </div>
          )}
          <div>
            <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>Email</label>
            <input type="email" placeholder="you@example.com" style={{ width: "100%", marginTop: 6, padding: "11px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", background: COLORS.bg, color: COLORS.text }} />
          </div>
          <div>
            <label style={{ fontSize: 12, color: COLORS.textMuted, fontWeight: 500 }}>Password</label>
            <input type="password" placeholder="••••••••" style={{ width: "100%", marginTop: 6, padding: "11px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", background: COLORS.bg, color: COLORS.text }} />
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
          {mode === "login" && (
            <>
              <Btn style={{ flex: 1, justifyContent: "center", padding: "11px", fontSize: 14 }} onClick={() => onLogin("brand")}>Sign in as Brand</Btn>
              <Btn variant="secondary" style={{ flex: 1, justifyContent: "center", padding: "11px", fontSize: 14 }} onClick={() => onLogin("influencer")}>Sign in as Creator</Btn>
            </>
          )}
          {mode === "register" && (
            <Btn style={{ flex: 1, justifyContent: "center", padding: "11px", fontSize: 14 }} onClick={() => onLogin(role || "brand")}>Create account</Btn>
          )}
        </div>

        <div style={{ textAlign: "center", marginTop: 18, fontSize: 13, color: COLORS.textMuted }}>
          {mode === "login" ? (
            <span>Don't have an account? <button onClick={() => setMode("register")} style={{ color: COLORS.accent, background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}>Register</button></span>
          ) : (
            <span>Already registered? <button onClick={() => { setMode("login"); setRole(null); }} style={{ color: COLORS.accent, background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}>Sign in</button></span>
          )}
        </div>
      </div>
    </div>
  );
};

// ======================== MAIN APP ========================

export default function App() {
  const [screen, setScreen] = useState("landing"); // landing | auth | brand | influencer
  const [role, setRole] = useState(null);
  const [page, setPage] = useState("dashboard");

  const handleLogin = (selectedRole) => {
    setRole(selectedRole);
    setScreen(selectedRole);
    setPage("dashboard");
  };

  const handleLogout = () => {
    setScreen("landing");
    setRole(null);
    setPage("dashboard");
  };

  if (["landing", "features", "about", "pricing", "contact"].includes(screen)) {
    const marketingProps = { onGetStarted: () => setScreen("auth"), onNavigate: setScreen };
    return (
      <>
        <style>{css}</style>
        {screen === "landing" && <LandingPage {...marketingProps} />}
        {screen === "features" && <FeaturesPage {...marketingProps} />}
        {screen === "about" && <AboutPage {...marketingProps} />}
        {screen === "pricing" && <PricingPage {...marketingProps} />}
        {screen === "contact" && <ContactPage {...marketingProps} />}
      </>
    );
  }

  if (screen === "auth") {
    return (
      <>
        <style>{css}</style>
        <AuthPage onLogin={handleLogin} />
      </>
    );
  }

  const isBrand = role === "brand";
  const pageTitle = {
    dashboard: "Dashboard", campaigns: "Campaigns", discovery: "Influencer Discovery",
    messages: "Messages", contracts: "Contracts", analytics: "Analytics", calendar: "Calendar",
    settings: "Settings", opportunities: "Opportunities", collaborations: "Collaborations",
    applications: "Applications", portfolio: "Portfolio", payments: "Payments", reviews: "Reviews",
  }[page] || "Dashboard";

  const renderPage = () => {
    if (isBrand) {
      if (page === "dashboard") return <BrandDashboard />;
      if (page === "campaigns") return <BrandCampaigns />;
      if (page === "discovery") return <InfluencerDiscovery />;
      if (page === "messages") return <MessagesPage />;
      if (page === "analytics") return <BrandAnalytics />;
    } else {
      if (page === "dashboard") return <InfluencerDashboard />;
      if (page === "opportunities") return <Opportunities />;
      if (page === "messages") return <MessagesPage />;
      if (page === "payments") return <Payments />;
      if (page === "analytics") return <BrandAnalytics />;
    }
    return (
      <div style={{ padding: 40, textAlign: "center" }}>
        <div style={{ width: 64, height: 64, borderRadius: 20, background: "#EDE8F9", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
          <Icon name="dashboard" color={COLORS.accent} size={28} />
        </div>
        <div style={{ fontWeight: 600, fontSize: 18, marginBottom: 8 }}>{pageTitle}</div>
        <div style={{ fontSize: 14, color: COLORS.textMuted }}>This section is ready to be built. Select another page from the sidebar.</div>
      </div>
    );
  };

  return (
    <>
      <style>{css}</style>
      <div style={{ display: "flex", minHeight: "100vh", position: "relative" }}>
        <div style={{ position: "fixed", inset: 0, zIndex: 0, opacity: 0.5 }}><BackgroundDecor /></div>
        <Sidebar role={role} page={page} setPage={setPage} onLogout={handleLogout} />
        <div style={{ marginLeft: 220, flex: 1, display: "flex", flexDirection: "column", minHeight: "100vh", position: "relative", zIndex: 1 }}>
          <Topbar title={pageTitle} />
          <div style={{ flex: 1, overflowY: "auto", background: "transparent" }}>
            {renderPage()}
          </div>
        </div>
      </div>
    </>
  );
}
