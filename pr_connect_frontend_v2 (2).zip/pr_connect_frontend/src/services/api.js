const BASE=import.meta.env.VITE_API_BASE_URL||'http://localhost:8000/api';
export const api={baseUrl:BASE, async request(path,options={}){const r=await fetch(`${BASE}${path}`,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options}); if(!r.ok) throw new Error(`API ${r.status}`); return r.json();}};
export const mockRecommendation=(creators,criteria)=>creators.map((c,i)=>({...c,score:Math.max(60,96-i*4)})).sort((a,b)=>b.score-a.score);
export const mockTrustScore=c=>Math.round((c.engagement*5)+(c.rating*12)+((c.verified?1:0)*18)+Math.min(c.followers/10000,20)+20);
export default api;
