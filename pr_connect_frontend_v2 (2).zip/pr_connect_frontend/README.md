# PR Connect — Complete FYP Frontend

A responsive React/Vite frontend for an Influencer–Brand Collaboration & Marketing Analytics platform.

## Run
```bash
npm install
npm run dev
```
Build verification:
```bash
npm run build
```

## Demo accounts
No credentials are required. Choose **Brand Demo** or **Creator Demo** on the auth screen.

## Included workflows
- Brand + Creator role dashboards
- Campaign creation/editing/status workflow
- Influencer discovery with search/category/budget/availability filters
- AI-style recommendation scoring (mock service, backend-ready)
- Trust / scam-risk scoring with explainable factors
- Negotiation chat with offer + counter-offer history
- Contract generation + PDF download using jsPDF
- Campaign analytics with interactive charts
- Creator earnings and payment states
- Two-sided rating/review workflow
- Notifications, saved creators, calendar, portfolio
- Settings with theme toggle and notification preferences
- Responsive mobile sidebar/drawer and animated UI
- localStorage mock persistence
- API service abstraction ready for Django/Node integration

## Backend integration
Set `VITE_API_BASE_URL` to your Django API. Replace mock service methods in `src/services/api.js` with fetch/axios calls. Keep payment secret credentials server-side only.

## Architecture
Presentation: React components/routes
Application: service layer + mock domain logic
Data: localStorage mock repository; replace with API calls later

## Design
Lilac/lavender/purple foundation with selective rose, plum, orchid, mint and amber accents. Typography uses Plus Jakarta Sans + DM Serif Display for editorial headings.
