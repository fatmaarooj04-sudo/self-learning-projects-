# Arooj's Portfolio — Interactive House

A redesigned, walk-through-a-house portfolio. Move your mouse to look around
each room in 3D, use the side arrows (or dots) to walk to the next room, and
click any glowing hotspot to open that section.

## Run
1. Install Node.js LTS.
2. Open this folder in VS Code / your terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite.

## What's new in this redesign
- New "Golden Hour" color theme (brass / walnut / sage) instead of the old
  pastel-cartoon palette, with a new font pairing: **Fraunces** (headings),
  **Manrope** (body) and **JetBrains Mono** (labels/eyebrows).
- A soft animated 3D-ish background (drifting gradient mesh + rising motes)
  and a lantern-glow that follows your cursor (`Background3D.jsx`, `LanternCursor.jsx`).
- The room itself tilts gently with your mouse (CSS 3D perspective in
  `.tilt` / `.room-scene`, driven by `hooks/useParallax.js`), and furniture
  is layered on 3 depth planes so it parallaxes as you move — closer to an
  actual walk-through-a-house feeling instead of a flat cartoon scene.
- Two rooms — **Living Room** and **Study Room** — connect through animated
  "walk" transitions via the arrow buttons / dots (`components/House.jsx`,
  `components/scenes/*`).
- **About Me** is now three separately-styled, click-to-reveal sections
  (`components/AboutContent.jsx`):
  - **Personal** — an ID-card style block with name, location, address, email, phone.
  - **Education** — a vertical stepper: KIPS College (Pre-Medical) → University
    of Lahore, BSSE, Final Year.
  - **Experience** — the same experience info, shown as flip cards (hover /
    tap to flip and read the description) for a distinctly different style.
- Every button/hotspot has hover, active and keyboard-focus states, and the
  whole layout is responsive down to mobile (see the `@media` rules at the
  bottom of `styles/global.css`).
- `prefers-reduced-motion` is respected — animations are disabled for people
  who've asked their OS to reduce motion.

## Personalise it
Edit `src/data/portfolio.js` (name, location, address, email, phone,
education, experience, skills, projects, achievements) and
`src/data/rooms.js` (which hotspot appears in which room). Note: only a
city-level location is filled in by default rather than a precise street
address, for privacy/safety — change `personal.address` if you'd rather show
more.

## Stack
- React + Vite
- JSX
- CSS (no framework — custom design system via CSS variables)
- Motion (framer-motion)
- Lucide React

## Next full-stack phases
After the frontend works, add a Django REST API and PostgreSQL. Move
projects, experience, achievements and contact messages into the database.
Add admin authentication and CRUD after the public API works.
