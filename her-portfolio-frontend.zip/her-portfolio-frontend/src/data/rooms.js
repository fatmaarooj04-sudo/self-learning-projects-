export const rooms = [
  {
    id: "living",
    name: "Living Room",
    tag: "Golden Hour",
    hotspots: [
      { key: "about", icon: "User", label: "About Me" },
      { key: "skills", icon: "Layers", label: "Skills" },
      { key: "contact", icon: "Mail", label: "Say Hello" },
    ],
  },
  {
    id: "study",
    name: "Study Room",
    tag: "Quiet Hours",
    hotspots: [
      { key: "projects", icon: "FolderKanban", label: "Projects" },
      { key: "achievements", icon: "Award", label: "Achievements" },
    ],
  },
];
