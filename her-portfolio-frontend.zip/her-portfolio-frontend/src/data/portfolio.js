// Edit the values below to personalise the site further.
// NOTE: for personal safety, only a city-level location is shown publicly
// instead of a full street address. Swap `address` if you're comfortable
// sharing more.

export const personal = {
  name: "Arooj Fatima",
  role: "Software Engineer · Final Year BSSE Student",
  location: "Lahore, Punjab, Pakistan",
  address: "Lahore, Punjab, Pakistan",
  email: "arooj.fatima@example.com",
  phone: "+92 3XX XXXXXXX",
  bio: "I'm a Software Engineering student who likes building things that feel a little more human than the average interface — part logic, part craft. When I'm not writing code, I'm sketching out UI ideas or reorganising my bookshelf (digitally and literally).",
};

export const education = [
  {
    id: "uni",
    level: "University",
    institute: "University of Lahore (UOL)",
    program: "BS Software Engineering (BSSE)",
    status: "Final Year",
    period: "2022 — 2026",
    note: "Coursework across frontend, backend, databases and software design, with hands-on project work each semester.",
  },
  {
    id: "college",
    level: "College",
    institute: "KIPS College",
    program: "Pre-Medical (FSc)",
    status: "Completed",
    period: "2020 — 2022",
    note: "Built a strong analytical foundation before pivoting toward software engineering.",
  },
];

export const experience = [
  {
    company: "Nishat Mills Limited",
    role: "IT Intern",
    period: "Internship",
    description:
      "Worked alongside the IT department, getting hands-on with real enterprise software and technology workflows.",
  },
  {
    company: "CodeAlpha",
    role: "Development Intern",
    period: "Internship",
    description:
      "Built practical, client-style projects end-to-end, from planning through implementation.",
  },
];

export const achievements = [
  {
    title: "Essay & Speech Writing",
    date: "Academic competitions",
    description: "Recognition in essay and speech writing competitions.",
    icon: "Trophy",
  },
  {
    title: "University Publication",
    date: "University of Lahore",
    description: "Published writing through university publication activities.",
    icon: "BookOpenText",
  },
  {
    title: "Internship Experience",
    date: "Professional",
    description: "Built practical, real-world experience through IT and development internships.",
    icon: "Briefcase",
  },
];

export const projects = [
  {
    id: 1,
    title: "CareShare",
    description:
      "Mental wellness platform with mood tracking, journaling and recovery-focused features.",
    technologies: ["React", "Python", "PostgreSQL"],
  },
  {
    id: 2,
    title: "Letters to Future Me",
    description: "Animated letter app for writing notes to your future self.",
    technologies: ["React", "JSX", "CSS"],
  },
  {
    id: 3,
    title: "BrandConnect",
    description: "A platform concept connecting brands with influencers.",
    technologies: ["React", "Django", "PostgreSQL"],
  },
  {
    id: 4,
    title: "Tourism Management System",
    description: "Database-focused tourism management project.",
    technologies: ["SQL", "Database Design"],
  },
];

export const skills = [
  { name: "React", category: "Frontend", icon: "Atom" },
  { name: "JavaScript", category: "Frontend", icon: "Braces" },
  { name: "Python", category: "Backend", icon: "Terminal" },
  { name: "Django", category: "Backend", icon: "Server" },
  { name: "PostgreSQL", category: "Database", icon: "Database" },
  { name: "UI / UX", category: "Design", icon: "PenTool" },
  { name: "Git & GitHub", category: "Tools", icon: "GitBranch" },
  { name: "REST APIs", category: "Backend", icon: "Waypoints" },
  { name: "Figma", category: "Design", icon: "Palette" },
  { name: "Problem Solving", category: "Core", icon: "Lightbulb" },
];
