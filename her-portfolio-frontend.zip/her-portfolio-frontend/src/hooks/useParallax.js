import { useEffect, useRef } from "react";

/**
 * Tracks the pointer position across a container and writes it straight to
 * CSS custom properties (--mx / --my, range -1..1) via a rAF loop instead of
 * React state, so the parallax + lantern-glow effects stay smooth (60fps)
 * without re-rendering the component tree on every pixel of movement.
 */
export default function useParallax(ref) {
  const target = useRef({ x: 0, y: 0 });
  const current = useRef({ x: 0, y: 0 });
  const raf = useRef(null);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const handleMove = (e) => {
      const rect = node.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      target.current.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      target.current.y = ((clientY - rect.top) / rect.height) * 2 - 1;
      node.style.setProperty("--px", `${clientX - rect.left}px`);
      node.style.setProperty("--py", `${clientY - rect.top}px`);
    };

    const handleLeave = () => {
      target.current.x = 0;
      target.current.y = 0;
    };

    const tick = () => {
      current.current.x += (target.current.x - current.current.x) * 0.06;
      current.current.y += (target.current.y - current.current.y) * 0.06;
      node.style.setProperty("--mx", current.current.x.toFixed(4));
      node.style.setProperty("--my", current.current.y.toFixed(4));
      raf.current = requestAnimationFrame(tick);
    };

    node.addEventListener("mousemove", handleMove);
    node.addEventListener("mouseleave", handleLeave);
    node.addEventListener("touchmove", handleMove, { passive: true });
    raf.current = requestAnimationFrame(tick);

    return () => {
      node.removeEventListener("mousemove", handleMove);
      node.removeEventListener("mouseleave", handleLeave);
      node.removeEventListener("touchmove", handleMove);
      cancelAnimationFrame(raf.current);
    };
  }, [ref]);
}
