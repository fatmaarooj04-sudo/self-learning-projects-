import React, { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Menu, X, ArrowDownRight } from "lucide-react";
import House from "./components/House";
import Modal from "./components/Modal";
import AboutContent from "./components/AboutContent";
import ContactForm from "./components/ContactForm";
import { SkillsGrid, ProjectsGrid, AchievementsGrid } from "./components/SectionGrids";
import Background3D from "./components/Background3D";
import { personal } from "./data/portfolio";

const sections = {
  about: { title: "About Me", eyebrow: "WHO LIVES HERE", content: <AboutContent /> },
  skills: { title: "What's On My Desk", eyebrow: "TOOLS & CRAFT", content: <SkillsGrid /> },
  projects: { title: "Things I've Built", eyebrow: "THE BOOKSHELF", content: <ProjectsGrid /> },
  achievements: {
    title: "Achievements",
    eyebrow: "ON THE WALL",
    content: <AchievementsGrid />,
  },
  contact: { title: "Let's Work Together", eyebrow: "THE FRONT DOOR", content: <ContactForm /> },
};

export default function App() {
  const [entered, setEntered] = useState(false);
  const [modal, setModal] = useState(null);
  const [menu, setMenu] = useState(false);

  const open = (key) => {
    setModal(key);
    setMenu(false);
  };

  return (
    <main>
      {!entered ? (
        <motion.section
          className="landing"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Background3D />
          <p className="eyebrow">A LITTLE DIGITAL HOME</p>
          <h1>{personal.name.split(" ")[0].toUpperCase()}</h1>
          <h2>{personal.role}</h2>
          <p className="tagline">
            I design.
            <br />
            I build.
            <br />
            I keep the lamp on.
          </p>
          <button className="enter" onClick={() => setEntered(true)}>
            Step inside <ArrowDownRight size={16} />
          </button>
          <small>Move your mouse once you're in ↓</small>
        </motion.section>
      ) : (
        <motion.section
          className="app"
          initial={{ opacity: 0, scale: 1.02 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <header>
            <b className="brand">{personal.name}</b>
            <nav>
              <button onClick={() => setMenu(!menu)} aria-label="Toggle menu">
                {menu ? <X size={18} /> : <Menu size={18} />}
              </button>
            </nav>
          </header>

          {menu && (
            <motion.div
              className="mobile-menu"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              {Object.keys(sections).map((k) => (
                <button key={k} onClick={() => open(k)}>
                  {sections[k].title}
                </button>
              ))}
            </motion.div>
          )}

          <House onOpen={open} />

          <AnimatePresence>
            {modal && (
              <Modal
                title={sections[modal].title}
                eyebrow={sections[modal].eyebrow}
                onClose={() => setModal(null)}
              >
                {sections[modal].content}
              </Modal>
            )}
          </AnimatePresence>
        </motion.section>
      )}
    </main>
  );
}
