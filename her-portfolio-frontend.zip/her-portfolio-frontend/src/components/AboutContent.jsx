import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  User,
  MapPin,
  Home as HomeIcon,
  Mail,
  Phone,
  GraduationCap,
  CircleDot,
  Briefcase,
} from "lucide-react";
import { personal, education, experience } from "../data/portfolio";

const tabs = [
  { key: "personal", label: "Personal" },
  { key: "education", label: "Education" },
  { key: "experience", label: "Experience" },
];

export default function AboutContent() {
  const [tab, setTab] = useState("personal");

  return (
    <div className="about-wrap">
      <p className="about-bio">{personal.bio}</p>

      <div className="tab-row" role="tablist" aria-label="About Arooj">
        {tabs.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            className={`tab-btn ${tab === t.key ? "active" : ""}`}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {tab === "personal" && (
          <motion.div
            key="personal"
            className="panel panel-personal"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3 }}
          >
            <div className="id-card">
              <div className="id-avatar">
                <User size={30} strokeWidth={1.5} />
              </div>
              <div className="id-name">{personal.name}</div>
              <div className="id-role">{personal.role}</div>
            </div>
            <ul className="detail-list">
              <li>
                <MapPin size={16} /> <span>{personal.location}</span>
              </li>
              <li>
                <HomeIcon size={16} /> <span>{personal.address}</span>
              </li>
              <li>
                <Mail size={16} /> <span>{personal.email}</span>
              </li>
              <li>
                <Phone size={16} /> <span>{personal.phone}</span>
              </li>
            </ul>
          </motion.div>
        )}

        {tab === "education" && (
          <motion.div
            key="education"
            className="panel panel-education"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3 }}
          >
            <div className="edu-track">
              {education.map((e, i) => (
                <div className="edu-step" key={e.id}>
                  <div className="edu-node">
                    <GraduationCap size={16} />
                  </div>
                  {i < education.length - 1 && <div className="edu-line" />}
                  <div className="edu-body">
                    <span className={`edu-status ${e.status === "Final Year" ? "current" : ""}`}>
                      {e.status}
                    </span>
                    <h4>{e.institute}</h4>
                    <p className="edu-program">{e.program}</p>
                    <p className="edu-period">{e.period}</p>
                    <p className="edu-note">{e.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {tab === "experience" && (
          <motion.div
            key="experience"
            className="panel panel-experience"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flip-grid">
              {experience.map((e) => (
                <div className="flip-card" key={e.company} tabIndex={0}>
                  <div className="flip-inner">
                    <div className="flip-front">
                      <Briefcase size={22} strokeWidth={1.5} />
                      <h4>{e.role}</h4>
                      <p>{e.company}</p>
                      <span className="flip-hint">
                        <CircleDot size={12} /> hover / tap
                      </span>
                    </div>
                    <div className="flip-back">
                      <span className="flip-period">{e.period}</span>
                      <p>{e.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
