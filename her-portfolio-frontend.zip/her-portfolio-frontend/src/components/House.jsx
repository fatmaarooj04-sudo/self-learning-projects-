import React, { useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  User,
  Layers,
  Mail,
  FolderKanban,
  Award,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import useParallax from "../hooks/useParallax";
import Background3D from "./Background3D";
import LanternCursor from "./LanternCursor";
import LivingRoomScene from "./scenes/LivingRoomScene";
import StudyRoomScene from "./scenes/StudyRoomScene";
import { rooms } from "../data/rooms";

const iconMap = { User, Layers, Mail, FolderKanban, Award };

const slideVariants = {
  enter: (dir) => ({ opacity: 0, x: dir > 0 ? 90 : -90, rotateY: dir > 0 ? -10 : 10 }),
  center: { opacity: 1, x: 0, rotateY: 0 },
  exit: (dir) => ({ opacity: 0, x: dir > 0 ? -90 : 90, rotateY: dir > 0 ? 10 : -10 }),
};

export default function House({ onOpen }) {
  const containerRef = useRef(null);
  useParallax(containerRef);
  const [index, setIndex] = useState(0);
  const [dir, setDir] = useState(1);

  const room = rooms[index];
  const go = (delta) => {
    setDir(delta);
    setIndex((i) => (i + delta + rooms.length) % rooms.length);
  };

  return (
    <div className="house" ref={containerRef}>
      <Background3D />
      <LanternCursor />

      <div className="stage">
        <div className="tilt">
          <AnimatePresence mode="wait" custom={dir}>
            <motion.div
              key={room.id}
              className="room-scene"
              custom={dir}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            >
              {room.id === "living" ? <LivingRoomScene /> : <StudyRoomScene />}

              {room.hotspots.map((h) => {
                const Icon = iconMap[h.icon];
                return (
                  <motion.button
                    key={h.key}
                    className={`hotspot hotspot-${h.key}`}
                    whileHover={{ scale: 1.07, y: -5 }}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => onOpen(h.key)}
                    aria-label={h.label}
                  >
                    <span className="hotspot-ring" />
                    <span className="hotspot-icon">
                      <Icon size={18} strokeWidth={1.75} />
                    </span>
                    <b>{h.label}</b>
                  </motion.button>
                );
              })}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <button className="nav-arrow nav-prev" onClick={() => go(-1)} aria-label="Previous room">
        <ChevronLeft size={20} />
      </button>
      <button className="nav-arrow nav-next" onClick={() => go(1)} aria-label="Next room">
        <ChevronRight size={20} />
      </button>

      <div className="room-index">
        <span className="ri-tag">{room.tag}</span>
        <span className="ri-name">{room.name}</span>
        <span className="ri-count">
          {String(index + 1).padStart(2, "0")} / {String(rooms.length).padStart(2, "0")}
        </span>
      </div>

      <div className="room-dots">
        {rooms.map((r, i) => (
          <button
            key={r.id}
            className={`dot ${i === index ? "active" : ""}`}
            onClick={() => {
              setDir(i > index ? 1 : -1);
              setIndex(i);
            }}
            aria-label={`Go to ${r.name}`}
          />
        ))}
      </div>
    </div>
  );
}
