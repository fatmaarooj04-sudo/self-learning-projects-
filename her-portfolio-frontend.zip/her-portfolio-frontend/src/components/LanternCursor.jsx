import React from "react";

export default function LanternCursor() {
  return <div className="lantern" aria-hidden="true" />;
}
