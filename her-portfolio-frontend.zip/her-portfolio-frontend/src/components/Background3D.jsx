import React, { useMemo } from "react";

// A handful of softly glowing motes that drift upward and sway sideways,
// each nudged slightly by the cursor for a subtle sense of depth.
export default function Background3D() {
  const motes = useMemo(
    () =>
      Array.from({ length: 22 }, (_, i) => ({
        id: i,
        left: Math.round(Math.random() * 100),
        size: (Math.random() * 3 + 1.5).toFixed(1),
        duration: (Math.random() * 14 + 14).toFixed(1),
        delay: (Math.random() * -20).toFixed(1),
        depth: (Math.random() * 0.6 + 0.2).toFixed(2),
      })),
    []
  );

  return (
    <div className="bg3d" aria-hidden="true">
      <div className="bg3d-mesh bg3d-mesh--one" />
      <div className="bg3d-mesh bg3d-mesh--two" />
      <div className="bg3d-mesh bg3d-mesh--three" />
      <div className="bg3d-grain" />
      <div className="bg3d-motes">
        {motes.map((m) => (
          <span
            key={m.id}
            className="mote"
            style={{
              left: `${m.left}%`,
              width: `${m.size}px`,
              height: `${m.size}px`,
              animationDuration: `${m.duration}s`,
              animationDelay: `${m.delay}s`,
              "--depth": m.depth,
            }}
          />
        ))}
      </div>
    </div>
  );
}
