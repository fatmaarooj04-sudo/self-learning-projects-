import React, { useEffect } from "react";
import { motion } from "motion/react";
import { X } from "lucide-react";

export default function Modal({ title, eyebrow, onClose, children }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <motion.div
      className="overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        className="modal"
        initial={{ scale: 0.9, y: 40, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.94, y: 24, opacity: 0 }}
        transition={{ type: "spring", stiffness: 260, damping: 26 }}
      >
        <button className="close" onClick={onClose} aria-label="Close">
          <X size={18} />
        </button>
        <p className="eyebrow">{eyebrow || "ROOM DISCOVERY"}</p>
        <h2>{title}</h2>
        {children}
      </motion.div>
    </motion.div>
  );
}
