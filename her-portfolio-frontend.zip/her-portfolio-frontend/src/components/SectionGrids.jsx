import React from "react";
import * as Icons from "lucide-react";
import { skills, projects, achievements } from "../data/portfolio";

export function SkillsGrid() {
  return (
    <div className="grid skills-grid">
      {skills.map((s) => {
        const Icon = Icons[s.icon] || Icons.Sparkle;
        return (
          <div className="info-card skill-card" key={s.name}>
            <span className="skill-icon">
              <Icon size={20} strokeWidth={1.6} />
            </span>
            <strong>{s.name}</strong>
            <small>{s.category}</small>
          </div>
        );
      })}
    </div>
  );
}

export function ProjectsGrid() {
  return (
    <div className="grid">
      {projects.map((p) => (
        <div className="info-card clickable project-card" key={p.id}>
          <strong>{p.title}</strong>
          <small>{p.description}</small>
          <div className="chips">
            {p.technologies.map((t) => (
              <span key={t}>{t}</span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export function AchievementsGrid() {
  return (
    <div className="grid">
      {achievements.map((a) => {
        const Icon = Icons[a.icon] || Icons.Trophy;
        return (
          <div className="info-card achievement-card" key={a.title}>
            <span className="skill-icon">
              <Icon size={20} strokeWidth={1.6} />
            </span>
            <strong>{a.title}</strong>
            <small>{a.date}</small>
            <p>{a.description}</p>
          </div>
        );
      })}
    </div>
  );
}
