import React from "react";

export default function LivingRoomScene() {
  return (
    <>
      <div className="wall-molding depth-back" />
      <div className="window depth-back">
        <div className="window-sky">
          <span className="moon" />
          <span className="cloud c1" />
          <span className="cloud c2" />
        </div>
        <div className="window-panes" />
        <div className="curtain curtain-left" />
        <div className="curtain curtain-right" />
      </div>
      <div className="wall-frame depth-back">
        <span>♡</span>
      </div>

      <div className="rug depth-mid" />

      <div className="bookshelf depth-mid" id="skills-anchor">
        <div className="shelf-row">
          {[..."ABCDE"].map((c) => (
            <i key={c} className={`spine s-${c}`} />
          ))}
        </div>
        <div className="shelf-row">
          {[..."FGHI"].map((c) => (
            <i key={c} className={`spine s-${c}`} />
          ))}
        </div>
        <div className="shelf-row">
          {[..."JKL"].map((c) => (
            <i key={c} className={`spine s-${c}`} />
          ))}
        </div>
      </div>

      <div className="sofa depth-front" id="about-anchor">
        <div className="sofa-back" />
        <div className="cushion cushion-1" />
        <div className="cushion cushion-2" />
        <div className="sofa-arm arm-left" />
        <div className="sofa-arm arm-right" />
      </div>

      <div className="floor-lamp depth-front">
        <div className="lamp-shade" />
        <div className="lamp-pole" />
        <div className="lamp-base" />
      </div>

      <div className="plant depth-front">
        <span className="leaf l1" />
        <span className="leaf l2" />
        <span className="leaf l3" />
        <div className="pot" />
      </div>

      <div className="door depth-front" id="contact-anchor">
        <div className="door-panel" />
        <div className="door-panel small" />
        <span className="doorknob" />
      </div>
    </>
  );
}
