import React from "react";

export default function StudyRoomScene() {
  return (
    <>
      <div className="wall-molding depth-back" />
      <div className="window window--study depth-back">
        <div className="window-sky window-sky--study">
          <span className="star s1" />
          <span className="star s2" />
          <span className="star s3" />
          <span className="star s4" />
        </div>
        <div className="window-panes" />
      </div>

      <div className="tall-shelf depth-back">
        {Array.from({ length: 4 }).map((_, r) => (
          <div className="shelf-row" key={r}>
            {Array.from({ length: 5 }).map((__, c) => (
              <i key={c} className={`spine s-${(r * 5 + c) % 12}`} />
            ))}
          </div>
        ))}
      </div>

      <div className="rug rug--study depth-mid" />

      <div className="cert-frame depth-mid" id="achievements-anchor">
        <div className="cert-inner">
          <span className="ribbon" />
        </div>
      </div>

      <div className="desk depth-front" id="projects-anchor">
        <div className="desk-top" />
        <div className="laptop">
          <div className="laptop-screen">
            <span />
          </div>
          <div className="laptop-base" />
        </div>
        <div className="mug" />
        <div className="desk-lamp">
          <span className="dl-shade" />
          <span className="dl-arm" />
        </div>
        <div className="desk-leg leg-left" />
        <div className="desk-leg leg-right" />
      </div>

      <div className="chair depth-front">
        <div className="chair-back" />
        <div className="chair-seat" />
        <div className="chair-leg" />
      </div>

      <div className="plant plant--study depth-front">
        <span className="leaf l1" />
        <span className="leaf l2" />
        <span className="leaf l3" />
        <div className="pot" />
      </div>
    </>
  );
}
