import React, { useState } from "react";
import { Send, Mail, MapPin } from "lucide-react";
import { personal } from "../data/portfolio";

export default function ContactForm() {
  const [sent, setSent] = useState(false);

  return (
    <div className="contact-wrap">
      <div className="contact-info">
        <p>
          <Mail size={16} /> {personal.email}
        </p>
        <p>
          <MapPin size={16} /> {personal.location}
        </p>
      </div>
      <form
        className="contact"
        onSubmit={(e) => {
          e.preventDefault();
          setSent(true);
        }}
      >
        <input required placeholder="Your name" aria-label="Your name" />
        <input required type="email" placeholder="Your email" aria-label="Your email" />
        <textarea required rows="5" placeholder="Say something…" aria-label="Message" />
        <button type="submit">
          <Send size={16} /> Send message
        </button>
        {sent && (
          <p className="success">
            Message captured in this frontend demo — it'll be wired up to a real backend soon.
          </p>
        )}
      </form>
    </div>
  );
}
