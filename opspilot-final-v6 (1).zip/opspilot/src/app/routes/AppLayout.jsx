import { Outlet, Navigate } from 'react-router-dom'
import Sidebar from '../../components/ui/Sidebar'
import ToastStack from '../../components/ui/ToastStack'
import CreateProjectModal from '../../components/modals/CreateProjectModal'
import CreateTaskModal from '../../components/modals/CreateTaskModal'
import { useAuth } from '../providers/AuthContext'
import { useModals } from '../providers/ModalProvider'

export default function AppLayout() {
  const { user } = useAuth()
  const { projectModalOpen, closeCreateProject, taskModalOpen, taskModalProjectId, closeCreateTask } = useModals()

  if (!user) return <Navigate to="/login" replace />

  return (
    <div className="flex min-h-screen bg-ink">
      <Sidebar />
      <main className="flex-1 min-w-0">
        <Outlet />
      </main>

      {projectModalOpen && <CreateProjectModal onClose={closeCreateProject} />}
      {taskModalOpen && <CreateTaskModal projectId={taskModalProjectId} onClose={closeCreateTask} />}
      <ToastStack />
    </div>
  )
}
