import { createContext, useContext, useState, useCallback } from 'react'
import {
  projects as initialProjects,
  tasks as initialTasks,
  clients,
  workflows as initialWorkflows,
} from '../../data/projects'
import { employees as initialEmployees } from '../../data/employees'

const DataContext = createContext(null)

const slugify = (name) =>
  name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || 'item'

export function DataProvider({ children }) {
  const [projects, setProjects] = useState(initialProjects)
  const [tasks, setTasks] = useState(initialTasks)
  const [employees, setEmployees] = useState(initialEmployees)
  const [workflows, setWorkflows] = useState(initialWorkflows)
  const [requests, setRequests] = useState([])
  const [clientHours, setClientHours] = useState({ 'cli-1': 40, 'cli-2': 40, 'cli-3': 40 })
  const [toasts, setToasts] = useState([])

  const pushToast = useCallback((toast) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
    setToasts((t) => [...t, { id, ...toast }])
    window.setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id))
    }, 6000)
  }, [])

  const dismissToast = useCallback((id) => {
    setToasts((t) => t.filter((x) => x.id !== id))
  }, [])

  const addProject = useCallback((input) => {
    const normalizedName = input.name.trim().toLowerCase()
    if (projects.some((p) => p.name.trim().toLowerCase() === normalizedName)) {
      return { error: 'A project with this name already exists.' }
    }

    const budget = Number(input.budget) || 0
    if (budget > 100000) {
      return { error: 'Project budget cannot exceed $100,000.' }
    }

    const id = `proj-${slugify(input.name)}-${Date.now().toString(36).slice(-4)}`
    const project = {
      id,
      name: input.name,
      clientId: input.clientId,
      manager: input.manager,
      start: input.start,
      deadline: input.deadline,
      health: 100,
      risk: 'low',
      budget,
      spent: 0,
      status: 'Planning',
      description: input.description || 'No description provided yet.',
    }
    setProjects((p) => [project, ...p])
    return { project }
  }, [projects])

  const addTask = useCallback((input) => {
    const id = `task-${slugify(input.title)}-${Date.now().toString(36).slice(-4)}`
    const task = {
      id,
      projectId: input.projectId,
      title: input.title,
      status: input.status || 'todo',
      priority: input.priority || 'medium',
      assignee: input.assignee,
      department: employees.find((e) => e.name === input.assignee)?.department || 'Development',
      estHrs: Number(input.estHrs) || 0,
      actualHrs: 0,
      deadline: input.deadline,
      dependsOn: [],
      tags: input.tags ? input.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
      createdAt: Date.now(),
    }
    setTasks((t) => [task, ...t])
    setEmployees((list) => list.map((e) => e.name === input.assignee ? { ...e, assignedHrs: Math.max(0, Number(e.assignedHrs || 0) + Number(task.estHrs || 0)), overloadFlag: (Number(e.assignedHrs || 0) + Number(task.estHrs || 0)) > Number(e.capacityHrs || 40) } : e))
    return task
  }, [employees])

  const updateEmployeeHours = useCallback((id, assignedHrs) => {
    const hours = Math.max(0, Math.min(60, Number(assignedHrs) || 0))
    setEmployees((list) => list.map((e) => e.id === id ? { ...e, assignedHrs: hours, overloadFlag: hours > e.capacityHrs } : e))
  }, [])

  const updateTask = useCallback((id, patch) => {
    setTasks((list) => list.map((t) => t.id === id ? { ...t, ...patch } : t))
  }, [])

  const updateRequest = useCallback((id, patch) => { setRequests((list) => list.map((r) => r.id === id ? { ...r, ...patch } : r)) }, [])

  const addRequest = useCallback((request) => {
    const next = { id: `req-${Date.now()}`, status: 'pending', submittedAt: new Date().toLocaleString(), ...request }
    setRequests((list) => [next, ...list])
    return next
  }, [])

  const updateRecommendation = useCallback((id, patch) => {
    setEmployees((list) => list.map((e) => e.id === id ? { ...e, ...patch } : e))
  }, [])

  const updateClientHours = useCallback((clientId, hours) => {
    setClientHours((list) => ({ ...list, [clientId]: Math.max(0, Math.min(60, Number(hours) || 0)) }))
  }, [])

  const addWorkflowRequest = useCallback((workflowId, item) => {
    setWorkflows((wfs) =>
      wfs.map((wf) =>
        wf.id === workflowId
          ? { ...wf, active: [{ item: item.item, currentStep: 0, requestedBy: item.requestedBy }, ...wf.active] }
          : wf
      )
    )
  }, [])

  const sendEmailNotification = useCallback(
    ({ to, subject, body }) => {
      const href = `mailto:${encodeURIComponent(to || '')}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
      window.open(href, '_blank')
      pushToast({
        tone: 'indigo',
        title: 'Email draft opened',
        message: `A pre-filled email to ${to} was handed off to your default mail app.`,
      })
    },
    [pushToast]
  )

  const value = {
    projects,
    tasks,
    employees,
    clients,
    workflows,
    requests,
    clientHours,
    addProject,
    addTask,
    updateTask,
    updateEmployeeHours,
    updateRecommendation,
    updateClientHours,
    addRequest,
    updateRequest,
    setRequests,
    addWorkflowRequest,
    sendEmailNotification,
    pushToast,
    toasts,
    dismissToast,
  }

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}

export function useData() {
  const ctx = useContext(DataContext)
  if (!ctx) throw new Error('useData must be used within a DataProvider')
  return ctx
}
