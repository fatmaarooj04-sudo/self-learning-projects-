import { createContext, useContext, useState, useCallback } from 'react'

const ModalContext = createContext(null)

export function ModalProvider({ children }) {
  const [projectModal, setProjectModal] = useState(false)
  const [taskModal, setTaskModal] = useState({ open: false, projectId: null })

  const openCreateProject = useCallback(() => setProjectModal(true), [])
  const closeCreateProject = useCallback(() => setProjectModal(false), [])

  const openCreateTask = useCallback((projectId = null) => setTaskModal({ open: true, projectId }), [])
  const closeCreateTask = useCallback(() => setTaskModal({ open: false, projectId: null }), [])

  const value = {
    projectModalOpen: projectModal,
    openCreateProject,
    closeCreateProject,
    taskModalOpen: taskModal.open,
    taskModalProjectId: taskModal.projectId,
    openCreateTask,
    closeCreateTask,
  }

  return <ModalContext.Provider value={value}>{children}</ModalContext.Provider>
}

export function useModals() {
  const ctx = useContext(ModalContext)
  if (!ctx) throw new Error('useModals must be used within a ModalProvider')
  return ctx
}
