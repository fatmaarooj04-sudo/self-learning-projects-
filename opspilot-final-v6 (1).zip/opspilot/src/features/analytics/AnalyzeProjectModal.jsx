import { useEffect, useState } from 'react'
import { Panel, Tag } from '../../components/ui/Primitives'
import { riskTone } from '../../utils/format'

// Deterministic mock "AI" reasoning derived from project + task data,
// standing in for a real call to the completions API.
function buildAnalysis(project, projectTasks) {
  const overdue = projectTasks.filter((t) => t.status === 'overdue')
  const blocked = projectTasks.filter((t) => t.status === 'blocked')
  const risks = []
  const actions = []

  if (overdue.length > 0) {
    risks.push(`${overdue.length} task${overdue.length > 1 ? 's are' : ' is'} overdue, including "${overdue[0].title}"`)
    actions.push(`Re-prioritize ${overdue.length > 1 ? 'the overdue tasks' : `"${overdue[0].title}"`} and confirm a revised delivery date with the assignee`)
  }
  if (blocked.length > 0) {
    risks.push(`${blocked.length} task${blocked.length > 1 ? 's are' : ' is'} blocked on an upstream dependency`)
    actions.push(`Unblock "${blocked[0].title}" — its dependency needs to close before downstream work can continue`)
  }
  if (project.health < 60) {
    risks.push('Overall project health has dropped below the 60% threshold this team treats as at-risk')
    actions.push('Schedule a status review with the client before the next milestone')
  }
  if (project.spent / project.budget > 0.6) {
    risks.push(`Budget is ${Math.round((project.spent / project.budget) * 100)}% consumed relative to elapsed timeline`)
    actions.push('Review remaining scope against budget with the account owner')
  }
  if (risks.length === 0) {
    risks.push('No material risks detected in current task and budget data')
    actions.push('Continue current cadence — no intervention needed this week')
  }

  return { risks, actions }
}

export default function AnalyzeProjectModal({ project, projectTasks, onClose }) {
  const [phase, setPhase] = useState('loading')
  const [analysis, setAnalysis] = useState(null)

  useEffect(() => {
    setPhase('loading')
    const t = setTimeout(() => {
      setAnalysis(buildAnalysis(project, projectTasks))
      setPhase('done')
    }, 900)
    return () => clearTimeout(t)
  }, [project, projectTasks])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <Panel className="w-full max-w-lg p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-signal-indigo/15 border border-signal-indigo/30 flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#7c8cf8" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1" />
                <circle cx="12" cy="12" r="3.2" />
              </svg>
            </div>
            <div>
              <p className="font-display text-sm font-semibold">Project health analysis</p>
              <p className="text-xs text-text-faint">{project.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-text-faint hover:text-text text-sm">✕</button>
        </div>

        {phase === 'loading' ? (
          <div className="py-10 flex flex-col items-center gap-3">
            <div className="w-5 h-5 border-2 border-line border-t-signal-indigo rounded-full animate-spin" />
            <p className="text-xs text-text-faint">Reviewing tasks, budget and deadlines…</p>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-xs text-text-dim">Risk level</span>
              <Tag tone={riskTone(project.risk)}>{project.risk.toUpperCase()}</Tag>
            </div>

            <div>
              <p className="text-xs font-medium text-text-dim uppercase tracking-wide mb-2">Primary risks</p>
              <ul className="space-y-1.5">
                {analysis.risks.map((r, i) => (
                  <li key={i} className="text-sm text-text flex gap-2">
                    <span className="text-signal-coral mt-1">•</span>
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="text-xs font-medium text-text-dim uppercase tracking-wide mb-2">Recommended actions</p>
              <ol className="space-y-1.5">
                {analysis.actions.map((a, i) => (
                  <li key={i} className="text-sm text-text flex gap-2">
                    <span className="font-display text-signal-indigo shrink-0">{i + 1}.</span>
                    <span>{a}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        )}
      </Panel>
    </div>
  )
}
