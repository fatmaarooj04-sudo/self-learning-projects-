import { useData } from '../../app/providers/DataContext'
import { toneClasses } from '../../utils/format'

export default function ToastStack() {
  const { toasts, dismissToast } = useData()
  if (toasts.length === 0) return null

  return (
    <div className="fixed inset-0 z-[60] pointer-events-none flex items-center justify-center p-5">
      <div className="flex flex-col items-center gap-3 w-full max-w-[420px]">
      {toasts.map((t) => {
        const c = toneClasses[t.tone] || toneClasses.indigo
        return (
          <div
            key={t.id}
            className={`pointer-events-auto w-full bg-panel/95 backdrop-blur-md border ${c.border} rounded-xl shadow-2xl p-4 animate-toast-in flex gap-3`}
          >
            <span className={`w-2 h-2 rounded-full ${c.dot} mt-1.5 shrink-0 animate-pulse-dot`} />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-text">{t.title}</p>
              {t.message && <p className="text-xs text-text-dim mt-0.5 leading-relaxed">{t.message}</p>}
            </div>
            <button
              onClick={() => dismissToast(t.id)}
              className="text-text-faint hover:text-text shrink-0"
              aria-label="Dismiss"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>
        )
      })}
      </div>
    </div>
  )
}
