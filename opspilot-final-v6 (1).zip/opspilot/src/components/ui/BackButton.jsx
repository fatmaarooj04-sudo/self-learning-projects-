import { useNavigate } from 'react-router-dom'
export default function BackButton({ fallback='/app' }) { const navigate=useNavigate(); return <button className="back-button" onClick={()=>window.history.length>1?navigate(-1):navigate(fallback)}>← <span>Back</span></button> }
