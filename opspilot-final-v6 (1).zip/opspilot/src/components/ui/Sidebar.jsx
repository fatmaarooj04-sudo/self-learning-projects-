import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../../app/providers/AuthContext'
import { Avatar } from './Primitives'

const icons = {
  dashboard: <path d="M3 12h4v8H3v-8Zm7-8h4v16h-4V4Zm7 5h4v11h-4V9Z" />,
  tasks: <path d="M5 6h14M5 12h14M5 18h9" /> ,
  projects: <path d="M4 5h16v3H4V5Zm0 5h16v3H4v-3Zm0 5h10v3H4v-3Z" />,
  employees: <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-8 8a8 8 0 0 1 16 0H4Z" />,
  issues: <path d="M12 3 2 20h20L12 3Zm0 6v5m0 3h.01" />,
  workflows: <path d="M4 6h6l2 2h8v3H4V6Zm0 7h16v2H4v-2Zm0 5h10v2H4v-2Z" />,
  analytics: <path d="M4 20V10m6 10V4m6 16v-7m6 7V8" />,
  audit: <path d="M6 3h9l5 5v13H6V3Zm9 0v5h5M9 12h6M9 16h6M9 8h2" />,
  portal: <path d="M12 2 3 7v6c0 5 4 8 9 9 5-1 9-4 9-9V7l-9-5Z" />,
}

const navByRole = {
  admin: [
    { to: '/app', label: 'Overview', icon: 'dashboard', end: true },
    { to: '/app/projects', label: 'Projects', icon: 'projects' },
    { to: '/app/tasks', label: 'Tasks', icon: 'tasks' },
    { to: '/app/employees', label: 'Team & Workload', icon: 'employees' },
    { to: '/app/issues', label: 'Incidents', icon: 'issues' },
    { to: '/app/workflows', label: 'Approvals', icon: 'workflows' },
    { to: '/app/analytics', label: 'Analytics', icon: 'analytics' },
    { to: '/app/audit', label: 'Audit Log', icon: 'audit' },
  ],
  employee: [
    { to: '/app', label: 'Overview', icon: 'dashboard', end: true },
    { to: '/app/projects', label: 'Projects', icon: 'projects' },
    { to: '/app/tasks', label: 'Tasks', icon: 'tasks' },
    { to: '/app/employees', label: 'Team & Workload', icon: 'employees' },
    { to: '/app/issues', label: 'Incidents', icon: 'issues' },
    { to: '/app/workflows', label: 'Approvals', icon: 'workflows' },
  ],
  client: [
    { to: '/app/portal', label: 'Your Projects', icon: 'portal', end: true },
  ],
}

export default function Sidebar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const items = navByRole[user?.role] || navByRole.employee

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <aside className="w-60 shrink-0 h-screen sticky top-0 border-r border-line bg-panel flex flex-col">
      <div className="px-5 h-16 flex items-center gap-2 border-b border-line">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4c6ef5" strokeWidth="2">
          <path d="M12 2 3 7v6c0 5 4 8 9 9 5-1 9-4 9-9V7l-9-5Z" />
          <path d="M9 12l2 2 4-4" />
        </svg>
        <span className="font-semibold text-[15px] tracking-tight">OpsPilot</span>
      </div>

      <nav className="flex-1 py-3 px-2.5 space-y-0.5 overflow-y-auto">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-md text-[13px] transition-colors ${
                isActive
                  ? 'bg-panel-raised text-text border border-line'
                  : 'text-text-dim hover:text-text hover:bg-panel-raised border border-transparent'
              }`
            }
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              {icons[item.icon]}
            </svg>
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="p-3 border-t border-line">
        <div className="flex items-center gap-2.5 px-2 py-2 rounded-md bg-panel-raised border border-line">
          <Avatar name={user?.name || '?'} color={user?.avatarColor} size={30} />
          <div className="min-w-0 flex-1">
            <p className="text-[13px] truncate">{user?.name}</p>
            <p className="text-[11px] text-text-faint truncate capitalize">{user?.role}</p>
          </div>
          <button onClick={handleLogout} title="Sign out" className="text-text-faint hover:text-text shrink-0">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <path d="M16 17l5-5-5-5M21 12H9" />
            </svg>
          </button>
        </div>
      </div>
    </aside>
  )
}
