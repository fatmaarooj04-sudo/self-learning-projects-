import { useEffect } from 'react'

export default function Modal({ title, subtitle, onClose, children, width = 'max-w-lg' }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-4 overflow-y-auto">
      <div className="fixed inset-0 bg-ink/70 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div
        className={`relative w-full ${width} bg-panel border border-line rounded-xl shadow-2xl animate-modal-in my-8`}
      >
        <div className="flex items-start justify-between px-5 pt-5 pb-4 border-b border-line-soft">
          <div>
            <h2 className="font-display italic text-[19px] font-semibold text-text">{title}</h2>
            {subtitle && <p className="text-xs text-text-faint mt-1">{subtitle}</p>}
          </div>
          <button
            onClick={onClose}
            className="text-text-faint hover:text-text transition-colors rounded-md p-1 hover:bg-panel-raised"
            aria-label="Close"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>
        <div className="px-5 py-5">{children}</div>
      </div>
    </div>
  )
}
