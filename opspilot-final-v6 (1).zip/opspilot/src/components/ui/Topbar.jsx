import BackButton from './BackButton'
export default function Topbar({title,subtitle,actions,showBack=true}){return <div className="topbar"><div className="topbar-left">{showBack&&<BackButton/>}<div><h1>{title}</h1>{subtitle&&<p>{subtitle}</p>}</div></div><div className="topbar-actions">{actions}</div></div>}
