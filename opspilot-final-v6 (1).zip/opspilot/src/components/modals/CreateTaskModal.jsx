import { useState } from 'react'
import Modal from '../ui/Modal'
import { Field, Input, Select, Button } from '../ui/Primitives'
import { useData } from '../../app/providers/DataContext'
import { useAuth } from '../../app/providers/AuthContext'

export default function CreateTaskModal({ projectId, onClose }) {
  const { projects, employees, addTask, sendEmailNotification, pushToast } = useData()
  const { user } = useAuth()
  const [form, setForm] = useState({ projectId: projectId || projects[0]?.id || '', title: '', assignee: employees[0]?.name || '', priority: 'medium', status: 'todo', estHrs: '', deadline: '', tags: '', notify: true })
  const [submitting, setSubmitting] = useState(false)
  const [errors, setErrors] = useState({})
  const [overloadWarning, setOverloadWarning] = useState(null)

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  const actuallyCreate = () => {
    setSubmitting(true)
    setTimeout(() => {
      const task = addTask(form)
      const project = projects.find((p) => p.id === task.projectId)
      pushToast({ tone: 'indigo', title: 'Task added successfully', message: `"${task.title}" assigned to ${task.assignee} on ${project?.name || 'project'}.` })
      if (form.notify) sendEmailNotification({ to: user?.email || 'you@opspilot.app', subject: `New task: ${task.title}`, body: `Hi ${user?.name || ''},\n\nA new task was created in OpsPilot:\n\nTask: ${task.title}\nProject: ${project?.name || ''}\nAssignee: ${task.assignee}\nPriority: ${task.priority}\nDeadline: ${task.deadline}\n\n— OpsPilot` })
      setSubmitting(false)
      onClose()
    }, 350)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const nextErrors = {}
    if (!form.title.trim()) nextErrors.title = 'Task title is required.'
    if (!form.projectId) nextErrors.projectId = 'Please select a project.'
    if (!form.deadline) nextErrors.deadline = 'Please select a deadline.'
    if (Number(form.estHrs) < 0) nextErrors.estHrs = 'Hours cannot be negative.'
    if (Object.keys(nextErrors).length) { setErrors(nextErrors); return }
    const employee = employees.find((e) => e.name === form.assignee)
    const planned = Number(employee?.assignedHrs || 0) + Number(form.estHrs || 0)
    if (employee && planned > employee.capacityHrs) {
      setOverloadWarning({ name: employee.name, planned, capacity: employee.capacityHrs, extra: planned - employee.capacityHrs })
      return
    }
    setErrors({})
    actuallyCreate()
  }

  return <Modal title="Add task" subtitle="Assign work, set a deadline and keep workload visible." onClose={onClose}>
    <form onSubmit={handleSubmit} className="space-y-4">
      <Field label="Task title"><Input placeholder="e.g. Build settings page" value={form.title} onChange={set('title')} required autoFocus aria-invalid={Boolean(errors.title)} />{errors.title && <span className="text-[11px] text-status-bad mt-1 block">{errors.title}</span>}</Field>
      {!projectId && <Field label="Project"><Select value={form.projectId} onChange={set('projectId')}>{projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select></Field>}
      <div className="grid grid-cols-2 gap-4"><Field label="Assignee"><Select value={form.assignee} onChange={set('assignee')}>{employees.map((e) => <option key={e.id}>{e.name}</option>)}</Select></Field><Field label="Priority"><Select value={form.priority} onChange={set('priority')}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="critical">Critical</option></Select></Field></div>
      <div className="grid grid-cols-2 gap-4"><Field label="Status"><Select value={form.status} onChange={set('status')}><option value="todo">To do</option><option value="in-progress">In progress</option><option value="blocked">Blocked</option><option value="done">Done</option></Select></Field><Field label="Estimated hours"><Input type="number" min="0" placeholder="8" value={form.estHrs} onChange={set('estHrs')} />{errors.estHrs && <span className="text-[11px] text-status-bad mt-1 block">{errors.estHrs}</span>}</Field></div>
      <Field label="Deadline"><Input type="date" value={form.deadline} onChange={set('deadline')} required />{errors.deadline && <span className="text-[11px] text-status-bad mt-1 block">{errors.deadline}</span>}</Field>
      <Field label="Tags" hint="Comma-separated, e.g. frontend, urgent"><Input placeholder="frontend, api" value={form.tags} onChange={set('tags')} /></Field>
      <label className="flex items-center gap-2.5 text-xs text-text-dim py-1 cursor-pointer select-none"><input type="checkbox" checked={form.notify} onChange={set('notify')} className="accent-brand w-3.5 h-3.5" />Email me a confirmation when this task is created</label>
      <div className="flex justify-end gap-2.5 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancel</Button><Button type="submit" disabled={submitting}>{submitting ? <> <span className="w-3.5 h-3.5 rounded-full border-2 border-white/40 border-t-white animate-spin" />Adding…</> : '+ Add task'}</Button></div>
    </form>
    {overloadWarning && <div className="overload-warning"><div className="overload-icon">!</div><div className="flex-1"><b>Workload overload warning</b><p>{overloadWarning.name} is already at {overloadWarning.capacity}h capacity. This task would take the plan to <strong>{overloadWarning.planned}h</strong>, which is {overloadWarning.extra}h over capacity.</p><div className="flex gap-2 mt-3"><Button type="button" variant="ghost" onClick={()=>setOverloadWarning(null)}>Choose someone else</Button><Button type="button" onClick={()=>{setOverloadWarning(null);actuallyCreate()}}>Yes, put on overload</Button></div></div></div>}
  </Modal>
}
