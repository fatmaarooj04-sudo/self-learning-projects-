import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Modal from '../ui/Modal'
import { Field, Input, Select, Textarea, Button } from '../ui/Primitives'
import { useData } from '../../app/providers/DataContext'
import { useAuth } from '../../app/providers/AuthContext'

export default function CreateProjectModal({ onClose }) {
  const { clients, employees, addProject, sendEmailNotification, pushToast } = useData()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({
    name: '',
    clientId: clients[0]?.id || '',
    manager: employees[0]?.name || '',
    start: '2026-08-31',
    deadline: '',
    budget: '',
    description: '',
    notify: true,
  })
  const [submitting, setSubmitting] = useState(false)
  const [errors, setErrors] = useState({})

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  const handleSubmit = (e) => {
    e.preventDefault()
    const nextErrors = {}
    const budget = Number(form.budget) || 0

    if (!form.name.trim()) nextErrors.name = 'Project name is required.'
    if (!form.deadline) nextErrors.deadline = 'Please select a deadline.'
    if (budget < 0) nextErrors.budget = 'Budget cannot be negative.'
    if (budget > 100000) nextErrors.budget = 'Budget cannot exceed $100,000.'

    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors)
      return
    }

    setErrors({})
    setSubmitting(true)

    setTimeout(() => {
      const result = addProject(form)
      if (result.error) {
        setSubmitting(false)
        pushToast({ tone: 'coral', title: 'Project not created', message: result.error })
        return
      }

      const project = result.project
      pushToast({
        tone: 'teal',
        title: 'Project added successfully',
        message: `"${project.name}" was added to the pipeline.`,
      })
      if (form.notify) {
        sendEmailNotification({
          to: user?.email || 'you@opspilot.app',
          subject: `New project created: ${project.name}`,
          body: `Hi ${user?.name || ''},\n\nA new project has been added to OpsPilot:\n\nProject: ${project.name}\nManager: ${project.manager}\nDeadline: ${project.deadline}\nBudget: $${project.budget}\n\n— OpsPilot`,
        })
      }
      setSubmitting(false)
      onClose()
      navigate(`/app/projects/${project.id}`)
    }, 450)
  }

  return (
    <Modal title="New project" subtitle="Kick off a new engagement — it'll appear on the projects board instantly." onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Project name">
          <Input placeholder="e.g. Inventory Dashboard Rebuild" value={form.name} onChange={set('name')} required autoFocus aria-invalid={Boolean(errors.name)} className={errors.name ? 'border-status-bad' : ''} />
          {errors.name && <span className="text-[11px] text-status-bad mt-1 block">{errors.name}</span>}
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Client">
            <Select value={form.clientId} onChange={set('clientId')}>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </Select>
          </Field>
          <Field label="Manager">
            <Select value={form.manager} onChange={set('manager')}>
              {employees.map((e) => (
                <option key={e.id} value={e.name}>{e.name}</option>
              ))}
            </Select>
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Start date">
            <Input type="date" value={form.start} onChange={set('start')} />
          </Field>
          <Field label="Deadline">
            <Input type="date" value={form.deadline} onChange={set('deadline')} required aria-invalid={Boolean(errors.deadline)} className={errors.deadline ? 'border-status-bad' : ''} />
            {errors.deadline && <span className="text-[11px] text-status-bad mt-1 block">{errors.deadline}</span>}
          </Field>
        </div>

        <Field label="Budget (USD)">
          <Input type="number" min="0" max="100000" step="100" placeholder="12000" value={form.budget} onChange={set('budget')} aria-invalid={Boolean(errors.budget)} className={errors.budget ? 'border-status-bad' : ''} />
          <span className={`text-[11px] mt-1 block ${errors.budget ? 'text-status-bad' : 'text-text-faint'}`}>{errors.budget || 'Maximum allowed budget: $100,000'}</span>
        </Field>

        <Field label="Description" hint="Shown on the project's Overview tab.">
          <Textarea rows={3} placeholder="What is this project about?" value={form.description} onChange={set('description')} />
        </Field>

        <label className="flex items-center gap-2.5 text-xs text-text-dim py-1 cursor-pointer select-none">
          <input type="checkbox" checked={form.notify} onChange={set('notify')} className="accent-brand w-3.5 h-3.5" />
          Email me a confirmation when this project is created
        </label>

        <div className="flex justify-end gap-2.5 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary" disabled={submitting}>
            {submitting ? (
              <>
                <span className="w-3.5 h-3.5 rounded-full border-2 border-white/40 border-t-white animate-spin" />
                Creating…
              </>
            ) : (
              '+ Create project'
            )}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
