import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../../app/providers/AuthContext'

const roles = [
  {
    id: 'admin',
    label: 'Admin',
    desc: 'Full access — projects, team, budgets, approvals',
    email: 'arooj@opspilot.io',
  },
  {
    id: 'employee',
    label: 'Employee',
    desc: 'Your tasks, projects and workload',
    email: 'ahmed@opspilot.io',
  },
  {
    id: 'client',
    label: 'Client',
    desc: 'Read-only status for your own projects',
    email: 'farhan@abctech.com',
  },
]

export default function LoginPage() {
  const [role, setRole] = useState('admin')
  const [email, setEmail] = useState(roles[0].email)
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState({})
  const { login } = useAuth()
  const navigate = useNavigate()

  const selectRole = (id) => {
    setRole(id)
    setEmail(roles.find((r) => r.id === id).email)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const nextErrors = {}
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/

    if (!emailPattern.test(email.trim())) nextErrors.email = 'Enter a valid email address.'
    if (!passwordPattern.test(password)) nextErrors.password = 'Password must be at least 8 characters and include uppercase, lowercase and a number.'

    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors)
      return
    }

    setErrors({})
    login(role, email.trim())
    navigate(role === 'client' ? '/app/portal' : '/app')
  }

  return (
    <div className="min-h-screen bg-ink text-text grid md:grid-cols-2">
      {/* left brand panel */}
      <div className="hidden md:flex flex-col justify-between bg-panel border-r border-line p-10 bg-grid">
        <Link to="/" className="flex items-center gap-2">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4c6ef5" strokeWidth="2">
            <path d="M12 2 3 7v6c0 5 4 8 9 9 5-1 9-4 9-9V7l-9-5Z" />
            <path d="M9 12l2 2 4-4" />
          </svg>
          <span className="font-semibold text-[15px] tracking-tight">OpsPilot</span>
        </Link>

        <div className="max-w-sm">
          <p className="font-display text-[26px] leading-snug mb-4">
            "Project Alpha is at risk — 3 high-priority tasks are overdue and two assigned
            employees are above capacity."
          </p>
          <p className="text-xs text-text-faint">Example risk alert, generated automatically from live task and workload data.</p>
        </div>

        <p className="text-xs text-text-faint">© 2026 OpsPilot — Operations command center</p>
      </div>

      {/* right form panel */}
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <Link to="/" className="md:hidden flex items-center gap-2 mb-10">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4c6ef5" strokeWidth="2">
              <path d="M12 2 3 7v6c0 5 4 8 9 9 5-1 9-4 9-9V7l-9-5Z" />
              <path d="M9 12l2 2 4-4" />
            </svg>
            <span className="font-semibold text-[15px]">OpsPilot</span>
          </Link>

          <h1 className="font-display text-2xl mb-1.5">Sign in to your workspace</h1>
          <p className="text-sm text-text-dim mb-8">Choose how you're accessing OpsPilot.</p>

          <div className="grid grid-cols-3 gap-2 mb-7">
            {roles.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => selectRole(r.id)}
                className={`text-left p-3 rounded-md border transition-colors ${
                  role === r.id ? 'border-brand bg-brand-soft' : 'border-line bg-panel hover:border-line'
                }`}
              >
                <p className={`text-[13px] font-medium ${role === r.id ? 'text-text' : 'text-text-dim'}`}>{r.label}</p>
              </button>
            ))}
          </div>
          <p className="text-xs text-text-faint -mt-5 mb-7">{roles.find((r) => r.id === role).desc}</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-text-dim mb-1.5 block">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-panel-raised border border-line rounded-md px-3.5 py-2.5 text-sm outline-none focus:border-brand transition-colors"
                required
                autoComplete="email"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <p className="text-[11px] text-status-bad mt-1.5">{errors.email}</p>}
            </div>
            <div>
              <label className="text-xs text-text-dim mb-1.5 block">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                minLength={8}
                required
                autoComplete="current-password"
                aria-invalid={Boolean(errors.password)}
                className="w-full bg-panel-raised border border-line rounded-md px-3.5 py-2.5 text-sm outline-none focus:border-brand transition-colors"
              />
              {errors.password && <p className="text-[11px] text-status-bad mt-1.5 leading-relaxed">{errors.password}</p>}
            </div>
            <button
              type="submit"
              className="w-full bg-brand text-white text-sm font-medium py-2.5 rounded-md hover:bg-[#3f5edb] transition-colors mt-2"
            >
              Sign in as {roles.find((r) => r.id === role).label}
            </button>
          </form>

          <div className="flex items-center justify-between mt-5 text-xs">
            <button type="button" onClick={()=>window.alert('For the demo, enter your email and we will simulate a password reset link.')} className="text-text-faint hover:text-signal-indigo">Forgot password?</button>
            <Link to="/signup" className="text-signal-indigo hover:underline">Create account</Link>
          </div>
          <p className="text-xs text-text-faint mt-4 leading-relaxed">Demo login: use a valid email and a password with at least 8 characters, including uppercase, lowercase and a number.</p>
        </div>
      </div>
    </div>
  )
}
