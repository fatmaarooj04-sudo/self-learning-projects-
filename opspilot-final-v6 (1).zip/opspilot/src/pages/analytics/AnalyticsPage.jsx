import { useEffect, useState } from 'react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, RadialBarChart, RadialBar, PolarAngleAxis,
} from 'recharts'
import Topbar from '../../components/ui/Topbar'
import { Panel } from '../../components/ui/Primitives'
import { velocity, completionBreakdown, departmentPerformance } from '../../data/projects'

const toneHex = { teal: '#37d0a8', indigo: '#7c8cf8', amber: '#f2ab3d', coral: '#f2586f' }
const deptHex = ['#7c8cf8', '#37d0a8', '#f2ab3d', '#f2586f', '#a78bfa']

const tooltipStyle = {
  background: '#1e232c',
  border: '1px solid #2a2f3a',
  borderRadius: 6,
  fontSize: 12,
  color: '#e7e9ee',
}

function useCountUp(target, duration = 900) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    let raf
    const start = performance.now()
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - p, 3)
      setValue(target * eased)
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, duration])
  return value
}

function AnimatedStat({ label, value, suffix = '', tone, decimals = 0 }) {
  const n = useCountUp(value)
  const hex = tone ? toneHex[tone] : '#e8eaed'
  return (
    <Panel className="p-4 relative overflow-hidden group hover:border-brand/30 transition-colors">
      <div className="absolute inset-x-0 -bottom-6 h-16 opacity-[0.07] group-hover:opacity-[0.14] transition-opacity" style={{ background: `radial-gradient(circle at 30% 100%, ${hex}, transparent 70%)` }} />
      <p className="text-[11px] text-text-faint uppercase tracking-wider font-medium relative">{label}</p>
      <p className="font-display italic text-[28px] leading-none mt-2 tabular relative" style={{ color: hex }}>
        {n.toFixed(decimals)}{suffix}
      </p>
    </Panel>
  )
}

export default function AnalyticsPage() {
  const totalCompletion = completionBreakdown.reduce((s, d) => s + d.value, 0)
  const completedPct = completionBreakdown.find((d) => d.name === 'Completed')?.value || 0

  return (
    <div>
      <Topbar title="Analytics" subtitle="Operational metrics across all projects" />
      <div className="p-6 space-y-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <AnimatedStat label="Avg. project health" value={76} suffix="%" tone="teal" />
          <AnimatedStat label="On-time delivery" value={82} suffix="%" tone="indigo" />
          <AnimatedStat label="Tasks this month" value={81} tone={null} />
          <AnimatedStat label="Avg. resolution time" value={6.4} suffix="h" tone="amber" decimals={1} />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <Panel className="xl:col-span-2 p-5">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-display italic text-sm font-semibold">Project velocity</h3>
              <span className="text-[11px] text-text-faint">tasks completed / week</span>
            </div>
            <div className="h-56 mt-3">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={velocity} margin={{ left: -20 }}>
                  <defs>
                    <linearGradient id="velocityFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#7c8cf8" stopOpacity={0.55} />
                      <stop offset="100%" stopColor="#7c8cf8" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="#22262f" vertical={false} />
                  <XAxis dataKey="week" stroke="#656c78" fontSize={12} tickLine={false} axisLine={{ stroke: '#2a2f3a' }} />
                  <YAxis stroke="#656c78" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip cursor={{ stroke: '#4c6ef5', strokeWidth: 1 }} contentStyle={tooltipStyle} />
                  <Area
                    type="monotone" dataKey="tasks" stroke="#7c8cf8" strokeWidth={2.5}
                    fill="url(#velocityFill)" name="Tasks completed"
                    animationDuration={1100} animationEasing="ease-out"
                    dot={{ r: 3.5, fill: '#0f1216', stroke: '#7c8cf8', strokeWidth: 2 }}
                    activeDot={{ r: 5.5 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Panel>

          <Panel className="p-5 flex flex-col">
            <h3 className="font-display italic text-sm font-semibold mb-1">Completion breakdown</h3>
            <div className="h-44 relative mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={completionBreakdown} dataKey="value" nameKey="name"
                    innerRadius={48} outerRadius={72} paddingAngle={3}
                    animationDuration={1000} animationBegin={100}
                  >
                    {completionBreakdown.map((d, i) => (
                      <Cell key={i} fill={toneHex[d.tone]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="font-display text-2xl tabular">{completedPct}%</span>
                <span className="text-[10px] text-text-faint uppercase tracking-wide">Done</span>
              </div>
            </div>
            <div className="space-y-1.5 mt-3">
              {completionBreakdown.map((d) => (
                <div key={d.name} className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-text-dim">
                    <span className="w-2 h-2 rounded-full" style={{ background: toneHex[d.tone] }} />
                    {d.name}
                  </span>
                  <span className="tabular">{((d.value / totalCompletion) * 100).toFixed(0)}%</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        <Panel className="p-5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-display italic text-sm font-semibold">Department performance</h3>
            <span className="text-[11px] text-text-faint">score out of 100</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-[1.3fr_1fr] gap-4 items-center">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart
                  data={departmentPerformance.map((d, i) => ({ ...d, fill: deptHex[i % deptHex.length] }))}
                  innerRadius="30%" outerRadius="100%" startAngle={90} endAngle={-270} barSize={14}
                >
                  <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                  <RadialBar dataKey="value" background={{ fill: '#1a1e25' }} cornerRadius={8} animationDuration={1100} animationEasing="ease-out" />
                  <Tooltip contentStyle={tooltipStyle} />
                </RadialBarChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-3">
              {departmentPerformance.map((d, i) => (
                <div key={d.name} className="flex items-center gap-3">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: deptHex[i % deptHex.length] }} />
                  <span className="text-sm text-text-dim flex-1">{d.name}</span>
                  <span className="font-display tabular text-sm">{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>
    </div>
  )
}
