import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import Topbar from '../../components/ui/Topbar'
import { Panel, Tag, ProgressBar, Button, Avatar } from '../../components/ui/Primitives'
import { clients, issues, auditLog } from '../../data/projects'
import { riskTone, priorityTone, dateShort, currency, daysUntil } from '../../utils/format'
import AnalyzeProjectModal from '../../features/analytics/AnalyzeProjectModal'
import { useData } from '../../app/providers/DataContext'
import { useModals } from '../../app/providers/ModalProvider'
import { useAuth } from '../../app/providers/AuthContext'

const tabs = ['Overview', 'Tasks', 'Team', 'Issues', 'Activity', 'Analytics']

const statusLabel = {
  done: 'Done', 'in-progress': 'In progress', todo: 'To do', blocked: 'Blocked', overdue: 'Overdue',
}
const statusTone = {
  done: 'teal', 'in-progress': 'indigo', todo: 'indigo', blocked: 'coral', overdue: 'coral',
}

function RadialRing({ pct, tone, size = 76 }) {
  const strokeW = 7
  const r = (size - strokeW) / 2
  const c = 2 * Math.PI * r
  const clamped = Math.min(100, Math.max(0, pct))
  const hex = { teal: '#2fb67c', indigo: '#4c6ef5', amber: '#cf9a44', coral: '#d9636f' }[tone] || '#4c6ef5'
  return (
    <svg width={size} height={size} className="-rotate-90 shrink-0">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#1a1e25" strokeWidth={strokeW} />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none" stroke={hex} strokeWidth={strokeW} strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c}
        className="animate-ring-fill"
        style={{ '--ring-target': c - (clamped / 100) * c }}
      />
    </svg>
  )
}

export default function ProjectDetailPage() {
  const { id } = useParams()
  const { projects, tasks, employees, sendEmailNotification } = useData()
  const { openCreateTask } = useModals()
  const { user } = useAuth()
  const admin = user?.role === 'admin'
  const [tab, setTab] = useState('Overview')
  const [showAnalyze, setShowAnalyze] = useState(false)
  const project = projects.find((p) => p.id === id)

  if (!project) {
    return (
      <div className="p-6">
        <p className="text-text-dim text-sm">Project not found.</p>
        <Link to="/app/projects" className="text-signal-indigo text-sm hover:underline">← Back to projects</Link>
      </div>
    )
  }

  const client = clients.find((c) => c.id === project.clientId)
  const projectTasks = tasks.filter((t) => t.projectId === project.id)
  const projectIssues = issues.filter((i) => i.projectId === project.id)
  const dd = daysUntil(project.deadline)

  const handleShareUpdate = () => {
    const overdue = projectTasks.filter((t) => t.status === 'overdue').length
    sendEmailNotification({
      to: client?.contact ? `${client.contact.toLowerCase().replace(/\s+/g, '.')}@example.com` : 'client@example.com',
      subject: `Status update — ${project.name}`,
      body: `Hi ${client?.contact || ''},\n\nQuick update on ${project.name}:\n\nHealth: ${project.health}%\nDeadline: ${project.deadline}\nOverdue tasks: ${overdue}\n\n— Sent from OpsPilot`,
    })
  }

  return (
    <div>
      <Topbar
        title={project.name}
        subtitle={`${client?.name} · Managed by ${project.manager}`}
        actions={
          <>
            <Button variant="ghost" onClick={handleShareUpdate}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4l16 8-16 8V4Z" />
              </svg>
              Email client update
            </Button>
            <Button variant="ghost" onClick={() => setShowAnalyze(true)}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1" />
                <circle cx="12" cy="12" r="3.2" />
              </svg>
              Analyze project health
            </Button>
            {admin && <Button variant="primary" onClick={() => openCreateTask(project.id)}>+ Add task</Button>}
          </>
        }
      />

      <div className="px-6 pt-5">
        <div className="grid grid-cols-4 gap-4 mb-5">
          <Panel className="p-4">
            <p className="text-xs text-text-dim uppercase tracking-wide">Health</p>
            <p className="font-display text-2xl mt-1 tabular">{project.health}%</p>
            <ProgressBar value={project.health} tone={project.health > 70 ? 'teal' : project.health > 50 ? 'amber' : 'coral'} height="h-1" />
          </Panel>
          <Panel className="p-4">
            <p className="text-xs text-text-dim uppercase tracking-wide">Risk</p>
            <div className="mt-2"><Tag tone={riskTone(project.risk)}>{project.risk}</Tag></div>
          </Panel>
          <Panel className="p-4">
            <p className="text-xs text-text-dim uppercase tracking-wide">Deadline</p>
            <p className="font-display text-2xl mt-1 tabular">{dateShort(project.deadline)}</p>
            <p className="text-xs text-text-faint mt-0.5">{dd >= 0 ? `${dd} days left` : `${Math.abs(dd)} days overdue`}</p>
          </Panel>
          <Panel className="p-4">
            <p className="text-xs text-text-dim uppercase tracking-wide">Budget</p>
            <p className="font-display text-2xl mt-1 tabular">{currency(project.spent)}</p>
            <p className="text-xs text-text-faint mt-0.5">of {currency(project.budget)}</p>
          </Panel>
        </div>

        <div className="flex gap-1 border-b border-line mb-5">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-3.5 py-2.5 text-sm border-b-2 -mb-px transition-colors ${
                tab === t ? 'border-signal-indigo text-text' : 'border-transparent text-text-dim hover:text-text'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="px-6 pb-8">
        {tab === 'Overview' && (
          <div className="grid grid-cols-3 gap-4">
            <Panel className="col-span-2 p-5">
              <h3 className="font-display text-sm font-semibold mb-2">About this project</h3>
              <p className="text-sm text-text-dim leading-relaxed">{project.description}</p>
              <div className="grid grid-cols-2 gap-4 mt-5 pt-5 border-t border-line-soft">
                <div>
                  <p className="text-xs text-text-faint">Start date</p>
                  <p className="text-sm mt-0.5">{dateShort(project.start)}</p>
                </div>
                <div>
                  <p className="text-xs text-text-faint">Status</p>
                  <p className="text-sm mt-0.5">{project.status}</p>
                </div>
              </div>
            </Panel>
            <Panel className="p-5">
              <h3 className="font-display text-sm font-semibold mb-3">Task breakdown</h3>
              <div className="space-y-2.5">
                {Object.entries(
                  projectTasks.reduce((acc, t) => {
                    acc[t.status] = (acc[t.status] || 0) + 1
                    return acc
                  }, {})
                ).map(([status, count]) => (
                  <div key={status} className="flex items-center justify-between text-sm">
                    <Tag tone={statusTone[status]}>{statusLabel[status]}</Tag>
                    <span className="tabular text-text-dim">{count}</span>
                  </div>
                ))}
                {projectTasks.length === 0 && <p className="text-xs text-text-faint">No tasks yet — add one to get started.</p>}
              </div>
            </Panel>
          </div>
        )}

        {tab === 'Tasks' && (
          <Panel className="overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs text-text-dim uppercase tracking-wide">
                  <th className="font-medium px-4 py-3">Task</th>
                  <th className="font-medium px-4 py-3">Assignee</th>
                  <th className="font-medium px-4 py-3">Priority</th>
                  <th className="font-medium px-4 py-3">Status</th>
                  <th className="font-medium px-4 py-3">Est. / Actual</th>
                  <th className="font-medium px-4 py-3">Deadline</th>
                </tr>
              </thead>
              <tbody>
                {projectTasks.map((t, i) => {
                  const blockedBy = t.dependsOn
                    .map((dep) => projectTasks.find((x) => x.id === dep))
                    .filter((dep) => dep && dep.status !== 'done')
                  return (
                    <tr
                      key={t.id}
                      className="border-b border-line-soft last:border-0 hover:bg-panel-raised transition-colors align-top animate-row-in"
                      style={{ animationDelay: `${Math.min(i, 10) * 30}ms` }}
                    >
                      <td className="px-4 py-3.5">
                        <p className="font-medium">{t.title}</p>
                        {blockedBy.length > 0 && (
                          <p className="text-xs text-signal-coral mt-1">Blocked by: {blockedBy.map((b) => b.title).join(', ')}</p>
                        )}
                        <div className="flex gap-1.5 mt-1.5">
                          {t.tags.map((tag) => (
                            <span key={tag} className="text-[11px] text-text-faint bg-line-soft px-1.5 py-0.5 rounded">{tag}</span>
                          ))}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-text-dim whitespace-nowrap">{t.assignee}</td>
                      <td className="px-4 py-3.5"><Tag tone={priorityTone(t.priority)}>{t.priority}</Tag></td>
                      <td className="px-4 py-3.5"><Tag tone={statusTone[t.status]}>{statusLabel[t.status]}</Tag></td>
                      <td className="px-4 py-3.5 text-text-dim tabular whitespace-nowrap">{t.estHrs}h / {t.actualHrs}h</td>
                      <td className="px-4 py-3.5 text-text-dim tabular whitespace-nowrap">{dateShort(t.deadline)}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </Panel>
        )}

        {tab === 'Team' && (
          <div className="grid grid-cols-3 gap-4">
            {[...new Set(projectTasks.map((t) => t.assignee))].map((name, i) => {
              const emp = employees.find((e) => e.name === name)
              const myTasks = projectTasks.filter((t) => t.assignee === name)
              if (!emp) return null
              return (
                <Panel key={name} className="p-4 animate-row-in" style={{ animationDelay: `${i * 45}ms` }}>
                  <div className="flex items-center gap-3">
                    <Avatar name={emp.name} color={emp.avatarColor} size={36} />
                    <div>
                      <p className="text-sm font-medium">{emp.name}</p>
                      <p className="text-xs text-text-faint">{emp.role}</p>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-line-soft text-xs text-text-dim flex justify-between">
                    <span>{myTasks.length} tasks on this project</span>
                    <span>{myTasks.filter((t) => t.status === 'overdue').length} overdue</span>
                  </div>
                </Panel>
              )
            })}
          </div>
        )}

        {tab === 'Issues' && (
          <div className="space-y-3">
            {projectIssues.length === 0 && <p className="text-sm text-text-faint">No incidents logged for this project.</p>}
            {projectIssues.map((iss) => (
              <Panel key={iss.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-display text-text-faint tabular">{iss.id}</span>
                    <p className="text-sm font-medium">{iss.title}</p>
                  </div>
                  <Tag tone={priorityTone(iss.priority)}>{iss.priority}</Tag>
                </div>
                <p className="text-xs text-text-faint mt-2">Reported by {iss.reportedBy} · Assigned to {iss.assignedTo}</p>
              </Panel>
            ))}
          </div>
        )}

        {tab === 'Activity' && (
          <Panel className="p-5">
            <div className="space-y-4">
              {auditLog.slice(0, 5).map((log, i) => (
                <div key={i} className="flex gap-3 text-sm">
                  <span className="text-xs text-text-faint tabular w-20 shrink-0 pt-0.5">{log.time}</span>
                  <p className="text-text-dim"><span className="text-text font-medium">{log.actor}</span> {log.action}</p>
                </div>
              ))}
            </div>
          </Panel>
        )}

        {tab === 'Analytics' && (
          <Panel className="p-5">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-display italic text-sm font-semibold">Time tracked vs. estimated</h3>
              <p className="text-xs text-text-faint">Ring shows actual hours logged against the estimate</p>
            </div>
            {projectTasks.length === 0 ? (
              <p className="text-xs text-text-faint">No tasks yet — add one to see analytics.</p>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
                {projectTasks.map((t, i) => {
                  const pct = t.estHrs ? Math.round((t.actualHrs / t.estHrs) * 100) : 0
                  const over = t.actualHrs > t.estHrs
                  return (
                    <div
                      key={t.id}
                      className="flex flex-col items-center text-center gap-2.5 bg-panel-raised border border-line-soft rounded-lg p-4 animate-row-in"
                      style={{ animationDelay: `${i * 60}ms` }}
                    >
                      <div className="relative">
                        <RadialRing pct={pct} tone={over ? 'coral' : pct > 80 ? 'amber' : 'teal'} />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className={`font-display text-sm tabular ${over ? 'text-signal-coral' : 'text-text'}`}>{pct}%</span>
                        </div>
                      </div>
                      <p className="text-xs font-medium leading-snug">{t.title}</p>
                      <p className="text-[11px] text-text-faint tabular">{t.actualHrs}h logged / {t.estHrs}h est.</p>
                    </div>
                  )
                })}
              </div>
            )}
          </Panel>
        )}
      </div>

      {showAnalyze && (
        <AnalyzeProjectModal project={project} projectTasks={projectTasks} onClose={() => setShowAnalyze(false)} />
      )}
    </div>
  )
}
