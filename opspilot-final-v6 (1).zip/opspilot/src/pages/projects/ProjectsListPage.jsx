import { Link } from 'react-router-dom'
import Topbar from '../../components/ui/Topbar'
import { Panel, Tag, ProgressBar, Button } from '../../components/ui/Primitives'
import { useData } from '../../app/providers/DataContext'
import { useModals } from '../../app/providers/ModalProvider'
import { useAuth } from '../../app/providers/AuthContext'
import { riskTone, dateShort, currency } from '../../utils/format'

export default function ProjectsListPage() {
  const { projects, clients, tasks } = useData()
  const { openCreateProject } = useModals()
  const { user } = useAuth()
  const admin = user?.role === 'admin'

  return (
    <div>
      <Topbar
        title="Projects"
        subtitle={`${projects.length} active projects`}
        actions={admin && <Button variant="primary" onClick={openCreateProject}>+ New project</Button>}
      />
      <div className="p-6">
        <Panel className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs text-text-dim uppercase tracking-wide">
                <th className="font-medium px-4 py-3">Project</th>
                <th className="font-medium px-4 py-3">Client</th>
                <th className="font-medium px-4 py-3">Manager</th>
                <th className="font-medium px-4 py-3">Deadline</th>
                <th className="font-medium px-4 py-3 w-40">Health</th>
                <th className="font-medium px-4 py-3">Budget</th>
                <th className="font-medium px-4 py-3">Risk</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((p, i) => {
                const client = clients.find((c) => c.id === p.clientId)
                const openTasks = tasks.filter((t) => t.projectId === p.id && t.status !== 'done').length
                return (
                  <tr
                    key={p.id}
                    className="border-b border-line-soft last:border-0 hover:bg-panel-raised transition-colors animate-row-in"
                    style={{ animationDelay: `${Math.min(i, 8) * 35}ms` }}
                  >
                    <td className="px-4 py-3.5">
                      <Link to={`/app/projects/${p.id}/analytics`} className="font-medium hover:text-signal-indigo transition-colors">
                        {p.name}
                      </Link>
                      <p className="text-xs text-text-faint mt-0.5">{openTasks} open tasks</p>
                    </td>
                    <td className="px-4 py-3.5 text-text-dim">{client?.name}</td>
                    <td className="px-4 py-3.5 text-text-dim">{p.manager}</td>
                    <td className="px-4 py-3.5 text-text-dim tabular">{dateShort(p.deadline)}</td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2">
                        <ProgressBar value={p.health} tone={p.health > 70 ? 'teal' : p.health > 50 ? 'amber' : 'coral'} />
                        <span className="text-xs tabular text-text-dim w-8">{p.health}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-text-dim tabular">{currency(p.budget)}</td>
                    <td className="px-4 py-3.5">
                      <Tag tone={riskTone(p.risk)}>{p.risk}</Tag>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  )
}
