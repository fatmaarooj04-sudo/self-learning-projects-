export const clients = [
  { id: 'cli-1', name: 'ABC Technologies', contact: 'Farhan Iqbal', since: '2024-02-01' },
  { id: 'cli-2', name: 'Northbridge Retail', contact: 'Emma Clarke', since: '2023-11-14' },
  { id: 'cli-3', name: 'Vantage Logistics', contact: 'Omar Siddiqui', since: '2025-01-09' },
]

export const projects = [
  {
    id: 'proj-1',
    name: 'CRM Migration',
    clientId: 'cli-1',
    manager: 'Sara Malik',
    start: '2026-08-01',
    deadline: '2026-09-15',
    health: 72,
    risk: 'medium',
    budget: 18000,
    spent: 11200,
    status: 'At Risk',
    description:
      'Migrating ABC Technologies from a legacy on-prem CRM to a cloud-based platform, including data migration, custom pipelines and staff training.',
  },
  {
    id: 'proj-2',
    name: 'Website Revamp',
    clientId: 'cli-2',
    manager: 'Ahmed Khan',
    start: '2026-07-10',
    deadline: '2026-09-03',
    health: 41,
    risk: 'high',
    budget: 12500,
    spent: 9800,
    status: 'At Risk',
    description:
      'Full redesign and rebuild of Northbridge Retail\'s e-commerce storefront, including a new design system and checkout flow.',
  },
  {
    id: 'proj-3',
    name: 'Mobile App',
    clientId: 'cli-3',
    manager: 'Ali Raza',
    start: '2026-06-01',
    deadline: '2026-10-01',
    health: 88,
    risk: 'low',
    budget: 32000,
    spent: 19400,
    status: 'On Track',
    description:
      'Native iOS and Android companion app for Vantage Logistics drivers, covering route tracking and delivery confirmation.',
  },
  {
    id: 'proj-4',
    name: 'Payment Gateway Integration',
    clientId: 'cli-2',
    manager: 'Ahmed Khan',
    start: '2026-08-10',
    deadline: '2026-09-20',
    health: 63,
    risk: 'medium',
    budget: 9000,
    spent: 4100,
    status: 'On Track',
    description: 'Integrating a regional payment gateway into the Northbridge storefront with fraud checks.',
  },
]

export const tasks = [
  {
    id: 'task-1', projectId: 'proj-1', title: 'Database schema design', status: 'done',
    priority: 'high', assignee: 'Ahmed Khan', department: 'Development',
    estHrs: 12, actualHrs: 14, deadline: '2026-08-10', dependsOn: [], tags: ['backend', 'db'],
  },
  {
    id: 'task-2', projectId: 'proj-1', title: 'API development', status: 'blocked',
    priority: 'high', assignee: 'Ahmed Khan', department: 'Development',
    estHrs: 20, actualHrs: 6, deadline: '2026-08-25', dependsOn: ['task-1'], tags: ['backend', 'api'],
  },
  {
    id: 'task-3', projectId: 'proj-1', title: 'Frontend integration', status: 'todo',
    priority: 'medium', assignee: 'Ali Raza', department: 'Development',
    estHrs: 16, actualHrs: 0, deadline: '2026-09-02', dependsOn: ['task-2'], tags: ['frontend'],
  },
  {
    id: 'task-4', projectId: 'proj-1', title: 'QA regression pass', status: 'todo',
    priority: 'medium', assignee: 'Zoya Ahmed', department: 'Development',
    estHrs: 10, actualHrs: 0, deadline: '2026-09-08', dependsOn: ['task-3'], tags: ['qa'],
  },
  {
    id: 'task-5', projectId: 'proj-1', title: 'Data migration script', status: 'overdue',
    priority: 'high', assignee: 'Ahmed Khan', department: 'Development',
    estHrs: 8, actualHrs: 9, deadline: '2026-08-27', dependsOn: [], tags: ['backend', 'migration'],
  },
  {
    id: 'task-6', projectId: 'proj-2', title: 'Design system tokens', status: 'done',
    priority: 'high', assignee: 'Sara Malik', department: 'Design',
    estHrs: 14, actualHrs: 15, deadline: '2026-07-20', dependsOn: [], tags: ['design'],
  },
  {
    id: 'task-7', projectId: 'proj-2', title: 'Checkout flow build', status: 'overdue',
    priority: 'critical', assignee: 'Ali Raza', department: 'Development',
    estHrs: 18, actualHrs: 12, deadline: '2026-08-22', dependsOn: [], tags: ['frontend', 'checkout'],
  },
  {
    id: 'task-8', projectId: 'proj-2', title: 'Product catalog page', status: 'overdue',
    priority: 'high', assignee: 'Sara Malik', department: 'Design',
    estHrs: 10, actualHrs: 8, deadline: '2026-08-24', dependsOn: [], tags: ['frontend'],
  },
  {
    id: 'task-9', projectId: 'proj-2', title: 'SEO audit', status: 'todo',
    priority: 'low', assignee: 'Hamza Sheikh', department: 'Marketing',
    estHrs: 6, actualHrs: 0, deadline: '2026-09-01', dependsOn: [], tags: ['marketing'],
  },
  {
    id: 'task-10', projectId: 'proj-3', title: 'Route tracking module', status: 'in-progress',
    priority: 'high', assignee: 'Ali Raza', department: 'Development',
    estHrs: 24, actualHrs: 18, deadline: '2026-09-10', dependsOn: [], tags: ['mobile'],
  },
  {
    id: 'task-11', projectId: 'proj-3', title: 'Push notification service', status: 'todo',
    priority: 'medium', assignee: 'Ahmed Khan', department: 'Development',
    estHrs: 12, actualHrs: 0, deadline: '2026-09-18', dependsOn: [], tags: ['backend'],
  },
  {
    id: 'task-12', projectId: 'proj-4', title: 'Gateway sandbox setup', status: 'done',
    priority: 'medium', assignee: 'Ahmed Khan', department: 'Development',
    estHrs: 5, actualHrs: 5, deadline: '2026-08-15', dependsOn: [], tags: ['backend'],
  },
]

export const issues = [
  {
    id: 'INC-2048', title: 'Payment API failing intermittently', projectId: 'proj-4',
    priority: 'critical', status: 'investigating', reportedBy: 'Ahmed Khan', assignedTo: 'Backend Team',
    timeline: [
      { time: '09:42', event: 'Issue created' },
      { time: '09:50', event: 'Assigned to Backend Team' },
      { time: '10:13', event: 'Investigation started' },
      { time: '11:02', event: 'Root cause identified — gateway timeout under load' },
    ],
  },
  {
    id: 'INC-2041', title: 'Checkout page 500 error on mobile Safari', projectId: 'proj-2',
    priority: 'high', status: 'open', reportedBy: 'Sara Malik', assignedTo: 'Frontend Team',
    timeline: [
      { time: '08:15', event: 'Issue created' },
      { time: '08:20', event: 'Awaiting triage' },
    ],
  },
  {
    id: 'INC-2033', title: 'CRM contact sync duplicating records', projectId: 'proj-1',
    priority: 'medium', status: 'resolved', reportedBy: 'Client — ABC Technologies', assignedTo: 'Ahmed Khan',
    timeline: [
      { time: 'Aug 27, 14:02', event: 'Issue created' },
      { time: 'Aug 27, 14:40', event: 'Assigned to Ahmed Khan' },
      { time: 'Aug 28, 09:15', event: 'Fix deployed' },
      { time: 'Aug 28, 10:05', event: 'Issue resolved' },
    ],
  },
  {
    id: 'INC-2029', title: 'Delivery ETA miscalculated on long routes', projectId: 'proj-3',
    priority: 'low', status: 'open', reportedBy: 'Ali Raza', assignedTo: 'Backend Team',
    timeline: [{ time: 'Aug 26, 16:10', event: 'Issue created' }],
  },
]

export const workflows = [
  {
    id: 'wf-1',
    name: 'Client Design Approval',
    steps: ['Designer', 'Project Manager', 'Client', 'Final Approval'],
    active: [
      { item: 'Homepage hero design — Northbridge Retail', currentStep: 2, requestedBy: 'Sara Malik' },
      { item: 'Onboarding flow wireframes — Vantage Logistics', currentStep: 1, requestedBy: 'Sara Malik' },
    ],
  },
  {
    id: 'wf-2',
    name: 'Leave Request',
    steps: ['Employee', 'Manager', 'HR', 'Approved'],
    active: [
      { item: 'Ali Raza — 2 days leave (Sep 4–5)', currentStep: 1, requestedBy: 'Ali Raza' },
      { item: 'Zoya Ahmed — 1 day leave (Sep 2)', currentStep: 2, requestedBy: 'Zoya Ahmed' },
    ],
  },
]

export const auditLog = [
  { time: '12:42 PM', actor: 'Sarah', action: 'changed Project Alpha status from "On Track" to "At Risk"' },
  { time: '12:37 PM', actor: 'Ahmed Khan', action: 'uploaded contract.pdf to CRM Migration' },
  { time: '12:10 PM', actor: 'Admin', action: 'added new employee Zoya Ahmed' },
  { time: '11:54 AM', actor: 'Client — Northbridge Retail', action: 'approved homepage design' },
  { time: '11:20 AM', actor: 'Ali Raza', action: 'marked "Route tracking module" as in progress' },
  { time: '10:45 AM', actor: 'Zoya Ahmed', action: 'logged 4 hours against QA regression pass' },
  { time: '09:50 AM', actor: 'System', action: 'auto-assigned INC-2048 to Backend Team' },
]

export const velocity = [
  { week: 'Week 1', tasks: 14 },
  { week: 'Week 2', tasks: 19 },
  { week: 'Week 3', tasks: 27 },
  { week: 'Week 4', tasks: 21 },
]

export const completionBreakdown = [
  { name: 'Completed', value: 68, tone: 'teal' },
  { name: 'In Progress', value: 21, tone: 'indigo' },
  { name: 'Blocked', value: 7, tone: 'coral' },
  { name: 'Overdue', value: 4, tone: 'amber' },
]

export const departmentPerformance = [
  { name: 'Development', value: 84 },
  { name: 'Design', value: 91 },
  { name: 'Marketing', value: 73 },
  { name: 'HR', value: 88 },
]
