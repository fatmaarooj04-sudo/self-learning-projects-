import { HashRouter, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './app/providers/AuthContext'
import { DataProvider } from './app/providers/DataContext'
import { ModalProvider } from './app/providers/ModalProvider'
import AppLayout from './app/routes/AppLayout'
import LandingPage from './pages/marketing/LandingPage'
import LoginPage from './pages/auth/LoginPage'
import SignupPage from './pages/auth/SignupPage'
import ProjectAnalyticsPage from './pages/projects/ProjectAnalyticsPage'
import TasksPage from './pages/tasks/TasksPage'
import DashboardPage from './pages/dashboard/DashboardPage'
import ProjectsListPage from './pages/projects/ProjectsListPage'
import ProjectDetailPage from './pages/projects/ProjectDetailPage'
import EmployeesPage from './pages/employees/EmployeesPage'
import IssuesPage from './pages/issues/IssuesPage'
import WorkflowsPage from './pages/workflows/WorkflowsPage'
import AnalyticsPage from './pages/analytics/AnalyticsPage'
import AuditLogPage from './pages/audit/AuditLogPage'
import ClientPortalPage from './pages/clients/ClientPortalPage'

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
      <ModalProvider>
      <HashRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />

          <Route path="/app" element={<AppLayout />}>
            <Route index element={<DashboardPage />} />
            <Route path="projects" element={<ProjectsListPage />} />
            <Route path="projects/:id" element={<ProjectDetailPage />} />
            <Route path="projects/:id/analytics" element={<ProjectAnalyticsPage />} />
            <Route path="tasks" element={<TasksPage />} />
            <Route path="employees" element={<EmployeesPage />} />
            <Route path="issues" element={<IssuesPage />} />
            <Route path="workflows" element={<WorkflowsPage />} />
            <Route path="analytics" element={<AnalyticsPage />} />
            <Route path="audit" element={<AuditLogPage />} />
            <Route path="portal" element={<ClientPortalPage />} />
          </Route>
        </Routes>
      </HashRouter>
      </ModalProvider>
      </DataProvider>
    </AuthProvider>
  )
}
