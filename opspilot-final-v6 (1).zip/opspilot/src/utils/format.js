export const currency = (n) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n)

export const dateShort = (iso) =>
  new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })

export const daysUntil = (iso) => {
  const diff = new Date(iso).setHours(0, 0, 0, 0) - new Date('2026-08-31').setHours(0, 0, 0, 0)
  return Math.round(diff / 86400000)
}

export const toneClasses = {
  teal: { text: 'text-[#2fb67c]', bg: 'bg-[#2fb67c]/10', border: 'border-[#2fb67c]/25', dot: 'bg-[#2fb67c]' },
  indigo: { text: 'text-[#4c6ef5]', bg: 'bg-[#4c6ef5]/10', border: 'border-[#4c6ef5]/25', dot: 'bg-[#4c6ef5]' },
  amber: { text: 'text-[#cf9a44]', bg: 'bg-[#cf9a44]/10', border: 'border-[#cf9a44]/25', dot: 'bg-[#cf9a44]' },
  coral: { text: 'text-[#d9636f]', bg: 'bg-[#d9636f]/10', border: 'border-[#d9636f]/25', dot: 'bg-[#d9636f]' },
}

export const riskTone = (risk) => (risk === 'high' ? 'coral' : risk === 'medium' ? 'amber' : 'teal')
export const priorityTone = (p) =>
  p === 'critical' ? 'coral' : p === 'high' ? 'amber' : p === 'medium' ? 'indigo' : 'teal'
