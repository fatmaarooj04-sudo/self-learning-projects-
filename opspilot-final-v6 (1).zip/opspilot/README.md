# OpsPilot — Business Operations Command Center

Frontend scaffold for OpsPilot, a centralized operations platform for small/medium
businesses: projects, tasks with dependencies, employee workload, incident
management, client portal, approval workflows, audit log, and analytics.

## Stack

- React 19 + Vite
- React Router (HashRouter, so it works from a static file:// or any static host)
- Tailwind CSS v4
- Recharts for charts

All data is mocked in `src/data/` — wire up `src/services/` to your Django/REST
API to make it live.

## Auth & roles

There's a landing page at `/`, a login page at `/login` with three role tabs
(**Admin**, **Employee**, **Client**), and the app itself lives under `/app`.
It's a demo auth flow — any password signs you in as the selected role,
stored in `localStorage` via `src/app/providers/AuthContext.jsx`. Swap
`login()` for a real call to `/api/auth/login` when you connect a backend.

- **Admin** — full sidebar: Overview, Projects, Team & Workload, Incidents, Approvals, Analytics, Audit Log, Client Portal.
- **Employee** — Overview, Projects, Team & Workload, Incidents, Approvals.
- **Client** — routed straight to a single restricted "Your Projects" view, no internal team/budget data.

## Getting started

```bash
npm install
npm run dev       # start dev server
npm run build     # production build -> dist/
```

## Project structure

```
src/
├── app/
│   ├── providers/AuthContext.jsx   # demo role-based auth
│   └── routes/AppLayout.jsx        # sidebar shell + auth guard for /app/*
├── components/
│   ├── ui/           # Sidebar, Topbar, Panel, Tag, ProgressBar, Button, Avatar...
│   ├── forms/ tables/ charts/ modals/
├── features/
│   ├── analytics/     # AnalyzeProjectModal — AI-assisted project health readout
│   └── auth/ projects/ tasks/ employees/ clients/ issues/ workflows/
├── pages/
│   ├── marketing/LandingPage.jsx   # public marketing homepage
│   ├── auth/LoginPage.jsx          # role-select sign-in (Admin/Employee/Client)
│   ├── dashboard/      Overview — stats, project health, workload, risk feed
│   ├── projects/        List + detail (Overview/Tasks/Team/Issues/Activity/Analytics tabs)
│   ├── employees/        Team workload matrix + "Optimize team" rebalance
│   ├── issues/            Incident list + timeline (Jira-lite)
│   ├── workflows/          Approval workflow engine (design approval, leave request)
│   ├── analytics/            Velocity, completion breakdown, department performance
│   ├── audit/                  Audit log
│   └── clients/                 Client portal (restricted, role-based view)
├── services/          # api.js, auth.js, projectService.js — stub for your backend
├── hooks/ utils/ constants/ data/
```

## Suggested API surface (Django)

```
POST   /api/auth/login
GET    /api/projects            POST /api/projects
GET    /api/projects/:id        PATCH /api/projects/:id
GET    /api/tasks               POST /api/tasks           PATCH /api/tasks/:id
GET    /api/employees           GET  /api/workload
GET    /api/issues              POST /api/issues
GET    /api/analytics/project-health
```

## Notes

- The "Analyze project health" action in the project detail page simulates an
  AI decision-support call — swap `buildAnalysis()` in
  `src/features/analytics/AnalyzeProjectModal.jsx` for a real request to your
  completions endpoint, passing the project + task JSON as context.
- Role-based access (Admin/Manager/Employee/Client) is illustrated by the
  Client Portal page, which only surfaces client-safe fields.
