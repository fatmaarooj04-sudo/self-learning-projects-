# Letters to Future Me — React

A frontend-only React/Vite project. Data is stored in browser localStorage, so no backend or API is required.

## Run in VS Code
1. Install Node.js LTS.
2. Extract/open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Run `npm install`.
5. Run `npm run dev`.
6. Open the localhost URL Vite prints (usually `http://localhost:5173`).

## Features
- Home dashboard
- Write and seal letters
- Four visual themes
- Future open date
- Sent letters archive
- Preview sealed envelope
- Opened-letter journal view
- Happy / not-yet / in-between reactions
- Celebration state with party-popper message
- Motivation state when a goal is not complete
- Reply to your past self
- Progress dashboard from letter goals
- localStorage persistence
