export default function Topbar({ title, subtitle, actions }) {
  return (
    <div className="h-16 border-b border-line flex items-center justify-between px-6 sticky top-0 bg-ink/95 backdrop-blur z-10">
      <div>
        <h1 className="font-display text-[19px] leading-tight">{title}</h1>
        {subtitle && <p className="text-xs text-text-faint mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-2">{actions}</div>
    </div>
  )
}
