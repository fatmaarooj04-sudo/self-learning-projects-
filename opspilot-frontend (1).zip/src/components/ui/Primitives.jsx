import { toneClasses } from '../../utils/format'

export function Panel({ children, className = '', ...rest }) {
  return (
    <div className={`bg-panel border border-line rounded-lg ${className}`} {...rest}>
      {children}
    </div>
  )
}

export function Tag({ tone = 'indigo', children, subtle = true }) {
  const c = toneClasses[tone] || toneClasses.indigo
  return (
    <span
      className={`inline-flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide px-2 py-[3px] rounded ${c.text} ${subtle ? c.bg : ''} border ${c.border}`}
    >
      {children}
    </span>
  )
}

export function ProgressBar({ value, tone = 'indigo', height = 'h-1' }) {
  const c = toneClasses[tone] || toneClasses.indigo
  return (
    <div className={`w-full ${height} rounded-full bg-line-soft overflow-hidden`}>
      <div className={`${height} rounded-full ${c.dot}`} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  )
}

export function StatCard({ label, value, sub, tone }) {
  const c = tone ? toneClasses[tone] : null
  return (
    <Panel className="p-4">
      <p className="text-[11px] text-text-faint uppercase tracking-wider font-medium">{label}</p>
      <p className={`font-display text-[28px] leading-none mt-2 tabular ${c ? c.text : 'text-text'}`}>{value}</p>
      {sub && <p className="text-xs text-text-faint mt-1.5">{sub}</p>}
    </Panel>
  )
}

export function Avatar({ name, color = '#4c6ef5', size = 32 }) {
  const initials = name.split(' ').map((p) => p[0]).slice(0, 2).join('')
  return (
    <div
      className="rounded-full flex items-center justify-center text-[11px] font-semibold text-white shrink-0"
      style={{ width: size, height: size, background: color }}
    >
      {initials}
    </div>
  )
}

export function Button({ children, variant = 'primary', className = '', ...rest }) {
  const base = 'inline-flex items-center justify-center gap-1.5 text-[13px] font-medium px-3.5 py-2 rounded-md transition-colors whitespace-nowrap'
  const variants = {
    primary: 'bg-brand text-white hover:bg-[#3f5edb]',
    ghost: 'bg-transparent border border-line text-text hover:bg-panel-raised',
    subtle: 'bg-panel-raised text-text-dim hover:text-text border border-line',
    dark: 'bg-text text-ink hover:bg-white',
  }
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...rest}>
      {children}
    </button>
  )
}

export function Input({ className = '', ...rest }) {
  return (
    <input
      className={`w-full bg-panel-raised border border-line rounded-md px-3.5 py-2.5 text-sm text-text placeholder:text-text-faint outline-none focus:border-brand transition-colors ${className}`}
      {...rest}
    />
  )
}
