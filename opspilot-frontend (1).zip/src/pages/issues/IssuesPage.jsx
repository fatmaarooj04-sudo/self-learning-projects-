import { useState } from 'react'
import Topbar from '../../components/ui/Topbar'
import { Panel, Tag, Button } from '../../components/ui/Primitives'
import { issues, projects } from '../../data/projects'
import { priorityTone } from '../../utils/format'

const statusTone = { open: 'amber', investigating: 'indigo', resolved: 'teal' }
const statusLabel = { open: 'Open', investigating: 'Investigating', resolved: 'Resolved' }

export default function IssuesPage() {
  const [selected, setSelected] = useState(issues[0])

  return (
    <div>
      <Topbar
        title="Incidents"
        subtitle={`${issues.filter((i) => i.status !== 'resolved').length} open`}
        actions={<Button variant="primary">+ Report incident</Button>}
      />
      <div className="p-6 grid grid-cols-5 gap-4">
        <div className="col-span-2 space-y-2.5">
          {issues.map((iss) => {
            const project = projects.find((p) => p.id === iss.projectId)
            return (
              <button
                key={iss.id}
                onClick={() => setSelected(iss)}
                className={`w-full text-left p-4 rounded-md border transition-colors ${
                  selected.id === iss.id ? 'border-signal-indigo bg-panel-raised' : 'border-line bg-panel hover:border-line'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-display text-text-faint tabular">{iss.id}</span>
                  <Tag tone={priorityTone(iss.priority)}>{iss.priority}</Tag>
                </div>
                <p className="text-sm font-medium">{iss.title}</p>
                <p className="text-xs text-text-faint mt-1">{project?.name}</p>
              </button>
            )
          })}
        </div>

        <Panel className="col-span-3 p-5 h-fit">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-display text-text-faint tabular">{selected.id}</span>
            <Tag tone={statusTone[selected.status]}>{statusLabel[selected.status]}</Tag>
          </div>
          <h2 className="font-display text-lg font-semibold mt-1">{selected.title}</h2>
          <div className="flex gap-6 mt-3 text-xs text-text-dim">
            <span>Reported by <span className="text-text">{selected.reportedBy}</span></span>
            <span>Assigned to <span className="text-text">{selected.assignedTo}</span></span>
          </div>

          <div className="mt-6 pt-5 border-t border-line-soft">
            <p className="text-xs font-medium text-text-dim uppercase tracking-wide mb-3">Timeline</p>
            <div className="space-y-3">
              {selected.timeline.map((ev, i) => (
                <div key={i} className="flex gap-3 text-sm">
                  <span className="text-xs text-text-faint tabular w-16 shrink-0 pt-0.5">{ev.time}</span>
                  <div className="relative pl-4">
                    <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-signal-indigo" />
                    <span className="text-text-dim">{ev.event}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>
    </div>
  )
}
