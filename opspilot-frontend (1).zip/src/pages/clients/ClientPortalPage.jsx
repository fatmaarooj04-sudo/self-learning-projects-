import { useState } from 'react'
import Topbar from '../../components/ui/Topbar'
import { Panel, Tag, ProgressBar } from '../../components/ui/Primitives'
import { clients, projects, auditLog } from '../../data/projects'

export default function ClientPortalPage() {
  const [clientId, setClientId] = useState(clients[0].id)
  const client = clients.find((c) => c.id === clientId)
  const clientProjects = projects.filter((p) => p.clientId === clientId)

  // client-facing updates only — no internal employee/budget detail
  const updates = [
    'API integration completed',
    'UI testing completed',
    'Payment gateway delayed',
  ]

  return (
    <div>
      <Topbar
        title="Client Portal"
        subtitle="Restricted view — clients see status only, no internal team data"
        actions={
          <select
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
            className="bg-panel-raised border border-line rounded text-sm px-3 py-1.5 text-text"
          >
            {clients.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        }
      />

      <div className="p-6">
        <Panel className="p-1 mb-5 inline-flex items-center gap-2 px-3 py-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-signal-amber" />
          <span className="text-xs text-text-dim">Viewing as client — internal fields are hidden in this role</span>
        </Panel>

        <div className="grid grid-cols-3 gap-4">
          <Panel className="col-span-2 p-5">
            <h2 className="font-display text-lg font-semibold mb-1">{client.name}</h2>
            <p className="text-xs text-text-faint mb-5">Primary contact: {client.contact}</p>

            <p className="text-xs font-medium text-text-dim uppercase tracking-wide mb-3">Projects</p>
            <div className="space-y-4">
              {clientProjects.map((p) => (
                <div key={p.id}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm">{p.name}</span>
                    <span className="text-xs tabular text-text-dim">{p.health}%</span>
                  </div>
                  <ProgressBar value={p.health} tone={p.health > 70 ? 'teal' : p.health > 50 ? 'amber' : 'coral'} />
                </div>
              ))}
              {clientProjects.length === 0 && <p className="text-sm text-text-faint">No active projects.</p>}
            </div>
          </Panel>

          <Panel className="p-5">
            <p className="text-xs font-medium text-text-dim uppercase tracking-wide mb-3">Recent updates</p>
            <div className="space-y-2.5">
              {updates.map((u, i) => (
                <div key={i} className="flex items-start gap-2 text-sm">
                  <span className="text-signal-teal mt-0.5">{u.includes('delayed') ? '⚠' : '✓'}</span>
                  <span className={u.includes('delayed') ? 'text-signal-amber' : 'text-text-dim'}>{u}</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  )
}
