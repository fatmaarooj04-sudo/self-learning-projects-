import Topbar from '../../components/ui/Topbar'
import { Panel, Button } from '../../components/ui/Primitives'
import { workflows } from '../../data/projects'

export default function WorkflowsPage() {
  return (
    <div>
      <Topbar title="Approvals" subtitle="Active workflow instances" actions={<Button variant="primary">+ New request</Button>} />
      <div className="p-6 space-y-6">
        {workflows.map((wf) => (
          <Panel key={wf.id} className="p-5">
            <h2 className="font-display text-sm font-semibold mb-4">{wf.name}</h2>

            <div className="flex items-center mb-6">
              {wf.steps.map((step, i) => (
                <div key={step} className="flex items-center flex-1 last:flex-none">
                  <div className="flex flex-col items-center gap-1.5">
                    <div className="w-7 h-7 rounded-full border-2 border-line-soft flex items-center justify-center text-xs font-display text-text-faint">
                      {i + 1}
                    </div>
                    <span className="text-xs text-text-faint whitespace-nowrap">{step}</span>
                  </div>
                  {i < wf.steps.length - 1 && <div className="flex-1 h-px bg-line-soft mx-2 mb-4" />}
                </div>
              ))}
            </div>

            <div className="space-y-2.5">
              {wf.active.map((item, i) => (
                <div key={i} className="flex items-center justify-between border border-line-soft rounded p-3">
                  <div>
                    <p className="text-sm">{item.item}</p>
                    <p className="text-xs text-text-faint mt-0.5">
                      Requested by {item.requestedBy} · currently with <span className="text-signal-indigo">{wf.steps[item.currentStep]}</span>
                    </p>
                  </div>
                  <div className="flex gap-1.5 shrink-0">
                    {wf.steps.map((_, si) => (
                      <span
                        key={si}
                        className={`w-1.5 h-1.5 rounded-full ${si <= item.currentStep ? 'bg-signal-indigo' : 'bg-line-soft'}`}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        ))}
      </div>
    </div>
  )
}
