import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import Topbar from '../../components/ui/Topbar'
import { Panel, StatCard } from '../../components/ui/Primitives'
import { velocity, completionBreakdown, departmentPerformance } from '../../data/projects'

const toneHex = { teal: '#37d0a8', indigo: '#7c8cf8', amber: '#f2ab3d', coral: '#f2586f' }

const tooltipStyle = {
  background: '#1e232c',
  border: '1px solid #2a2f3a',
  borderRadius: 6,
  fontSize: 12,
  color: '#e7e9ee',
}

export default function AnalyticsPage() {
  return (
    <div>
      <Topbar title="Analytics" subtitle="Operational metrics across all projects" />
      <div className="p-6 space-y-5">
        <div className="grid grid-cols-4 gap-4">
          <StatCard label="Avg. project health" value="76%" tone="teal" />
          <StatCard label="On-time delivery" value="82%" tone="indigo" />
          <StatCard label="Tasks this month" value="81" />
          <StatCard label="Avg. resolution time" value="6.4h" tone="amber" />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <Panel className="col-span-2 p-5">
            <h3 className="font-display text-sm font-semibold mb-4">Project velocity</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={velocity} margin={{ left: -20 }}>
                  <CartesianGrid stroke="#22262f" vertical={false} />
                  <XAxis dataKey="week" stroke="#656c78" fontSize={12} tickLine={false} axisLine={{ stroke: '#2a2f3a' }} />
                  <YAxis stroke="#656c78" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip cursor={{ fill: '#22262f' }} contentStyle={tooltipStyle} />
                  <Bar dataKey="tasks" fill="#7c8cf8" radius={[3, 3, 0, 0]} name="Tasks completed" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Panel>

          <Panel className="p-5">
            <h3 className="font-display text-sm font-semibold mb-4">Completion breakdown</h3>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={completionBreakdown} dataKey="value" nameKey="name" innerRadius={45} outerRadius={70} paddingAngle={2}>
                    {completionBreakdown.map((d, i) => (
                      <Cell key={i} fill={toneHex[d.tone]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-1.5 mt-2">
              {completionBreakdown.map((d) => (
                <div key={d.name} className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-text-dim">
                    <span className="w-2 h-2 rounded-full" style={{ background: toneHex[d.tone] }} />
                    {d.name}
                  </span>
                  <span className="tabular">{d.value}%</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        <Panel className="p-5">
          <h3 className="font-display text-sm font-semibold mb-4">Department performance</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentPerformance} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid stroke="#22262f" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} stroke="#656c78" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis type="category" dataKey="name" stroke="#9aa1ad" fontSize={13} tickLine={false} axisLine={false} width={100} />
                <Tooltip cursor={{ fill: '#22262f' }} contentStyle={tooltipStyle} />
                <Bar dataKey="value" fill="#37d0a8" radius={[0, 3, 3, 0]} barSize={18} name="Performance score" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      </div>
    </div>
  )
}
