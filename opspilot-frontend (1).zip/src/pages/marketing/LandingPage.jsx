import { Link } from 'react-router-dom'

const modules = [
  {
    n: '01',
    title: 'Project intelligence',
    body: 'Every project rolls up client, budget, timeline and task health into one score — so risk surfaces before it becomes a missed deadline.',
  },
  {
    n: '02',
    title: 'Workload balancing',
    body: 'See exactly who is overloaded and who has capacity, then rebalance work across the team in one action.',
  },
  {
    n: '03',
    title: 'Incident management',
    body: 'Log, assign and track operational issues with a timestamped timeline — from first report to resolution.',
  },
  {
    n: '04',
    title: 'Approval workflows',
    body: 'Model any multi-step approval — design sign-off, leave requests, client review — with a reusable workflow engine.',
  },
  {
    n: '05',
    title: 'Client portal',
    body: 'Give clients a restricted, read-only view of their own project status — without exposing internal team or budget data.',
  },
  {
    n: '06',
    title: 'Audit trail',
    body: 'Every status change, upload and approval is recorded automatically, in order, for full operational accountability.',
  },
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-ink text-text">
      {/* Nav */}
      <header className="border-b border-line">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4c6ef5" strokeWidth="2">
              <path d="M12 2 3 7v6c0 5 4 8 9 9 5-1 9-4 9-9V7l-9-5Z" />
              <path d="M9 12l2 2 4-4" />
            </svg>
            <span className="font-semibold text-[15px] tracking-tight">OpsPilot</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-[13px] text-text-dim">
            <a href="#modules" className="hover:text-text transition-colors">Product</a>
            <a href="#workflow" className="hover:text-text transition-colors">How it works</a>
            <a href="#clients" className="hover:text-text transition-colors">Who it's for</a>
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-[13px] text-text-dim hover:text-text transition-colors">Sign in</Link>
            <Link
              to="/login"
              className="text-[13px] font-medium bg-brand text-white px-3.5 py-2 rounded-md hover:bg-[#3f5edb] transition-colors"
            >
              Request a demo
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="border-b border-line bg-grid relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-6 pt-20 pb-24 grid md:grid-cols-2 gap-16 items-center relative">
          <div>
            <p className="text-[13px] text-brand font-medium tracking-wide mb-5">Operations platform for agencies &amp; software houses</p>
            <h1 className="font-display text-[44px] md:text-[54px] leading-[1.08] mb-6">
              Run the business,<br />not a stack of spreadsheets.
            </h1>
            <p className="text-[15px] text-text-dim leading-relaxed max-w-md mb-9">
              OpsPilot pulls projects, tasks, people, clients and incidents into one system, so
              managers can see what's at risk before a client has to ask.
            </p>
            <div className="flex items-center gap-3">
              <Link
                to="/login"
                className="text-sm font-medium bg-brand text-white px-5 py-3 rounded-md hover:bg-[#3f5edb] transition-colors"
              >
                Sign in to workspace
              </Link>
              <a href="#modules" className="text-sm font-medium border border-line px-5 py-3 rounded-md hover:bg-panel-raised transition-colors">
                See what's inside
              </a>
            </div>
            <div className="flex items-center gap-8 mt-12 pt-8 border-t border-line-soft">
              <div>
                <p className="font-display text-2xl">24</p>
                <p className="text-xs text-text-faint mt-0.5">Active projects tracked</p>
              </div>
              <div>
                <p className="font-display text-2xl">78%</p>
                <p className="text-xs text-text-faint mt-0.5">Avg. team utilization</p>
              </div>
              <div>
                <p className="font-display text-2xl">6.4h</p>
                <p className="text-xs text-text-faint mt-0.5">Avg. incident resolution</p>
              </div>
            </div>
          </div>

          {/* product preview panel */}
          <div className="relative pb-14 md:pr-8">
            <div className="bg-panel border border-line rounded-lg shadow-2xl shadow-black/40 overflow-hidden">
              <div className="h-9 border-b border-line flex items-center gap-1.5 px-3.5">
                <span className="w-2.5 h-2.5 rounded-full bg-line-soft" />
                <span className="w-2.5 h-2.5 rounded-full bg-line-soft" />
                <span className="w-2.5 h-2.5 rounded-full bg-line-soft" />
              </div>
              <div className="p-5">
                <p className="text-xs text-text-faint mb-3">Project health</p>
                <div className="space-y-3.5 mb-5">
                  {[
                    ['CRM Migration', 72, '#cf9a44'],
                    ['Website Revamp', 41, '#d9636f'],
                    ['Mobile App', 88, '#2fb67c'],
                  ].map(([name, val, color]) => (
                    <div key={name}>
                      <div className="flex justify-between text-[13px] mb-1">
                        <span className="text-text-dim">{name}</span>
                        <span className="tabular text-text-faint">{val}%</span>
                      </div>
                      <div className="h-1 rounded-full bg-line-soft overflow-hidden">
                        <div className="h-1 rounded-full" style={{ width: `${val}%`, background: color }} />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="border border-line rounded-md p-3">
                    <p className="text-[11px] text-text-faint uppercase tracking-wide">Overdue tasks</p>
                    <p className="font-display text-xl mt-1 text-[#d9636f]">17</p>
                  </div>
                  <div className="border border-line rounded-md p-3">
                    <p className="text-[11px] text-text-faint uppercase tracking-wide">Open incidents</p>
                    <p className="font-display text-xl mt-1 text-[#cf9a44]">6</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-2 -right-2 translate-y-full bg-panel border border-line rounded-lg p-3.5 shadow-xl shadow-black/40 hidden md:block w-64">
              <p className="text-[11px] text-text-faint uppercase tracking-wide mb-1">Team utilization</p>
              <p className="font-display text-lg text-[#4c6ef5]">Sara Malik — 115%</p>
              <p className="text-[11px] text-text-faint mt-0.5">Overloaded — rebalance suggested</p>
            </div>
          </div>
        </div>
      </section>

      {/* Modules */}
      <section id="modules" className="max-w-6xl mx-auto px-6 py-24 border-b border-line">
        <div className="max-w-lg mb-14">
          <p className="text-[13px] text-brand font-medium tracking-wide mb-3">What's inside</p>
          <h2 className="font-display text-3xl leading-tight">Eight systems, one source of truth.</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-px bg-line rounded-lg overflow-hidden border border-line">
          {modules.map((m) => (
            <div key={m.n} className="bg-ink p-6">
              <p className="font-display text-sm text-text-faint mb-4">{m.n}</p>
              <h3 className="text-[15px] font-semibold mb-2">{m.title}</h3>
              <p className="text-[13px] text-text-dim leading-relaxed">{m.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="workflow" className="max-w-6xl mx-auto px-6 py-24 border-b border-line">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <p className="text-[13px] text-brand font-medium tracking-wide mb-3">How it works</p>
            <h2 className="font-display text-3xl leading-tight mb-6">Built around one relationship chain.</h2>
            <p className="text-[15px] text-text-dim leading-relaxed max-w-md">
              Clients, projects, tasks, people, deadlines and incidents aren't separate lists — they're
              connected. That's what lets OpsPilot tell you a project is at risk before you have to
              go looking for it.
            </p>
          </div>
          <div className="flex flex-col gap-0">
            {['Client', 'Project', 'Tasks', 'Employees', 'Deadlines', 'Issues', 'Performance'].map((step, i, arr) => (
              <div key={step} className="flex items-center gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-md border border-line bg-panel flex items-center justify-center text-xs font-display text-text-dim shrink-0">
                    {i + 1}
                  </div>
                  {i < arr.length - 1 && <div className="w-px h-8 bg-line" />}
                </div>
                <span className="text-sm pb-8">{step}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Who it's for */}
      <section id="clients" className="max-w-6xl mx-auto px-6 py-24 border-b border-line">
        <p className="text-[13px] text-brand font-medium tracking-wide mb-3">Who it's for</p>
        <h2 className="font-display text-3xl leading-tight mb-10 max-w-lg">
          Teams that run client work, not just internal projects.
        </h2>
        <div className="grid md:grid-cols-4 gap-6 text-sm text-text-dim">
          {['Software houses', 'Digital agencies', 'Marketing agencies', 'IT consultancies'].map((t) => (
            <div key={t} className="border-t border-line pt-4">{t}</div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-6 py-24 text-center">
        <h2 className="font-display text-3xl mb-6">See your operations in one place.</h2>
        <Link
          to="/login"
          className="inline-flex text-sm font-medium bg-brand text-white px-6 py-3 rounded-md hover:bg-[#3f5edb] transition-colors"
        >
          Sign in to workspace
        </Link>
      </section>

      <footer className="border-t border-line">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between text-xs text-text-faint">
          <span>© 2026 OpsPilot</span>
          <span>Operations command center for small &amp; medium businesses</span>
        </div>
      </footer>
    </div>
  )
}
