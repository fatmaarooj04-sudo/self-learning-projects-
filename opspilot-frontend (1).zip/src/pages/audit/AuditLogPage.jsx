import Topbar from '../../components/ui/Topbar'
import { Panel } from '../../components/ui/Primitives'
import { auditLog } from '../../data/projects'

export default function AuditLogPage() {
  return (
    <div>
      <Topbar title="Audit Log" subtitle="Every important action, recorded" />
      <div className="p-6">
        <Panel className="p-5">
          <div className="space-y-5">
            {auditLog.map((log, i) => (
              <div key={i} className="flex gap-4">
                <div className="flex flex-col items-center pt-1">
                  <span className="w-2 h-2 rounded-full bg-signal-indigo" />
                  {i < auditLog.length - 1 && <span className="w-px flex-1 bg-line-soft mt-1" />}
                </div>
                <div className="pb-1">
                  <p className="text-xs text-text-faint tabular">{log.time}</p>
                  <p className="text-sm mt-0.5"><span className="font-medium">{log.actor}</span> <span className="text-text-dim">{log.action}</span></p>
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  )
}
