import { Link } from 'react-router-dom'
import Topbar from '../../components/ui/Topbar'
import { Panel, Tag, ProgressBar, StatCard, Button } from '../../components/ui/Primitives'
import { projects, tasks, issues } from '../../data/projects'
import { employees, workloadStatus } from '../../data/employees'
import { daysUntil, riskTone } from '../../utils/format'

export default function DashboardPage() {
  const overdueTasks = tasks.filter((t) => t.status === 'overdue')
  const openIssues = issues.filter((i) => i.status !== 'resolved')
  const avgUtilization = Math.round(
    employees.reduce((sum, e) => sum + e.assignedHrs / e.capacityHrs, 0) / employees.length * 100
  )

  const riskFeed = [...projects].sort((a, b) => a.health - b.health)

  return (
    <div>
      <Topbar
        title="Good morning, Arooj"
        subtitle="Operations overview — August 31, 2026"
        actions={
          <>
            <Button variant="ghost">+ New project</Button>
            <Button variant="primary">Create task</Button>
          </>
        }
      />

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-4 gap-4">
          <StatCard label="Active projects" value={projects.length} sub="across 3 clients" />
          <StatCard label="Overdue tasks" value={overdueTasks.length} tone="coral" sub="needs attention" />
          <StatCard label="Team utilization" value={`${avgUtilization}%`} tone={avgUtilization > 90 ? 'coral' : 'indigo'} sub={`${employees.length} team members`} />
          <StatCard label="Open incidents" value={openIssues.length} tone="amber" sub={`${issues.filter(i=>i.priority==='critical').length} critical`} />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <Panel className="col-span-2 p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-sm font-semibold">Project health</h2>
              <Link to="/app/projects" className="text-xs text-signal-indigo hover:underline">View all →</Link>
            </div>
            <div className="space-y-4">
              {projects.map((p) => (
                <Link to={`/app/projects/${p.id}`} key={p.id} className="block group">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm group-hover:text-signal-indigo transition-colors">{p.name}</span>
                    <span className="text-xs tabular text-text-dim">{p.health}%</span>
                  </div>
                  <ProgressBar value={p.health} tone={p.health > 70 ? 'teal' : p.health > 50 ? 'amber' : 'coral'} />
                </Link>
              ))}
            </div>
          </Panel>

          <Panel className="p-5">
            <h2 className="font-display text-sm font-semibold mb-4">Team workload</h2>
            <div className="space-y-4">
              {employees.slice(0, 4).map((e) => {
                const pct = Math.round((e.assignedHrs / e.capacityHrs) * 100)
                const status = workloadStatus(e.assignedHrs, e.capacityHrs)
                return (
                  <div key={e.id}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm">{e.name.split(' ')[0]}</span>
                      <span className="text-xs tabular text-text-dim">{pct}%</span>
                    </div>
                    <ProgressBar value={pct} tone={status.tone} />
                  </div>
                )
              })}
            </div>
          </Panel>
        </div>

        <Panel className="p-5">
          <h2 className="font-display text-sm font-semibold mb-4">Risk feed</h2>
          <div className="grid grid-cols-3 gap-4">
            {riskFeed.map((p) => {
              const overdueCount = tasks.filter((t) => t.projectId === p.id && t.status === 'overdue').length
              const dd = daysUntil(p.deadline)
              return (
                <Link
                  to={`/app/projects/${p.id}`}
                  key={p.id}
                  className="border border-line rounded p-3.5 hover:border-signal-indigo/50 transition-colors"
                >
                  <Tag tone={riskTone(p.risk)}>{p.risk === 'high' ? 'High risk' : p.risk === 'medium' ? 'Attention required' : 'Healthy'}</Tag>
                  <p className="text-sm mt-2.5 font-medium">{p.name}</p>
                  <p className="text-xs text-text-faint mt-1">
                    {dd >= 0 ? `Deadline in ${dd} days` : `${Math.abs(dd)} days overdue`}
                    {overdueCount > 0 && ` · ${overdueCount} overdue task${overdueCount > 1 ? 's' : ''}`}
                  </p>
                </Link>
              )
            })}
          </div>
        </Panel>
      </div>
    </div>
  )
}
