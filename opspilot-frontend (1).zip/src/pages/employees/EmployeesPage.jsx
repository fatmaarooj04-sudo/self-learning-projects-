import { useState } from 'react'
import Topbar from '../../components/ui/Topbar'
import { Panel, Tag, ProgressBar, Avatar, Button } from '../../components/ui/Primitives'
import { employees, workloadStatus } from '../../data/employees'

export default function EmployeesPage() {
  const [optimized, setOptimized] = useState(false)

  // naive redistribution: shift hours from overloaded to available people
  const displayed = optimized
    ? employees.map((e) => {
        if (e.name === 'Sara Malik') return { ...e, assignedHrs: 40 }
        if (e.name === 'Ali Raza') return { ...e, assignedHrs: 27 }
        return e
      })
    : employees

  return (
    <div>
      <Topbar
        title="Team & Workload"
        subtitle={`${employees.length} team members`}
        actions={
          <Button variant="primary" onClick={() => setOptimized((v) => !v)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" />
            </svg>
            {optimized ? 'Reset workload' : 'Optimize team'}
          </Button>
        }
      />
      <div className="p-6 space-y-5">
        {optimized && (
          <Panel className="p-3.5 border-signal-teal/30 bg-signal-teal/5">
            <p className="text-sm text-signal-teal">
              Rebalanced: moved 5h from Sara Malik to Ali Raza based on current department and skill overlap.
            </p>
          </Panel>
        )}

        <Panel className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs text-text-dim uppercase tracking-wide">
                <th className="font-medium px-4 py-3">Employee</th>
                <th className="font-medium px-4 py-3">Department</th>
                <th className="font-medium px-4 py-3 w-52">Capacity</th>
                <th className="font-medium px-4 py-3">Projects</th>
                <th className="font-medium px-4 py-3">Open tasks</th>
                <th className="font-medium px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {displayed.map((e) => {
                const pct = Math.round((e.assignedHrs / e.capacityHrs) * 100)
                const status = workloadStatus(e.assignedHrs, e.capacityHrs)
                return (
                  <tr key={e.id} className="border-b border-line-soft last:border-0 hover:bg-panel-raised transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-3">
                        <Avatar name={e.name} color={e.avatarColor} />
                        <div>
                          <p className="font-medium">{e.name}</p>
                          <p className="text-xs text-text-faint">{e.role}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-text-dim">{e.department}</td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2">
                        <ProgressBar value={pct} tone={status.tone} />
                        <span className="text-xs tabular text-text-dim w-16 shrink-0">{e.assignedHrs}h / {e.capacityHrs}h</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-text-dim tabular">{e.activeProjects}</td>
                    <td className="px-4 py-3.5 text-text-dim tabular">
                      {e.openTasks}{e.overdueTasks > 0 && <span className="text-signal-coral"> ({e.overdueTasks} overdue)</span>}
                    </td>
                    <td className="px-4 py-3.5"><Tag tone={status.tone}>{status.label}</Tag></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  )
}
