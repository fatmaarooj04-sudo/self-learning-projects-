import { createContext, useContext, useEffect, useState } from 'react'

const AuthContext = createContext(null)

const roleProfiles = {
  admin: { name: 'Arooj Fatima', title: 'Operations Admin', avatarColor: '#4c6ef5' },
  employee: { name: 'Ahmed Khan', title: 'Backend Engineer', avatarColor: '#2fb67c' },
  client: { name: 'Farhan Iqbal', title: 'ABC Technologies', avatarColor: '#cf9a44' },
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem('opspilot.user')
      return raw ? JSON.parse(raw) : null
    } catch {
      return null
    }
  })

  useEffect(() => {
    if (user) localStorage.setItem('opspilot.user', JSON.stringify(user))
    else localStorage.removeItem('opspilot.user')
  }, [user])

  const login = (role, email) => {
    const profile = roleProfiles[role]
    setUser({ role, email, ...profile })
  }

  const logout = () => setUser(null)

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
