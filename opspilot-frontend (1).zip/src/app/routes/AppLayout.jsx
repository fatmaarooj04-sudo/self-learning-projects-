import { Outlet, Navigate } from 'react-router-dom'
import Sidebar from '../../components/ui/Sidebar'
import { useAuth } from '../providers/AuthContext'

export default function AppLayout() {
  const { user } = useAuth()

  if (!user) return <Navigate to="/login" replace />

  return (
    <div className="flex min-h-screen bg-ink">
      <Sidebar />
      <main className="flex-1 min-w-0">
        <Outlet />
      </main>
    </div>
  )
}
