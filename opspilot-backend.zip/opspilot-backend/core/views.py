from django.contrib.auth import get_user_model
from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from .models import AuditLog, Client, Employee, Issue, Project, Task, Workflow, WorkflowRequest
from .serializers import (
    AuditLogSerializer, ClientSerializer, EmployeeSerializer, IssueSerializer,
    ProjectSerializer, RegisterSerializer, TaskSerializer, UserSerializer,
    WorkflowSerializer, WorkflowRequestSerializer,
)

User = get_user_model()


# ---- Auth ----
# The frontend's demo login sends {email, password, role}. Real login just needs
# {email, password} — we look the user up by email and check the password ourselves,
# then hand back a JWT access/refresh token pair the frontend stores and sends on
# every future request as "Authorization: Bearer <access>".

class LoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        email = request.data.get("email", "")
        password = request.data.get("password", "")
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            user = None

        if user is None or not user.check_password(password):
            return Response({"detail": "Invalid email or password."}, status=status.HTTP_401_UNAUTHORIZED)

        refresh = RefreshToken.for_user(user)
        return Response({
            "access": str(refresh.access_token),
            "refresh": str(refresh),
            "user": UserSerializer(user).data,
        })


class RegisterView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        refresh = RefreshToken.for_user(user)
        return Response({
            "access": str(refresh.access_token),
            "refresh": str(refresh),
            "user": UserSerializer(user).data,
        }, status=status.HTTP_201_CREATED)


class MeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)


# ---- Data endpoints ----
# ModelViewSet gives full CRUD (list, retrieve, create, update, delete) from one class.

class ClientViewSet(viewsets.ModelViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer
    permission_classes = [permissions.IsAuthenticated]


class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all().select_related("client").prefetch_related("tasks")
    serializer_class = ProjectSerializer
    permission_classes = [permissions.IsAuthenticated]


class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all().select_related("assignee", "project")
    serializer_class = TaskSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = super().get_queryset()
        project_id = self.request.query_params.get("project")
        if project_id:
            qs = qs.filter(project_id=project_id)
        return qs


class IssueViewSet(viewsets.ModelViewSet):
    queryset = Issue.objects.all().select_related("project")
    serializer_class = IssueSerializer
    permission_classes = [permissions.IsAuthenticated]


class WorkflowViewSet(viewsets.ModelViewSet):
    queryset = Workflow.objects.all().prefetch_related("active")
    serializer_class = WorkflowSerializer
    permission_classes = [permissions.IsAuthenticated]


class WorkflowRequestViewSet(viewsets.ModelViewSet):
    queryset = WorkflowRequest.objects.all()
    serializer_class = WorkflowRequestSerializer
    permission_classes = [permissions.IsAuthenticated]


class AuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = AuditLog.objects.all()
    serializer_class = AuditLogSerializer
    permission_classes = [permissions.IsAuthenticated]
