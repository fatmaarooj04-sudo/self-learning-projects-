from django.contrib.auth import get_user_model
from rest_framework import serializers

from .models import (
    AuditLog, Client, Employee, Issue, Project, Task, Workflow, WorkflowRequest,
)

User = get_user_model()


class ClientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Client
        fields = ["id", "name", "contact", "since"]


class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = [
            "id", "photo", "name", "role", "department", "avatar_color",
            "capacity_hrs", "assigned_hrs", "overload_flag",
        ]


class TaskSerializer(serializers.ModelSerializer):
    assignee_name = serializers.CharField(source="assignee.name", read_only=True, default=None)

    class Meta:
        model = Task
        fields = [
            "id", "project", "title", "status", "priority", "assignee", "assignee_name",
            "department", "est_hrs", "actual_hrs", "deadline", "depends_on", "tags", "created_at",
        ]


class ProjectSerializer(serializers.ModelSerializer):
    tasks = TaskSerializer(many=True, read_only=True)

    class Meta:
        model = Project
        fields = [
            "id", "name", "client", "manager", "start", "deadline", "health", "risk",
            "budget", "spent", "status", "description", "tasks", "created_at",
        ]


class IssueSerializer(serializers.ModelSerializer):
    class Meta:
        model = Issue
        fields = [
            "id", "title", "project", "priority", "status", "reported_by",
            "assigned_to", "timeline", "created_at",
        ]


class WorkflowRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkflowRequest
        fields = ["id", "workflow", "item", "current_step", "requested_by", "created_at"]


class WorkflowSerializer(serializers.ModelSerializer):
    active = WorkflowRequestSerializer(many=True, read_only=True)

    class Meta:
        model = Workflow
        fields = ["id", "name", "steps", "active"]


class AuditLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditLog
        fields = ["id", "actor", "action", "created_at"]


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "email", "name", "role", "title", "avatar_color", "client"]


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)

    class Meta:
        model = User
        fields = ["email", "password", "name", "role", "title", "client"]

    def create(self, validated_data):
        password = validated_data.pop("password")
        # username is required by Django's base user model — reuse the email
        user = User(username=validated_data["email"], **validated_data)
        user.set_password(password)
        user.save()
        return user
