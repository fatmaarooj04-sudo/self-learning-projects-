from django.urls import path, include
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("clients", views.ClientViewSet)
router.register("employees", views.EmployeeViewSet)
router.register("projects", views.ProjectViewSet)
router.register("tasks", views.TaskViewSet)
router.register("issues", views.IssueViewSet)
router.register("workflows", views.WorkflowViewSet)
router.register("workflow-requests", views.WorkflowRequestViewSet)
router.register("audit-log", views.AuditLogViewSet)

urlpatterns = [
    path("auth/login", views.LoginView.as_view()),
    path("auth/register", views.RegisterView.as_view()),
    path("auth/me", views.MeView.as_view()),
    path("", include(router.urls)),
]
