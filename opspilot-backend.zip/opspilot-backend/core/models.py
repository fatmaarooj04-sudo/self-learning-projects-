from django.contrib.auth.models import AbstractUser
from django.db import models


class Client(models.Model):
    """A client company OpsPilot does work for."""
    name = models.CharField(max_length=200)
    contact = models.CharField(max_length=200)
    since = models.CharField(max_length=20)  # stored as 'YYYY-MM-DD' string, same as the mock data

    def __str__(self):
        return self.name


class User(AbstractUser):
    """
    Our own login account model, replacing Django's default.
    role decides what a person can see: 'admin' | 'employee' | 'client'
    """
    ROLE_CHOICES = [
        ("admin", "Admin"),
        ("employee", "Employee"),
        ("client", "Client"),
    ]
    name = models.CharField(max_length=200, blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="employee")
    title = models.CharField(max_length=200, blank=True)
    avatar_color = models.CharField(max_length=20, default="#7c8cf8")
    # only set when role == 'client' — links this login to a Client company
    client = models.ForeignKey(Client, null=True, blank=True, on_delete=models.SET_NULL, related_name="users")

    def __str__(self):
        return f"{self.email} ({self.role})"


class Employee(models.Model):
    """A staff member who can be assigned tasks. Separate from User/login."""
    photo = models.CharField(max_length=300, blank=True)
    name = models.CharField(max_length=200)
    role = models.CharField(max_length=200)
    department = models.CharField(max_length=100)
    avatar_color = models.CharField(max_length=20, default="#7c8cf8")
    capacity_hrs = models.IntegerField(default=40)
    assigned_hrs = models.IntegerField(default=0)
    overload_flag = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class Project(models.Model):
    STATUS_CHOICES = [
        ("Planning", "Planning"),
        ("On Track", "On Track"),
        ("At Risk", "At Risk"),
        ("Completed", "Completed"),
    ]
    RISK_CHOICES = [("low", "low"), ("medium", "medium"), ("high", "high")]

    name = models.CharField(max_length=200)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="projects")
    manager = models.CharField(max_length=200)
    start = models.CharField(max_length=20)
    deadline = models.CharField(max_length=20)
    health = models.IntegerField(default=100)
    risk = models.CharField(max_length=10, choices=RISK_CHOICES, default="low")
    budget = models.FloatField(default=0)
    spent = models.FloatField(default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="Planning")
    description = models.TextField(default="No description provided yet.")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class Task(models.Model):
    STATUS_CHOICES = [
        ("todo", "todo"), ("in-progress", "in-progress"), ("blocked", "blocked"),
        ("done", "done"), ("overdue", "overdue"),
    ]
    PRIORITY_CHOICES = [("low", "low"), ("medium", "medium"), ("high", "high"), ("critical", "critical")]

    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="tasks")
    title = models.CharField(max_length=300)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="todo")
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default="medium")
    assignee = models.ForeignKey(Employee, null=True, blank=True, on_delete=models.SET_NULL, related_name="tasks")
    department = models.CharField(max_length=100, default="Development")
    est_hrs = models.IntegerField(default=0)
    actual_hrs = models.IntegerField(default=0)
    deadline = models.CharField(max_length=20, blank=True)
    depends_on = models.JSONField(default=list, blank=True)  # list of task ids as strings
    tags = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class Issue(models.Model):
    PRIORITY_CHOICES = [("low", "low"), ("medium", "medium"), ("high", "high"), ("critical", "critical")]
    STATUS_CHOICES = [("open", "open"), ("investigating", "investigating"), ("resolved", "resolved")]

    title = models.CharField(max_length=300)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="issues")
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default="medium")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="open")
    reported_by = models.CharField(max_length=200)
    assigned_to = models.CharField(max_length=200)
    timeline = models.JSONField(default=list, blank=True)  # [{"time": "...", "event": "..."}]
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class Workflow(models.Model):
    name = models.CharField(max_length=200)
    steps = models.JSONField(default=list)  # ["Designer", "Project Manager", ...]

    def __str__(self):
        return self.name


class WorkflowRequest(models.Model):
    workflow = models.ForeignKey(Workflow, on_delete=models.CASCADE, related_name="active")
    item = models.CharField(max_length=300)
    current_step = models.IntegerField(default=0)
    requested_by = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.item


class AuditLog(models.Model):
    actor = models.CharField(max_length=200)
    action = models.CharField(max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.actor}: {self.action}"
