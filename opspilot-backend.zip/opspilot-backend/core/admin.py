from django.contrib import admin
from .models import Client, Employee, Project, Task, Issue, Workflow, WorkflowRequest, AuditLog, User

# Registering these makes them show up in the built-in Django admin at /admin/
# so you can view and edit data in a browser without writing any code.
admin.site.register(User)
admin.site.register(Client)
admin.site.register(Employee)
admin.site.register(Project)
admin.site.register(Task)
admin.site.register(Issue)
admin.site.register(Workflow)
admin.site.register(WorkflowRequest)
admin.site.register(AuditLog)
