from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from core.models import (
    AuditLog, Client, Employee, Issue, Project, Task, Workflow, WorkflowRequest,
)

User = get_user_model()


class Command(BaseCommand):
    help = "Load the same demo data the frontend currently uses as mock data, into the real database."

    def handle(self, *args, **options):
        self.stdout.write("Seeding database...")

        # --- Clients ---
        cli1 = Client.objects.create(name="ABC Technologies", contact="Farhan Iqbal", since="2024-02-01")
        cli2 = Client.objects.create(name="Northbridge Retail", contact="Emma Clarke", since="2023-11-14")
        cli3 = Client.objects.create(name="Vantage Logistics", contact="Omar Siddiqui", since="2025-01-09")

        # --- Demo login accounts, one per role (password is the same for all: "password123") ---
        admin = User.objects.create_user(
            username="admin@opspilot.dev", email="admin@opspilot.dev", password="password123",
            name="Arooj Fatima", role="admin", title="Operations Admin", avatar_color="#4c6ef5",
        )
        User.objects.create_user(
            username="employee@opspilot.dev", email="employee@opspilot.dev", password="password123",
            name="Ahmed Khan", role="employee", title="Backend Engineer", avatar_color="#2fb67c",
        )
        User.objects.create_user(
            username="client@opspilot.dev", email="client@opspilot.dev", password="password123",
            name="Farhan Iqbal", role="client", title="ABC Technologies", avatar_color="#cf9a44", client=cli1,
        )
        User.objects.create_superuser(
            username="superadmin", email="superadmin@opspilot.dev", password="password123",
        )

        # --- Employees (staff who get assigned tasks) ---
        e1 = Employee.objects.create(photo="/avatars/ahmed.svg", name="Ahmed Khan", role="Backend Engineer",
                                      department="Development", avatar_color="#7c8cf8", capacity_hrs=40, assigned_hrs=37)
        e2 = Employee.objects.create(photo="/avatars/sara.svg", name="Sara Malik", role="Product Designer",
                                      department="Design", avatar_color="#f2586f", capacity_hrs=40, assigned_hrs=46, overload_flag=True)
        e3 = Employee.objects.create(photo="/avatars/ali.svg", name="Ali Raza", role="Frontend Engineer",
                                      department="Development", avatar_color="#37d0a8", capacity_hrs=40, assigned_hrs=21)
        e4 = Employee.objects.create(photo="/avatars/zoya.svg", name="Zoya Ahmed", role="QA Engineer",
                                      department="Development", avatar_color="#f2ab3d", capacity_hrs=40, assigned_hrs=34)
        e5 = Employee.objects.create(photo="/avatars/hamza.svg", name="Hamza Sheikh", role="Marketing Lead",
                                      department="Marketing", avatar_color="#7c8cf8", capacity_hrs=40, assigned_hrs=29)
        Employee.objects.create(photo="/avatars/nida.svg", name="Nida Farooq", role="HR Manager",
                                 department="HR", avatar_color="#37d0a8", capacity_hrs=40, assigned_hrs=33)

        # --- Projects ---
        p1 = Project.objects.create(name="CRM Migration", client=cli1, manager="Sara Malik", start="2026-08-01",
                                     deadline="2026-09-15", health=72, risk="medium", budget=18000, spent=11200,
                                     status="At Risk",
                                     description="Migrating ABC Technologies from a legacy on-prem CRM to a cloud-based platform.")
        p2 = Project.objects.create(name="Website Revamp", client=cli2, manager="Ahmed Khan", start="2026-07-10",
                                     deadline="2026-09-03", health=41, risk="high", budget=12500, spent=9800,
                                     status="At Risk",
                                     description="Full redesign and rebuild of Northbridge Retail's e-commerce storefront.")
        p3 = Project.objects.create(name="Mobile App", client=cli3, manager="Ali Raza", start="2026-06-01",
                                     deadline="2026-10-01", health=88, risk="low", budget=32000, spent=19400,
                                     status="On Track",
                                     description="Native iOS and Android companion app for Vantage Logistics drivers.")
        p4 = Project.objects.create(name="Payment Gateway Integration", client=cli2, manager="Ahmed Khan",
                                     start="2026-08-10", deadline="2026-09-20", health=63, risk="medium", budget=9000,
                                     spent=4100, status="On Track",
                                     description="Integrating a regional payment gateway into the Northbridge storefront.")

        # --- Tasks ---
        Task.objects.create(project=p1, title="Database schema design", status="done", priority="high",
                             assignee=e1, department="Development", est_hrs=12, actual_hrs=14,
                             deadline="2026-08-10", tags=["backend", "db"])
        Task.objects.create(project=p1, title="API development", status="blocked", priority="high",
                             assignee=e1, department="Development", est_hrs=20, actual_hrs=6,
                             deadline="2026-08-25", tags=["backend", "api"])
        Task.objects.create(project=p1, title="Frontend integration", status="todo", priority="medium",
                             assignee=e3, department="Development", est_hrs=16, deadline="2026-09-02", tags=["frontend"])
        Task.objects.create(project=p1, title="QA regression pass", status="todo", priority="medium",
                             assignee=e4, department="Development", est_hrs=10, deadline="2026-09-08", tags=["qa"])
        Task.objects.create(project=p1, title="Data migration script", status="overdue", priority="high",
                             assignee=e1, department="Development", est_hrs=8, actual_hrs=9,
                             deadline="2026-08-27", tags=["backend", "migration"])
        Task.objects.create(project=p2, title="Design system tokens", status="done", priority="high",
                             assignee=e2, department="Design", est_hrs=14, actual_hrs=15, deadline="2026-07-20", tags=["design"])
        Task.objects.create(project=p2, title="Checkout flow build", status="overdue", priority="critical",
                             assignee=e3, department="Development", est_hrs=18, actual_hrs=12,
                             deadline="2026-08-22", tags=["frontend", "checkout"])
        Task.objects.create(project=p2, title="Product catalog page", status="overdue", priority="high",
                             assignee=e2, department="Design", est_hrs=10, actual_hrs=8, deadline="2026-08-24", tags=["frontend"])
        Task.objects.create(project=p2, title="SEO audit", status="todo", priority="low",
                             assignee=e5, department="Marketing", est_hrs=6, deadline="2026-09-01", tags=["marketing"])
        Task.objects.create(project=p3, title="Route tracking module", status="in-progress", priority="high",
                             assignee=e3, department="Development", est_hrs=24, actual_hrs=18, deadline="2026-09-10", tags=["mobile"])
        Task.objects.create(project=p3, title="Push notification service", status="todo", priority="medium",
                             assignee=e1, department="Development", est_hrs=12, deadline="2026-09-18", tags=["backend"])
        Task.objects.create(project=p4, title="Gateway sandbox setup", status="done", priority="medium",
                             assignee=e1, department="Development", est_hrs=5, actual_hrs=5, deadline="2026-08-15", tags=["backend"])

        # --- Issues ---
        Issue.objects.create(
            title="Payment API failing intermittently", project=p4, priority="critical", status="investigating",
            reported_by="Ahmed Khan", assigned_to="Backend Team",
            timeline=[
                {"time": "09:42", "event": "Issue created"},
                {"time": "09:50", "event": "Assigned to Backend Team"},
                {"time": "10:13", "event": "Investigation started"},
                {"time": "11:02", "event": "Root cause identified — gateway timeout under load"},
            ],
        )
        Issue.objects.create(
            title="Checkout page 500 error on mobile Safari", project=p2, priority="high", status="open",
            reported_by="Sara Malik", assigned_to="Frontend Team",
            timeline=[{"time": "08:15", "event": "Issue created"}, {"time": "08:20", "event": "Awaiting triage"}],
        )
        Issue.objects.create(
            title="CRM contact sync duplicating records", project=p1, priority="medium", status="resolved",
            reported_by="Client — ABC Technologies", assigned_to="Ahmed Khan",
            timeline=[
                {"time": "Aug 27, 14:02", "event": "Issue created"},
                {"time": "Aug 27, 14:40", "event": "Assigned to Ahmed Khan"},
                {"time": "Aug 28, 09:15", "event": "Fix deployed"},
                {"time": "Aug 28, 10:05", "event": "Issue resolved"},
            ],
        )
        Issue.objects.create(
            title="Delivery ETA miscalculated on long routes", project=p3, priority="low", status="open",
            reported_by="Ali Raza", assigned_to="Backend Team",
            timeline=[{"time": "Aug 26, 16:10", "event": "Issue created"}],
        )

        # --- Workflows ---
        wf1 = Workflow.objects.create(name="Client Design Approval",
                                       steps=["Designer", "Project Manager", "Client", "Final Approval"])
        WorkflowRequest.objects.create(workflow=wf1, item="Homepage hero design — Northbridge Retail",
                                        current_step=2, requested_by="Sara Malik")
        WorkflowRequest.objects.create(workflow=wf1, item="Onboarding flow wireframes — Vantage Logistics",
                                        current_step=1, requested_by="Sara Malik")

        wf2 = Workflow.objects.create(name="Leave Request", steps=["Employee", "Manager", "HR", "Approved"])
        WorkflowRequest.objects.create(workflow=wf2, item="Ali Raza — 2 days leave (Sep 4–5)",
                                        current_step=1, requested_by="Ali Raza")
        WorkflowRequest.objects.create(workflow=wf2, item="Zoya Ahmed — 1 day leave (Sep 2)",
                                        current_step=2, requested_by="Zoya Ahmed")

        # --- Audit log ---
        for actor, action in [
            ("Sarah", 'changed Project Alpha status from "On Track" to "At Risk"'),
            ("Ahmed Khan", "uploaded contract.pdf to CRM Migration"),
            ("Admin", "added new employee Zoya Ahmed"),
            ("Client — Northbridge Retail", "approved homepage design"),
            ("Ali Raza", 'marked "Route tracking module" as in progress'),
            ("Zoya Ahmed", "logged 4 hours against QA regression pass"),
            ("System", "auto-assigned INC-2048 to Backend Team"),
        ]:
            AuditLog.objects.create(actor=actor, action=action)

        self.stdout.write(self.style.SUCCESS(
            "Done! Demo logins (password for all: password123):\n"
            "  admin@opspilot.dev\n  employee@opspilot.dev\n  client@opspilot.dev\n"
            "Django admin superuser: superadmin / password123 at /admin/"
        ))
