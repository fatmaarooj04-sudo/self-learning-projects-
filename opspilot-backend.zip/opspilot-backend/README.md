# OpsPilot Backend (Django + PostgreSQL)

This is the real backend for your OpsPilot frontend. It replaces the mock
data in `src/data/` with a real database, and replaces the fake
`localStorage` login with real accounts and secure tokens.

## What's inside

```
config/          Django project settings (database, JWT, CORS)
core/
  models.py      Database tables: User, Client, Employee, Project, Task, Issue, Workflow...
  serializers.py Converts database records <-> JSON for the API
  views.py       The actual API logic (login, register, CRUD for everything)
  urls.py        Maps URLs like /api/projects/ to the views above
  admin.py       Free browser-based admin panel at /admin/
  management/commands/seed_data.py   Loads demo data matching your current mock data
requirements.txt Python packages needed
.env.example     Template for your secret configuration
```

## Step 1 — Get a PostgreSQL database

As a beginner, the easiest way is a **free hosted Postgres database** — no
installing PostgreSQL on your own computer required:

- [Neon](https://neon.tech) (recommended, generous free tier) or
- [Railway](https://railway.app) (also good, and where you can host the backend itself later) or
- [Supabase](https://supabase.com)

Sign up, create a new project/database, and copy the **connection string**
it gives you — it looks like:
```
postgresql://username:password@host:5432/dbname
```

## Step 2 — Install Python dependencies

Open a terminal in this folder and run:

```bash
python3 -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Step 3 — Configure your environment

```bash
cp .env.example .env
```

Open `.env` and paste in your real `DATABASE_URL` from Step 1. Also generate
a real `SECRET_KEY`:

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(50))"
```
Paste that output as `SECRET_KEY` in `.env`.

## Step 4 — Create the database tables

```bash
python3 manage.py migrate
```

This reads `core/models.py` and creates all the tables in your Postgres database.

## Step 5 — Load demo data (optional but recommended)

```bash
python3 manage.py seed_data
```

This creates the same projects/tasks/employees your frontend currently shows
as mock data, plus three demo logins so you can test right away:

| Email | Password | Role |
|---|---|---|
| admin@opspilot.dev | password123 | admin |
| employee@opspilot.dev | password123 | employee |
| client@opspilot.dev | password123 | client |

There's also a Django admin superuser: `superadmin@opspilot.dev` / `password123`,
usable at `/admin/` once the server is running (a full point-and-click UI to
view/edit every table — great for checking data without writing code).

## Step 6 — Run the server

```bash
python3 manage.py runserver
```

Your API is now live at `http://127.0.0.1:8000/api/`. Try it:

```bash
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@opspilot.dev","password":"password123"}'
```

You should get back an `access` token, a `refresh` token, and a `user` object.

## API reference

All endpoints below (except login/register) require a header:
`Authorization: Bearer <access token>`

```
POST   /api/auth/login          { email, password } -> { access, refresh, user }
POST   /api/auth/register       { email, password, name, role } -> { access, refresh, user }
GET    /api/auth/me             -> current logged-in user

GET    /api/clients/            POST /api/clients/
GET    /api/employees/          POST /api/employees/         PATCH /api/employees/:id/
GET    /api/projects/           POST /api/projects/          PATCH /api/projects/:id/
GET    /api/tasks/              POST /api/tasks/             PATCH /api/tasks/:id/
                                 (filter with /api/tasks/?project=1)
GET    /api/issues/             POST /api/issues/            PATCH /api/issues/:id/
GET    /api/workflows/          
GET    /api/workflow-requests/  POST /api/workflow-requests/
GET    /api/audit-log/
```

Every `/api/<thing>/` endpoint supports `GET` (list), `POST` (create),
`GET /:id/` (single item), `PATCH /:id/` (partial update), and
`DELETE /:id/` — this comes for free from Django REST Framework's ModelViewSet.

## Next step

Once this is running and you can log in with curl or a tool like
[Insomnia](https://insomnia.rest)/Postman, we'll connect your React frontend
to it — filling in `src/services/` and updating `AuthContext.jsx` /
`DataContext.jsx` to call this API instead of using mock arrays.
